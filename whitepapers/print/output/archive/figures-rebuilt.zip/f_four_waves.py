from common import *
fig,axes=plt.subplots(2,2,figsize=(4.3,3.5),dpi=300)
fig.subplots_adjust(hspace=0.85,wspace=0.45)

def pair(ax,title,a,b,la,lb,ylab,fmt='{:.2f}'):
    ax.bar([0,1],[a,b],color=[STATE,GLOBAL],width=0.55)
    for x,v in zip([0,1],[a,b]):
        ax.text(x,v*1.03,fmt.format(v),ha='center',fontsize=6.6,fontweight='bold')
    ax.set_xticks([0,1]); ax.set_xticklabels([la,lb],fontsize=6.6)
    ax.set_ylabel(ylab,fontsize=6.4); ax.set_title(title,fontsize=7,pad=4)
    ax.set_ylim(0,max(a,b)*1.25); ax.spines[['top','right']].set_visible(False)
    ax.tick_params(labelsize=6)

pair(axes[0][0],'Fertility collapse',0.97,0.87,'2015','2025','Births per woman')
pair(axes[0][1],'Ageing',13.1,20.7,'2015','2025','Citizens 65+, %','{:.1f}%')
pair(axes[1][0],'Shrinking household',62,88,'2015','2025','Seniors alone, 000s','{:.0f}k')
pair(axes[1][1],'Remaking of care',320,474,'2019','2024','S$/month','${:.0f}')
fig.suptitle('The four demographic waves',fontsize=9,x=0.015,ha='left',y=0.96)
source(fig,'Source: SingStat, Population.gov.sg, MOM, Household Expenditure Survey. Confidence: High.')
fig.tight_layout(rect=[0,0.045,1,0.95]); finish(fig,'fig-four-waves')
