from common import *
walls=[('E-commerce platforms',99,'Shopee 53%, Lazada, TikTok'),
       ('Supermarkets',82,'FairPrice, Sheng Siong, Macrovalue'),
       ('Audit (Big Four)',100,'PwC, KPMG, Deloitte, EY'),
       ('Telecoms',93,'Singtel, StarHub, M1')]
doors=[('Tuition centres',None,'1,000+ centres, no owner'),
       ('Salons & personal care',None,'fragmented, local'),
       ('Home care',None,'licence-bound, no brand'),
       ('Car servicing',None,'independent workshops')]
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.35,2.7),dpi=300,gridspec_kw={'width_ratios':[1.25,1]})
n=[w[0] for w in walls]; v=[w[1] for w in walls]
a1.barh(range(len(n))[::-1],v,color=DOM,height=0.55)
for y,val in zip(range(len(n))[::-1],v):
    a1.text(val-4,y,f'{val}%',va='center',ha='right',fontsize=7,color='white',fontweight='bold')
a1.set_yticks(range(len(n))[::-1]); a1.set_yticklabels(n,fontsize=6.7)
a1.set_xlim(0,108); a1.set_xlabel('Share held by the top few',fontsize=7)
a1.spines[['top','right']].set_visible(False); a1.tick_params(axis='x',labelsize=6.5)
a1.set_title('Walls: concentrated',fontsize=8,pad=5,color=DOM)
a2.axis('off')
a2.set_title('Doors: fragmented',fontsize=8,pad=5,color=GLOBAL)
for i,(t,_,sub) in enumerate(doors):
    y=0.86-i*0.235
    a2.add_patch(mp.FancyBboxPatch((0.02,y-0.10),0.94,0.175,boxstyle='round,pad=0.01,rounding_size=0.03',
                facecolor=LIGHT,edgecolor=GLOBAL,linewidth=0.6,transform=a2.transAxes))
    a2.text(0.06,y+0.025,t,fontsize=6.9,fontweight='bold',transform=a2.transAxes,va='center')
    a2.text(0.06,y-0.055,sub,fontsize=5.9,color=MUTE,transform=a2.transAxes,va='center',style='italic')
fig.suptitle('Walls and doors: where a name already owns the money',fontsize=8.8,x=0.015,ha='left',y=0.96)
source(fig,'Source: Momentum Works (platform share), company reports, SingStat. Confidence: Moderate.')
fig.subplots_adjust(right=0.97); fig.tight_layout(rect=[0.01,0.06,0.985,0.93]); finish(fig,'fig-walls-doors')
