from common import *

# ---------- 1. Singapore story: how a country positioned itself ----------
stages=[('1965','Independence','No resources, no hinterland, no obvious reason to exist'),
        ('1970s','The word chosen','"Clean, safe, corruption-free" \u2014 a promise nobody else was making'),
        ('1980s\u201390s','The proof delivered','Rule of law, infrastructure, an efficient state'),
        ('Today','The word owned','Multinationals still choose it for the reason it claimed')]
fig,ax=plt.subplots(figsize=(4.3,2.5),dpi=300)
for i,(yr,t,sub) in enumerate(stages):
    y=3-i; lead=(i==3)
    ax.add_patch(mp.FancyBboxPatch((0.13,y-0.35),0.84,0.70,boxstyle='round,pad=0.008,rounding_size=0.05',
                facecolor=GLOBAL if lead else LIGHT,edgecolor=GLOBAL,linewidth=0.7))
    ax.text(0.065,y,yr,ha='center',va='center',fontsize=6.8,fontweight='bold',color=GLOBAL)
    tc='white' if lead else INK
    ax.text(0.17,y+0.13,t,fontsize=7.3,fontweight='bold',color=tc,va='center')
    ax.text(0.17,y-0.14,sub,fontsize=6.0,color=tc,style='italic',va='center',alpha=0.95)
    if i<3: ax.annotate('',xy=(0.065,y-0.46),xytext=(0.065,y-0.30),
                        arrowprops=dict(arrowstyle='-|>',color=GLOBAL,lw=1.0))
ax.set_xlim(0,1.02); ax.set_ylim(-0.65,3.55); ax.axis('off')
ax.set_title('How a country positioned itself',fontsize=8.8,loc='left',x=0.0,pad=6)
source(fig,'A nation claimed one word and spent sixty years proving it. The method is the same at any scale.',y=0.03)
fig.tight_layout(rect=[0,0.065,1,1]); finish(fig,'fig-b2-singapore-story')

# ---------- 2. Heritage brands: a century of owning a word ----------
brands=[('Tiger Balm',1924,'relief'),('Ya Kun',1944,'kaya toast'),
        ('Khong Guan',1947,'the biscuit tin'),('Old Chang Kee',1956,'curry puff'),
        ('Sheng Siong',1985,'the deal'),('BreadTalk',2000,'designer bread')]
fig,ax=plt.subplots(figsize=(4.3,2.5),dpi=300)
ys=range(len(brands))[::-1]
for y,(n,yr,w) in zip(ys,brands):
    ax.plot([yr,2026],[y,y],color=GLOBAL,lw=2.4,solid_capstyle='round',alpha=0.75)
    ax.scatter([yr],[y],s=26,color=GLOBAL,zorder=3)
    ax.text(yr-2.5,y,f'{n}  {yr}',ha='right',va='center',fontsize=6.6,fontweight='bold')
    ax.text(2028,y,f'"{w}"',ha='left',va='center',fontsize=6.6,color=DOM,style='italic')
ax.set_xlim(1900,2062); ax.set_ylim(-0.7,len(brands)-0.3)
ax.set_yticks([]); ax.set_xticks([1920,1950,1980,2010])
ax.spines[['top','right','left']].set_visible(False); ax.tick_params(axis='x',labelsize=6.6)
ax.set_xlabel('Year the word was claimed',fontsize=7.2)
ax.set_title('A century of owning a word',fontsize=8.8,loc='left',pad=6)
source(fig,'Founding years from company histories. The word is what the customer still says today.')
fig.tight_layout(rect=[0,0.05,1,1]); finish(fig,'fig-b2-heritage-brands')

# ---------- 3. Category creators ----------
cc=[('BreadTalk','2000','designer bread','Bread was a staple.\nIt made bread a treat.'),
    ('Banyan Tree','1994','romantic sanctuary','Hotels sold rooms.\nIt sold a private villa.'),
    ('TWG Tea','2008','luxury tea','Tea was a supermarket good.\nIt made tea a luxury.'),
    ('Secretlab','2014','premium gaming chair','Chairs were office furniture.\nIt made one for gamers.')]
fig,ax=plt.subplots(figsize=(4.3,2.6),dpi=300)
for i,(n,yr,word,sub) in enumerate(cc):
    x=(i%2)*1.0; y=1-(i//2)
    ax.add_patch(mp.FancyBboxPatch((x+0.03,y+0.06),0.94,0.86,boxstyle='round,pad=0.01,rounding_size=0.04',
                facecolor=DOM,alpha=0.09,edgecolor=DOM,linewidth=0.8))
    ax.text(x+0.5,y+0.76,f'{n}  ({yr})',ha='center',fontsize=7.2,fontweight='bold',color=INK)
    ax.text(x+0.5,y+0.58,f'"{word}"',ha='center',fontsize=7.0,color=DOM,style='italic',fontweight='bold')
    ax.text(x+0.5,y+0.30,sub,ha='center',va='center',fontsize=6.0,color=MUTE,linespacing=1.4)
ax.set_xlim(0,2.0); ax.set_ylim(0,2.0); ax.axis('off')
ax.set_title('Create a category, be first in it',fontsize=8.8,loc='left',x=0.0,pad=5)
source(fig,'Four Singapore brands that did not enter a category. They made one.',y=0.03)
fig.tight_layout(rect=[0,0.075,1,1]); finish(fig,'fig-b2-category-creators')
