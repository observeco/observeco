from common import *

# ---------- 7. The positioning statement ----------
fig,ax=plt.subplots(figsize=(4.3,2.55),dpi=300)
parts=[('For','[the specific customer]','who exactly? not "everyone"',GLOBAL),
       ('I am','[the word]','one word, not a list',DOM),
       ('because','[the proof]','why it is true, not a claim',STATE),
       ('so','[the benefit]','what changes for them','#5d6b7a')]
for i,(lead,slot,note,c) in enumerate(parts):
    y=3-i
    ax.text(0.10,y,lead,ha='right',va='center',fontsize=7.4,style='italic',color=MUTE)
    ax.add_patch(mp.FancyBboxPatch((0.13,y-0.22),0.50,0.44,boxstyle='round,pad=0.008,rounding_size=0.04',
                facecolor=c,alpha=0.12,edgecolor=c,linewidth=0.9))
    ax.text(0.38,y,slot,ha='center',va='center',fontsize=7.2,fontweight='bold',color=c)
    ax.text(0.67,y,note,ha='left',va='center',fontsize=6.2,color=MUTE,style='italic')
ax.text(0.13,-0.75,'Worked example',fontsize=6.6,fontweight='bold',color=INK)
ax.text(0.13,-1.32,'"For families with a parent who has dementia, I am the dementia\nspecialist, because every carer I send is dementia-trained, so you\nstop explaining your mother to a stranger every week."',
        fontsize=6.2,color=INK,linespacing=1.45,style='italic')
ax.set_xlim(0,1.10); ax.set_ylim(-1.95,3.45); ax.axis('off')
ax.set_title('The positioning statement',fontsize=8.8,loc='left',x=0.0,pad=6)
source(fig,'Template after Geoffrey Moore, Crossing the Chasm (1991); worked example from the\nhome-care case in Part Five.',y=0.02)
fig.tight_layout(rect=[0,0.085,1,1]); finish(fig,'fig-b2-positioning-statement')

# ---------- 8. The one-page position ----------
fig,ax=plt.subplots(figsize=(4.25,2.75),dpi=300)
rows=[('My customer','the specific person, not the market'),
      ('My competitive set','who they would otherwise choose'),
      ('The word they already own','what the incumbent holds'),
      ('My word','the one I will be known for'),
      ('My proof','why it is true'),
      ('What I will stop doing','the discipline of saying no')]
for i,(t,sub) in enumerate(rows):
    y=5-i
    ax.add_patch(mp.FancyBboxPatch((0.03,y-0.34),0.94,0.68,boxstyle='round,pad=0.006,rounding_size=0.03',
                facecolor='white',edgecolor=GLOBAL if i in (3,5) else '#c9d4d0',
                linewidth=1.0 if i in (3,5) else 0.6))
    ax.text(0.06,y+0.13,t,fontsize=7.0,fontweight='bold',
            color=GLOBAL if i in (3,5) else INK,va='center')
    ax.text(0.06,y-0.13,sub,fontsize=5.9,color=MUTE,style='italic',va='center')
    ax.plot([0.50,0.94],[y-0.14,y-0.14],color='#c9d4d0',lw=0.6)
ax.set_xlim(0,1.0); ax.set_ylim(-0.7,5.6); ax.axis('off')
ax.set_title('The one-page position',fontsize=8.8,loc='left',x=0.0,pad=6)
source(fig,'Six lines. If you cannot fill the fourth, you do not have a position yet.',y=0.028)
fig.tight_layout(rect=[0,0.06,1,1]); finish(fig,'fig-b2-one-page')
