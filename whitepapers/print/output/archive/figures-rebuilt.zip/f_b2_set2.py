from common import *

# ---------- 4. The challenger ----------
fig,ax=plt.subplots(figsize=(4.3,2.5),dpi=300)
rows=[('NTUC FairPrice','the trusted default','the leader',GLOBAL,0.92),
      ('Sheng Siong','the deal','the challenger',DOM,0.62),
      ('Cold Storage, Meidi-ya','quality, imported','the premium tier',STATE,0.42)]
for i,(n,word,role,c,w) in enumerate(rows):
    y=2-i
    ax.barh([y],[w],color=c,height=0.42,alpha=0.85)
    ax.text(0.012,y+0.30,n,fontsize=7.2,fontweight='bold',color=INK)
    ax.text(w-0.02,y,f'"{word}"',ha='right',va='center',fontsize=7.0,color='white',
            fontweight='bold',style='italic')
    ax.text(1.0,y,role,ha='left',va='center',fontsize=6.4,color=MUTE)
ax.text(0.012,-0.72,'The challenger does not attack the leader\u2019s strength. It claims\nthe word the leader cannot own without contradicting itself.',
        fontsize=6.4,color=INK,linespacing=1.45)
ax.set_xlim(0,1.30); ax.set_ylim(-1.05,2.6); ax.axis('off')
ax.set_title('The challenger: take the word the leader cannot',fontsize=8.8,loc='left',x=0.0,pad=6)
source(fig,'Singapore grocery. Bar length is illustrative of mind-share, not measured share. Confidence: Low.',y=0.03)
fig.tight_layout(rect=[0,0.065,1,1]); finish(fig,'fig-b2-challengers')

# ---------- 5. The referral loop ----------
fig,ax=plt.subplots(figsize=(4.25,2.55),dpi=300)
steps=[('1','You own one word','sharp enough to be remembered',GLOBAL),
       ('2','The customer can say it','in one line, without you there',STATE),
       ('3','They tell someone else','because it is easy to pass on',DOM),
       ('4','That person arrives convinced','the sale is half made already','#5d6b7a')]
for i,(n,t,sub,c) in enumerate(steps):
    y=3-i
    ax.add_patch(mp.FancyBboxPatch((0.12,y-0.34),0.85,0.68,boxstyle='round,pad=0.008,rounding_size=0.05',
                facecolor=c,alpha=0.11,edgecolor=c,linewidth=0.8))
    ax.add_patch(mp.Ellipse((0.058,y),0.055,0.32,facecolor=c,edgecolor='none'))
    ax.text(0.058,y,n,ha='center',va='center',fontsize=6.8,fontweight='bold',color='white')
    ax.text(0.16,y+0.12,t,fontsize=7.2,fontweight='bold',color=INK,va='center')
    ax.text(0.16,y-0.14,sub,fontsize=6.0,color=MUTE,style='italic',va='center')
    if i<3: ax.annotate('',xy=(0.058,y-0.46),xytext=(0.058,y-0.31),
                        arrowprops=dict(arrowstyle='-|>',color=MUTE,lw=1.0))
ax.annotate('',xy=(1.005,3.0),xytext=(1.005,0.0),
            arrowprops=dict(arrowstyle='-|>',color=GLOBAL,lw=1.0,
                            connectionstyle='arc3,rad=-0.42'))
ax.text(1.10,1.5,'and the loop\nruns again',fontsize=6.2,color=GLOBAL,va='center',
        ha='center',linespacing=1.35)
ax.set_xlim(0,1.22); ax.set_ylim(-0.6,3.55); ax.axis('off')
ax.set_title('The referral loop',fontsize=8.8,loc='left',x=0.0,pad=6)
source(fig,'A word a customer cannot repeat is a word that cannot be referred. Author framework.',y=0.03)
fig.tight_layout(rect=[0,0.065,1,1]); finish(fig,'fig-b2-referral')

# ---------- 6. The word in the customer's mind ----------
fig,ax=plt.subplots(figsize=(4.2,2.4),dpi=300)
good=['the dementia specialist','the curry puff place','the deal','safe and reliable wells']
bad=['quality','service','value','innovation','trusted','excellence']
ax.text(0.02,0.90,'Words that get you chosen',fontsize=7.4,fontweight='bold',color=GLOBAL)
ax.text(0.02,0.80,'specific, ownable, repeatable',fontsize=6.2,color=MUTE,style='italic')
for i,w in enumerate(good):
    ax.add_patch(mp.FancyBboxPatch((0.02,0.60-i*0.155),0.44,0.115,
                boxstyle='round,pad=0.006,rounding_size=0.03',facecolor=LIGHT,edgecolor=GLOBAL,linewidth=0.7))
    ax.text(0.24,0.657-i*0.155,f'"{w}"',ha='center',va='center',fontsize=6.5,color=INK)
ax.text(0.54,0.90,'Words that get you ignored',fontsize=7.4,fontweight='bold',color=DOM)
ax.text(0.54,0.80,'everyone claims them, so nobody owns them',fontsize=6.2,color=MUTE,style='italic')
for i,w in enumerate(bad):
    x=0.54+(i%2)*0.23; y=0.60-(i//2)*0.155
    ax.add_patch(mp.FancyBboxPatch((x,y),0.21,0.115,boxstyle='round,pad=0.006,rounding_size=0.03',
                facecolor='#f5efe9',edgecolor=DOM,linewidth=0.6,alpha=0.8))
    ax.text(x+0.105,y+0.057,w,ha='center',va='center',fontsize=6.3,color=MUTE)
ax.set_xlim(0,1); ax.set_ylim(0.03,1.0); ax.axis('off')
ax.set_title('The word in the customer\u2019s mind',fontsize=8.8,loc='left',x=0.0,pad=4)
source(fig,'The test: could a customer repeat it in one breath, and would a competitor hesitate to claim it?',y=0.03)
fig.tight_layout(rect=[0,0.07,1,1]); finish(fig,'fig-b2-word')
