from common import *
import matplotlib; matplotlib.rcParams['text.usetex']=False; matplotlib.rcParams['mathtext.default']='regular'
cases=[('It widened','Ka-Soh, Tenderfresh','Owned a word, then\nadded everything else',DOM),
       ('The category died','Creative Technologies','Owned its word perfectly.\nUS\\$1.6bn in 1996 to\nUS\\$61m by 2022','#8a4b3a'),
       ('No demand under it','Thirsty4Balls','Flawlessly different.\nNobody wanted it.','#5d6b7a')]
fig,ax=plt.subplots(figsize=(4.35,2.5),dpi=300)
for i,(t,brands,sub,c) in enumerate(cases):
    x=i*1.0
    ax.add_patch(mp.FancyBboxPatch((x+0.04,0.10),0.92,0.80,boxstyle='round,pad=0.01,rounding_size=0.04',
                facecolor=c,alpha=0.10,edgecolor=c,linewidth=0.9))
    ax.text(x+0.50,0.79,t,ha='center',fontsize=7.4,fontweight='bold',color=c)
    ax.text(x+0.50,0.63,brands,ha='center',fontsize=6.4,style='italic',color=INK)
    ax.text(x+0.50,0.36,sub,ha='center',va='center',fontsize=5.9,color=MUTE,linespacing=1.45)
ax.set_xlim(0,3.0); ax.set_ylim(0,1.0); ax.axis('off')
ax.set_title('Where positioning fails: three ways a good word still loses',fontsize=8.8,loc='left',x=0.0,pad=6)
source(fig,'Sources: Straits Times, Business Times, company filings. See the failure-cases chapter.',y=0.035)
fig.tight_layout(rect=[0,0.09,1,1]); finish(fig,'fig-where-fails')
