from common import *
layers=[('1. The engine','Global, state, or domestic',GLOBAL),
        ('2. The wave','Ageing, fertility, care',STATE),
        ('3. The industry','Size, growth, data quality',DOM),
        ('4. The structure','Concentrated (a wall) or fragmented (a door)','#8a7f6d'),
        ('5. The names','Who already owns a word in your category','#5d6b7a'),
        ('6. The opening','The two or three words still free',INK)]
fig,ax=plt.subplots(figsize=(4.25,2.9),dpi=300)
for i,(t,sub,c) in enumerate(layers):
    y=5-i; w=0.34+0.115*i
    ax.add_patch(mp.FancyBboxPatch((0.06,y-0.33),w,0.66,boxstyle='round,pad=0.01,rounding_size=0.04',
                facecolor=c,edgecolor='none',alpha=0.92))
    ax.text(0.085,y+0.08,t,fontsize=7.2,fontweight='bold',color='white',va='center')
    ax.text(0.085,y-0.15,sub,fontsize=5.9,color='white',va='center',alpha=0.93)
ax.annotate('',xy=(0.035,-0.3),xytext=(0.035,5.4),arrowprops=dict(arrowstyle='-|>',color=MUTE,lw=1.0))
ax.text(0.012,2.5,'read in this order',rotation=90,va='center',ha='center',fontsize=6.2,color=MUTE)
ax.set_xlim(0,1.06); ax.set_ylim(-0.75,5.8); ax.axis('off')
ax.set_title('The six layers of the map',fontsize=9,loc='left',x=0.0,pad=6)
source(fig,'Each layer narrows the last. The sixth is where the second book begins. Author framework.',y=0.022)
fig.tight_layout(rect=[0,0.055,1,1]); finish(fig,'fig-six-layers')
