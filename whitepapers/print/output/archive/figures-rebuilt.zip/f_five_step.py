from common import *
steps=[('1','Know the competitive set','Who actually competes for your customer?'),
       ('2','Map the customer\u2019s mind','What word do they already associate with the category?'),
       ('3','Evaluate every way to stand out','Which differences can you actually win?'),
       ('4','Find the open slot, and the trap','Which word is free, and which only looks free?'),
       ('5','Decide the position and the plan','The one thing you will be known for, and the steps to hold it')]
fig,ax=plt.subplots(figsize=(4.3,2.85),dpi=300)
for i,(n,t,q) in enumerate(steps):
    y=4-i
    lead = (i==4)
    ax.add_patch(mp.FancyBboxPatch((0.10,y-0.36),0.87,0.72,boxstyle='round,pad=0.008,rounding_size=0.05',
                facecolor=GLOBAL if lead else LIGHT,edgecolor=GLOBAL,linewidth=0.7))
    ax.add_patch(mp.Ellipse((0.048,y),0.062,0.34,facecolor=GLOBAL,edgecolor='none'))
    ax.text(0.048,y,n,ha='center',va='center',fontsize=7.2,fontweight='bold',color='white')
    tc='white' if lead else INK
    ax.text(0.14,y+0.13,t,fontsize=7.3,fontweight='bold',color=tc,va='center')
    ax.text(0.14,y-0.14,q,fontsize=6.1,color=tc,style='italic',va='center',alpha=0.95)
    if i<4:
        ax.annotate('',xy=(0.048,y-0.44),xytext=(0.048,y-0.34),
                    arrowprops=dict(arrowstyle='-|>',color=GLOBAL,lw=1.1))
ax.set_xlim(0,1.02); ax.set_ylim(-0.65,4.55); ax.axis('off')
ax.set_title('The five-step process: from the ground to the word',fontsize=8.8,loc='left',x=0.0,pad=6)
source(fig,'Each step answers the question the last one raised. Author method.',y=0.025)
fig.tight_layout(rect=[0,0.055,1,1]); finish(fig,'fig-five-step')
