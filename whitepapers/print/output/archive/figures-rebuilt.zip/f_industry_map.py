from common import *
data=[('Wholesale trade',146.5,5.0,GLOBAL),('Manufacturing',137.6,8.7,GLOBAL),
      ('Finance & insurance',104.2,4.2,GLOBAL),('Professional svcs',41.8,4.2,DOM),
      ('Health & social',20.7,3.1,STATE),('Admin & support',18.4,3.1,DOM),
      ('Public admin',17.6,0.0,STATE),('Retail trade',9.0,5.0,DOM),
      ('Food & beverage',7.6,3.1,DOM)]
fig,ax=plt.subplots(figsize=(4.3,3.2),dpi=300)
OFF={'Wholesale trade':(-6,7,'right'),'Manufacturing':(-6,-14,'right'),
     'Finance & insurance':(6,-4,'left'),'Professional svcs':(-6,7,'right'),
     'Health & social':(0,9,'center'),'Admin & support':(0,-15,'center'),
     'Public admin':(6,-3,'left'),'Retail trade':(6,2,'left'),
     'Food & beverage':(0,9,'center')}
for n,v,g,c in data:
    ax.scatter(v,g,s=42,color=c,zorder=3,edgecolor='white',linewidth=0.6)
    dx,dy,ha=OFF[n]
    ax.annotate(n,(v,g),textcoords='offset points',xytext=(dx,dy),
                fontsize=6.3,ha=ha,color=INK)
ax.set_xscale('log'); ax.set_xlim(5,320); ax.set_ylim(-1.4,10.4)
ax.set_xlabel('Value added, S$ billion (log scale, 2024)',fontsize=7.5)
ax.set_ylabel('Five-year growth, % a year',fontsize=7.5)
ax.spines[['top','right']].set_visible(False); ax.tick_params(labelsize=6.8)
ax.set_xticks([10,30,100,300]); ax.set_xticklabels(['10','30','100','300'])
ax.axvline(30,color=MUTE,lw=0.6,ls=':')
ax.text(31,9.4,'engine layer  \u2192',fontsize=6.2,color=MUTE)
ax.text(28,9.4,'\u2190  domestic layer',fontsize=6.2,color=MUTE,ha='right')
ax.legend(handles=[mp.Patch(color=GLOBAL,label='Global'),mp.Patch(color=STATE,label='State'),
                   mp.Patch(color=DOM,label='Domestic')],frameon=False,fontsize=6.8,loc='lower left')
ax.set_title('The industry map: size against growth',fontsize=9,loc='left',pad=7)
source(fig,'Source: SingStat, value added by industry (SSIC), 2024; five-year CAGR. Confidence: High.')
fig.tight_layout(rect=[0,0.05,1,1]); finish(fig,'fig-industry-map')
