from common import *
fig,ax=plt.subplots(figsize=(4.3,3.1),dpi=300)
cells=[(0,1,'DEFENCE',"You are the leader",'Concentration:\nthe top few hold the share','Attack yourself before\na challenger does',GLOBAL),
       (1,1,'OFFENCE',"You are the challenger",'A leader with a\nweakness in its strength','Attack that weakness\non a narrow front',STATE),
       (0,0,'FLANK',"You create the category",'Fragmentation:\nno one owns the category','Move into uncontested\nground and defend it',DOM),
       (1,0,'GUERRILLA',"You are the small player",'A corner the big\nplayers cannot serve','Own a niche small\nenough to hold','#5d6b7a')]
for x,y,name,who,cond,move,c in cells:
    ax.add_patch(mp.FancyBboxPatch((x+0.03,y+0.03),0.94,0.94,boxstyle='round,pad=0.005,rounding_size=0.03',
                facecolor=c,alpha=0.10,edgecolor=c,linewidth=1.0))
    ax.text(x+0.5,y+0.83,name,ha='center',fontsize=8.4,fontweight='bold',color=c)
    ax.text(x+0.5,y+0.68,who,ha='center',fontsize=6.4,style='italic',color=INK)
    ax.text(x+0.5,y+0.45,cond,ha='center',fontsize=6.2,color=INK,linespacing=1.35)
    ax.text(x+0.5,y+0.17,move,ha='center',fontsize=6.2,color=MUTE,linespacing=1.35)
ax.text(-0.09,1.5,'You lead the category',rotation=90,va='center',ha='center',fontsize=6.6,color=MUTE)
ax.text(-0.09,0.5,'You do not',rotation=90,va='center',ha='center',fontsize=6.6,color=MUTE)
ax.text(0.5,-0.13,'Category has an owner',ha='center',fontsize=6.6,color=MUTE)
ax.text(1.5,-0.13,'Category is contested',ha='center',fontsize=6.6,color=MUTE)
ax.set_xlim(-0.2,2.05); ax.set_ylim(-0.28,2.05); ax.axis('off')
ax.set_title('The four postures, and the structure each requires',fontsize=8.8,loc='left',x=-0.02,pad=6)
source(fig,'Postures after Ries and Trout, Marketing Warfare (1986); structural conditions mapped to\nSingapore industry data in Small Island, Crowded Market. Author analysis.',y=0.018)
fig.tight_layout(rect=[0,0.075,1,1]); finish(fig,'fig-four-postures')
