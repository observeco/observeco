from common import *
import numpy as np
inds=['Health &\nsocial','Professional\nservices','Education /\ntuition','Personal\nservices','Admin &\nsupport','Retail','Food &\nbeverage']
# five forces scored 0=low pressure (friendly) .. 2=high pressure (brutal), from Table 20.1
scores=[[0,0,1,0,0],[1,0,1,1,1],[2,0,1,2,2],[2,0,1,1,2],[2,0,2,2,2],[2,1,2,2,2],[2,2,2,2,2]]
tot=[sum(r) for r in scores]
cols=[GLOBAL if t<=4 else (STATE if t<=7 else DOM) for t in tot]
fig,ax=plt.subplots(figsize=(4.3,2.9),dpi=300)
ax.barh(range(len(inds))[::-1],tot,color=cols,height=0.6)
for y,t in zip(range(len(inds))[::-1],tot):
    ax.text(t+0.15,y,str(t),va='center',fontsize=7.4,fontweight='bold')
ax.set_yticks(range(len(inds))[::-1]); ax.set_yticklabels(inds,fontsize=6.9)
ax.set_xlim(0,11.6); ax.set_xticks([0,2,4,6,8,10])
ax.set_xlabel('Competitive pressure score (0 = friendly, 10 = brutal)',fontsize=7.3)
ax.spines[['top','right']].set_visible(False); ax.tick_params(axis='x',labelsize=6.8)
ax.axvline(4.5,color=MUTE,lw=0.6,ls=':'); ax.axvline(7.5,color=MUTE,lw=0.6,ls=':')
ax.text(2.2,6.65,'friendlier',fontsize=6.3,color=MUTE,ha='center')
ax.text(6.0,6.65,'mixed',fontsize=6.3,color=MUTE,ha='center')
ax.text(9.4,6.65,'brutal',fontsize=6.3,color=MUTE,ha='center')
ax.set_ylim(-0.6,7.3)
ax.set_title('Friendly or brutal: the five-force score by industry',fontsize=8.6,loc='left',pad=7)
source(fig,'Five forces scored low/moderate/high (0/1/2) from Table 20.1: entry, supplier power,\nbuyer power, substitution, price rivalry. Author analysis on SingStat and ACRA data. Confidence: Moderate.', y=0.022)
fig.tight_layout(rect=[0,0.13,1,1]); finish(fig,'fig-friendly-brutal')
