import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
import matplotlib.patches as mp

rcParams['font.family']='DejaVu Serif'
rcParams['font.size']=8
rcParams['axes.linewidth']=0.7
rcParams['xtick.major.width']=0.7
rcParams['ytick.major.width']=0.7

GLOBAL='#1b6b57'; STATE='#7a8ba6'; DOM='#b5651d'
INK='#1a1a1a'; MUTE='#666666'; LIGHT='#d8e3df'

def source(fig, text, y=0.012):
    fig.text(0.015, y, text, fontsize=5.8, color=MUTE)

def finish(fig, name):
    fig.savefig(f'{name}.pdf', bbox_inches='tight', pad_inches=0.035)
    fig.savefig(f'{name}.png', dpi=300, bbox_inches='tight', pad_inches=0.035)
    plt.close(fig)
    return name
