from common import *
fig,ax=plt.subplots(figsize=(4.3,2.6),dpi=300)
labels=['TradersGPS\n(Collin Seow)','White-labelled\nidentical system']
price=[100,55]; share=[100,4]
x=[0,1]; w=0.32
ax.bar([i-w/2 for i in x],price,width=w,color=STATE,label='Relative price')
ax.bar([i+w/2 for i in x],share,width=w,color=GLOBAL,label='Relative customers won')
for i,(p,s) in enumerate(zip(price,share)):
    ax.text(i-w/2,p+2.5,f'{p}',ha='center',fontsize=7,fontweight='bold')
    ax.text(i+w/2,s+2.5,f'{s}',ha='center',fontsize=7,fontweight='bold')
ax.set_xticks(x); ax.set_xticklabels(labels,fontsize=7)
ax.set_ylabel('Indexed to the incumbent = 100',fontsize=7.2)
ax.set_ylim(0,118); ax.spines[['top','right']].set_visible(False); ax.tick_params(labelsize=6.8)
ax.legend(frameon=False,fontsize=6.8,loc='upper right')
ax.annotate('Same algorithm.\nHalf the price.\nThe word still won.',xy=(1.16,52),fontsize=6.6,
            color=DOM,ha='center',va='center',linespacing=1.4)
ax.set_title('Price cannot buy a word',fontsize=9,loc='left',pad=6)
source(fig,'Author\u2019s own experience at AlgoMerchant, 2021\u201323. Indexed illustration of a real outcome;\nthe figures are directional, not audited. Confidence: Low.',y=0.02)
fig.tight_layout(rect=[0,0.10,1,1]); finish(fig,'fig-price-vs-word')
