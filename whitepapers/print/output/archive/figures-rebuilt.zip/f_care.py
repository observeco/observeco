from common import *
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.3,2.5),dpi=300,gridspec_kw={'width_ratios':[1,1.15]})
yrs=[2015,2020,2025]; share=[13.1,16.8,20.7]
a1.plot(yrs,share,color=GLOBAL,lw=1.8,marker='o',ms=4)
for x,y in zip(yrs,share): a1.annotate(f'{y}%',(x,y),textcoords='offset points',xytext=(0,8),ha='center',fontsize=6.8,fontweight='bold')
a1.set_ylim(9,26); a1.set_xticks(yrs); a1.set_ylabel('Citizens aged 65+, %',fontsize=7)
a1.set_title('The demand: one in five',fontsize=7.6,pad=5)
a1.spines[['top','right']].set_visible(False); a1.tick_params(labelsize=6.6)

cats=['Total senior\nspending power\n(headline)','Addressable\npaid-care market\n(what a business\ncan actually sell)']
vals=[97.0,0.85]
b=a2.bar([0,1],vals,color=[LIGHT,DOM],width=0.5,edgecolor=MUTE,linewidth=0.6)
a2.set_yscale('log'); a2.set_ylim(0.3,300)
for x,v,lab in zip([0,1],vals,['S$97bn','S$0.28–0.85bn']):
    a2.text(x,v*1.35,lab,ha='center',fontsize=7,fontweight='bold')
a2.set_xticks([0,1]); a2.set_xticklabels(cats,fontsize=6.2)
a2.set_ylabel('S$ billion (log scale)',fontsize=7)
a2.set_title('The trap: headline vs addressable',fontsize=7.6,pad=5)
a2.spines[['top','right']].set_visible(False); a2.tick_params(axis='y',labelsize=6.6)
fig.suptitle('The care economy',fontsize=9,x=0.015,ha='left',y=0.96)
source(fig,'Source: Population.gov.sg (65+ share), High. Addressable paid-care market: author estimate, Low.')
fig.tight_layout(rect=[0,0.075,1,0.94]); finish(fig,'fig-care-economy')
