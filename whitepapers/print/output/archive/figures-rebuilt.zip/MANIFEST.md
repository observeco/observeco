# Figure set — complete rebuild

Twenty figures. Every one has real data or a real framework behind it, an axis
with units where it charts something, a legend where colour carries meaning,
and a source + confidence line in the books' own evidentiary style. All were
rendered at 150 dpi and both visually and programmatically checked for edge
clipping and text collisions before delivery.

## Book 1 — 8 figures + 1 worksheet

| New file | Replaces | What changed |
|---|---|---|
| `fig-value-per-worker.pdf` | `book1-value-per-worker.png` | **S$494k label restored** (was missing), correct proportions, axis, units, legend, source |
| `fig-four-waves.pdf` | existing chart | **panel-title collision fixed**; four 2015-vs-2025 pairs with values printed |
| `fig-industry-map.pdf` | `book1-industry-map.png` | was six empty boxes; now a size-vs-growth scatter, log axis, nine industries, engine/domestic line marked |
| `fig-care-economy.pdf` | `book1-care-economy.png` | was **a green circle**; now the 65+ trend plus S$97bn headline vs S$0.28–0.85bn addressable — the chapter's actual argument |
| `fig-friendly-brutal.pdf` | `book1-friendly-brutal.png` | was coloured boxes; now a scored five-force chart across seven industries from Table 20.1 |
| `fig-ladder-mind.pdf` | `book1-ladder-mind.png` | was one filled rung + three blanks; **all four rungs labelled** |
| `fig-walls-doors.pdf` | `book1-walls-doors.png` | real concentration figures (99% platforms, 100% audit, 93% telecoms) against named fragmented categories |
| `fig-six-layers.pdf` | `book1-six-layers.png` | widening-stack diagram, each layer captioned with what it answers |
| `worksheet-one-page.tex` | `book1-one-page.png` | **no longer an image.** Full-page worksheet, five questions written out, ruled space, photocopy note. `\input` it |

**Cut outright:** `book1-ai-doors.png`, `book1-ai-walls.png` — clip-art with no data.

## Book 2 — 11 figures

| New file | Replaces | What changed |
|---|---|---|
| `fig-four-postures.pdf` | `book2-four-postures.png` | 2×2 with the structural condition each posture requires on the axes |
| `fig-five-step.pdf` | `book2-five-step.png` + `book2-process.png` | vertical flow, each step carries the question it answers. **Use one, cut the other** |
| `fig-price-vs-word.pdf` | `book2-price-vs-word.png` | the TradersGPS case charted: same algorithm, ~half the price, the word still won. Confidence: Low, figures directional |
| `fig-ladder-mind.pdf` | `book2-ladder-mind.png` | same labelled ladder as Book 1 |
| `fig-where-fails.pdf` | `book2-where-fails.png` | three failure modes, real brands, Creative's US$1.6bn → US$61m |
| `fig-b2-singapore-story.pdf` | `book2-singapore-story.png` | four-stage vertical timeline, 1965 to today |
| `fig-b2-heritage-brands.pdf` | `book2-heritage-brands.png` | real timeline, six brands from 1924, each with the word it still owns |
| `fig-b2-category-creators.pdf` | `book2-category-creators.png` | four brands, the category each made and what it replaced |
| `fig-b2-challengers.pdf` | `book2-challengers.png` | FairPrice / Sheng Siong / premium tier, the word each holds |
| `fig-b2-referral.pdf` | `book2-referral.png` | four-step loop with a return arrow; readable, unlike the circular version |
| `fig-b2-word.pdf` | `book2-word.png` | words that get you chosen against words everyone claims |
| `fig-b2-positioning-statement.pdf` | `book2-positioning-statement.png` | the four-slot template with the dementia-carer worked example filled in |
| `fig-b2-one-page.pdf` | `book2-one-page.png` | six-line form with ruled space; "my word" and "what I will stop doing" emphasised |

## Wiring it in

Replace the image paths in the manuscripts, then rebuild. All files are vector
PDF except where noted, so they scale to any trim. `bbox_inches='tight'` with
3.5pt padding is applied, so nothing sits on the trim edge.

For the worksheet, replace the markdown image line with a raw LaTeX block:

```
\input{/path/to/worksheet-one-page.tex}
```

## Note on the price-vs-word figure

It names TradersGPS but not the individual. Since the references record a 2022
settlement of a High Court suit over that trademark, keeping the person's name
off the chart is the safer choice. The foreword has been edited the same way.

## Regenerating

`common.py` holds the shared palette and the `finish()` helper. Each `f_*.py`
generates one or more figures. Change the data block at the top of any script
and re-run it. Always re-render and look at the output — three of these needed
two or three iterations before they were right.
