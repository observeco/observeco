from common import *
rungs=[('The name they recall','first, trusted, defaults to',GLOBAL,'white'),
       ('The one they compare to','considered, needs a reason',STATE,'white'),
       ('The one they have heard of','recognised, rarely chosen',LIGHT,INK),
       ('Everyone else','not in the mind at all','#f0f0f0',MUTE)]
fig,ax=plt.subplots(figsize=(4.2,2.6),dpi=300)
for i,(t,sub,fc,tc) in enumerate(rungs):
    y=3-i
    ax.add_patch(mp.FancyBboxPatch((0.16,y-0.34),0.68,0.68,boxstyle='round,pad=0.02,rounding_size=0.05',
                 facecolor=fc,edgecolor=MUTE,linewidth=0.6))
    ax.text(0.50,y+0.06,t,ha='center',va='center',fontsize=7.4,fontweight='bold',color=tc)
    ax.text(0.50,y-0.17,sub,ha='center',va='center',fontsize=6.2,color=tc,style='italic')
for x in (0.13,0.87):
    ax.plot([x,x],[-0.5,3.5],color=MUTE,lw=1.0)
ax.annotate('',xy=(0.06,3.2),xytext=(0.06,-0.2),arrowprops=dict(arrowstyle='-|>',color=INK,lw=1.0))
ax.text(0.035,1.5,'share of the category',rotation=90,va='center',ha='center',fontsize=6.4,color=MUTE)
ax.text(0.90,3,'own this rung',fontsize=6.6,color=GLOBAL,va='center',fontweight='bold')
ax.set_xlim(0,1.20); ax.set_ylim(-0.6,3.75); ax.axis('off')
ax.set_title('The ladder of the mind',fontsize=9,loc='left',x=0.0,pad=6)
source(fig,'The mind ranks a category and defaults to the top rung. Author framework.',y=0.02)
fig.tight_layout(rect=[0,0.05,1,1]); finish(fig,'fig-ladder-mind')
