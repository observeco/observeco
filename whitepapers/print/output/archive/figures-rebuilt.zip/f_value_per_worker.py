from common import *
labels=['Wholesale\ntrade','Finance &\ninsurance','Education,\nhealth (state)','Public admin\n(state)','Retail\ntrade','Food &\nbeverage']
vals=[494,436,150,116,58,32]
cols=[GLOBAL,GLOBAL,STATE,STATE,DOM,DOM]
fig,ax=plt.subplots(figsize=(4.2,3.0),dpi=300)
b=ax.barh(range(len(vals))[::-1],vals,color=cols,height=0.6)
for y,v in zip(range(len(vals))[::-1],vals):
    ax.text(v+9,y,f'S${v}k',va='center',fontsize=7.8,fontweight='bold',color=INK)
ax.set_yticks(range(len(labels))[::-1]); ax.set_yticklabels(labels,fontsize=7.2)
ax.set_xlabel('Value added per worker, S$ thousands (2024)',fontsize=7.5)
ax.set_xlim(0,585); ax.spines[['top','right']].set_visible(False)
ax.tick_params(axis='x',labelsize=7)
ax.legend(handles=[mp.Patch(color=GLOBAL,label='Global engine'),
                   mp.Patch(color=STATE,label='State engine'),
                   mp.Patch(color=DOM,label='Domestic engine')],
          frameon=False,fontsize=7,loc='lower right')
ax.set_title('Value per worker, by engine',fontsize=9,loc='left',pad=7,color=INK)
source(fig,'Source: SingStat, value added per worker by industry, 2024. Confidence: High.')
fig.tight_layout(rect=[0,0.05,1,1]); finish(fig,'fig-value-per-worker')
