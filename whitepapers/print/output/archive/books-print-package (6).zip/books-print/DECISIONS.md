# Decisions — ask Sean, do not decide these yourself

Each of these changes the book, not the build. If one blocks you, stop and ask.

## 1. openright or openany — this is the blank-page question

The convention in the current build is `openright`: a chapter opens on a
right-hand page, so when the previous chapter ends on a right-hand page, a blank
left-hand page is inserted. That accounts for 20 of Book 1's 28 blanks and 19 of
Book 2's 28. They are not a fault and no code change removes them.

Measured, both ways, same content:

| | openright | openany |
|---|---|---|
| Book 1 | 268 pp, 28 blank, spine 10.9 mm | 244 pp, 4 blank, spine 9.9 mm |
| Book 2 | 256 pp, 28 blank, spine 10.4 mm | 232 pp, 4 blank, spine 9.4 mm |

`openany` costs 24 pages less per book and prints cheaper. It also means some
chapters open on a left-hand page, which reads as less formal. Trade paperbacks
go both ways.

The switch is one word in `build/build_latex.py`:
`\documentclass[10pt,twoside,openright]{memoir}` → `openany`.

If Sean picks `openany`, `verify_final.py` check 2 must be inverted — it
currently fails any chapter opening on a verso, which is exactly what openany
allows. Change the check, do not delete it.

## 2. Book 1's empty "Sources & confidence" chapter

`manuscripts/book1.md` line 2302: the heading for Part Five's sources section
runs straight into `# PART SIX` with no body. Every other part has one. The text
appears to have been lost, not omitted. Either it gets restored or the heading
gets cut. Do not invent sources text.

## 3. Book 1's worksheet chapter

Chapter 39, "The one-page self-assessment", opens with the title alone and the
worksheet on the page after. Probably deliberate — the worksheet wants a clean
page to be photocopied from. `verify_final.py` flags it. Confirm before
"fixing" it.

## 4. The three-engines figure

`fig-three-engines.pdf` is not in the figure set, and the reference to it was
removed from `book1.md`. In the earlier build it was the same value-per-worker
bar chart that appears one chapter later as Figure 4.1, captioned differently.
Either a real three-engines figure gets made, or Chapter 3 stays without one.

## 5. Table wording shortened in an earlier round

Four table cells were shortened to clear severe overfulls, e.g.
"Compensation-of-employees share of GDP" → "Employee share of GDP". Those stand.
Do not shorten further cells to chase the remaining 5–15pt overfulls without
asking; those are cosmetic and do not lose content.

---

## Do not

- Delete blank pages from a finished PDF. Removing one page flips every page
  after it from recto to verso and puts chapter openings on the wrong side.
  Blanks are fixed in the source or not at all.
- Change wording, cut cells, or reflow content to hit a page count. Page count
  follows the text; the spine follows the page count.
- Report page counts or spine widths from any build other than the one going to
  the printer.
- Weaken `run_build.sh`'s error check or the stale-PDF deletion.
