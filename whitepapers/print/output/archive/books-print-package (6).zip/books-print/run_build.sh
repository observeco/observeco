#!/usr/bin/env bash
# Build one book and fail loudly. The old pipeline kept a stale PDF when a pass
# died and still printed "Built"; that is how a failed build reached a printer.
set -euo pipefail
BOOK="${1:?usage: run_build.sh book1|book2}"
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HERE/out"
rm -f "$HERE/out/$BOOK-FINAL.pdf" "/tmp/$BOOK-print.pdf"

# OPENANY=1 builds with chapters allowed to open on either side, which removes
# the ~20 blank versos per book that the openright convention requires.
if [ "${OPENANY:-0}" = "1" ]; then
    sed -i.bak 's/twoside,openright/twoside,openany/' "$HERE/build/build_latex.py"
    trap 'mv -f "$HERE/build/build_latex.py.bak" "$HERE/build/build_latex.py"' EXIT
fi

python3 "$HERE/build/build_latex.py" "$BOOK"

if grep -q '^! ' "/tmp/$BOOK.log" 2>/dev/null; then
    echo "FAILED: xelatex reported errors:" >&2
    grep -n '^! ' "/tmp/$BOOK.log" | head -20 >&2
    exit 1
fi
[ -s "/tmp/$BOOK-print.pdf" ] || { echo "FAILED: no PDF produced" >&2; exit 1; }
cp "/tmp/$BOOK-print.pdf" "$HERE/out/$BOOK-FINAL.pdf"
echo "built $HERE/out/$BOOK-FINAL.pdf"
