# Tools worth having, in order of how much they raise the odds

Sean asked what to install. This is the honest ranking for a coding agent
driving a LaTeX book build.

## 1. git — the single biggest win

    cd books-print && git init && git add -A && git commit -m "baseline v2"

Without it, an agent's edits are invisible and irreversible, and a bad change
buried in a 700-line build script is very hard to find later. With it, you get:

- one commit per fix, each with the verify output in the message
- `git diff` as the review surface instead of the agent's prose summary
- `git revert` when a change makes things worse
- `git stash` so a half-finished experiment does not contaminate a build

Tell the agent: commit after each check goes green, never amend a commit that
has been reported.

## 2. latexmk — removes the class of bug that caused all of this

    brew install texlive     # or use MacTeX, which bundles latexmk

`latexmk -xelatex` works out how many passes are needed and runs `makeindex`
and `bibtex` itself, at the right point, until the aux files stop changing. The
whole index failure — makeindex never called, `\printindex` reading a stale
`.ind` from `/tmp` — is a bug latexmk cannot have, because the ordering is its
job rather than the script's.

Porting the build to latexmk is a contained change to one function and I would
do it before handing the pipeline to an agent for a long run.

## 3. poppler — `gate.py` needs it

    brew install poppler

Provides `pdftotext`, `pdftoppm`, `pdfimages`. `verify_final.py` needs only
pypdf, but `gate.py`'s figure-clipping and overfull checks need poppler.

## 4. diff-pdf or ImageMagick — catch layout regressions the checks miss

    brew install diff-pdf          # or: brew install imagemagick

Every check in `verify_final.py` is structural. None of them can see that a
table now overlaps a figure, or that the index font changed. A page-image diff
against `reference/` catches that in one command:

    diff-pdf --output-diff=diff.pdf reference/book1-v2.pdf out/book1-FINAL.pdf

Give the agent the previous build as a reference and require a visual diff when
a change touches the template. This is the check that would have caught a
silently-substituted font.

## 5. A real timeout-and-poll wrapper for long builds

A book build runs several minutes and can hang outright — the `\StrLen`-in-a-mark
bug spun xelatex at 100% CPU indefinitely, and only a timeout distinguishes that
from slow progress. Your cron plumbing already does background jobs; make sure
the agent runs builds under a hard timeout (10 minutes is generous) and treats a
timeout as a failure to diagnose, not a reason to retry.

## 6. Charter — required for the real page counts

The Mac build uses Bitstream Charter. Everything I built uses TeX Gyre Pagella,
because Charter's bold crashes the PDF driver on accented characters in the
Linux container. Page counts and spine widths differ between the two. Make sure
Charter is installed and `build_latex_MAC.py` is the script that produces
anything going to a printer.

## Optional, later

- **Ghostscript** (`brew install ghostscript`) for PDF/X-1a output if the
  printer asks for it. Most print-on-demand services accept plain PDF.
- **A second reader.** After nine rounds of screen review, the check that has
  never been done is a printed proof. No tool substitutes.

## What not to bother with

- A LaTeX GUI or editor integration. The agent runs `make`.
- Docker. The build is already reproducible enough given a pinned TeX Live.
- Any "PDF repair" or page-removal utility. Removing pages from the finished
  PDF breaks recto/verso parity and leaves the contents and index pointing at
  the wrong pages.
