# Small Island, Crowded Market

## What every Singapore business owner should know about the ground they compete on

**Sean Foo, founder of ObserveCo**
**Evidence as of:** August 2026 · All figures confidence-labeled · Sources in each chapter appendix

---

**Copyright © 2026 Sean Foo. All rights reserved.**

No part of this book may be reproduced, stored in a retrieval system, or transmitted in any form or by any means, electronic, mechanical, photocopying, recording, or otherwise, without the prior written permission of the author, except for brief quotations in a review.

This book is intended to inform and educate. It is not professional, financial, legal, or investment advice. The market figures and brand facts are drawn from the sources listed in the references and appendix, are confidence-labeled, and should be verified against primary sources before any business decision. The author is not affiliated with, endorsed by, or connected to any of the brands discussed, and the discussion of them is independent commentary.

**ISBN:** [to be assigned at publication]

---

## For the reader

These two books are for the aspiring entrepreneurs and the hardworking small Singapore business owners waiting to make their mark. The first book, *Small Island, Crowded Market*, shows you the ground you compete on. This second book, *How a Small Business Gets Chosen*, shows you the move. Read them in order, and you will know both where the money is and how to claim a share of it.

---

## Foreword

I have spent my working life inside the problem these books are about, and I want to tell you that plainly before we begin, because it is the reason you should trust what follows.

I started my career in 2008, in a niche industry called Well Engineering, with a wells consultancy based in Singapore called Stuart Wright. I chose a specialised path, and it took me around the world and up through the ranks into senior management. I saw what it felt like to be a company you could count on one hand, and I watched us scale to more than forty employees across Singapore and Australia. I have been the professional inside a company, and I have been the one who had to decide what the company would become.

I write this foreword for the people I have met in every industry I have worked in: the mid-career professional who has given years to a company and now feels the ground shifting under them; the one who fears for their job as the machines get smarter; the one with an entrepreneurial spirit who has been waiting for permission to come out on their own. I know that fear. I have felt it. And I am writing to tell you that the fear, while real, is pointing you in the wrong direction.

Artificial intelligence and technology have been a major force of disruption, and they have cost people their jobs. That is true, and it would be dishonest to pretend otherwise. But it is only half the story. The same age of AI ushers in a wave of new opportunities, and they are opportunities of a kind this country has never seen before.

Think about what it took to start a business in the past. Our ancestors could create a business with a cheap push cart. That was the barrier to entry: a cart, a product, and the will to stand in the sun. The cost of starting was low, but the ceiling was low too, because a push cart can only reach the people who walk past it.

Now look at what it takes today. With AI, the cost of starting a business is, in a real sense, the cost of electricity running through tokens. The tools that used to require a team, the marketing, the design, the accounting, the customer service, can now be done by one person with a subscription. In an expensive place like Singapore, where rent and salaries have always been the wall that kept the small out, this matters more than anywhere else. The two most expensive inputs a small business used to need, people and premises, are the two that AI has made optional at the start.

Never in recent history has it been as easy as it is now to create your own business. The barrier is no longer capital. It is no longer a team. It is the willingness to dare.

Lee Kuan Yew, the man who built this country, spoke to the young and the not-so-old in exactly these words: "For the young, let me tell you the sky has turned brighter. There's a glorious rainbow that beckons those with the spirit of adventure. And there are rich findings at the end of that rainbow. To the young and to the not-so-old, I say, look at that horizon, follow that rainbow, go ride it. Not all will be rich; quite a few will find a vein of gold; but all who pursue that rainbow will have a joyous and exhilarating ride and some profit."

He was not promising everyone a fortune. He was promising everyone who dares a ride worth taking, and some profit at the end of it. That is the honest promise, and it is the one these books make too.

That is what these books are for. They are the map and the method for the person who is ready to stop fearing the disruption and start using it. If that is you, read on. The ground is mapped, the move is written, and the only thing left is the decision to take it.

---


---

# PART ONE, THE SINGAPORE BUSINESS LANDSCAPE

## What this book is

This book, the first of two, is the map. It shows how Singapore's small business market actually works: where the money comes from, how the country is changing, which industries a small business can win in, which names own the money, and how artificial intelligence is reshaping the whole ground. It is written for the person who actually runs a business and is trying to make it grow: the second-generation owner taking over the family trade, the manager of a small firm, the professional considering a business of their own, the founder with a few staff. It uses real Singapore data and real Singapore brands, and it is in plain language, not business-school jargon.

The second book, *How a Small Business Gets Chosen*, is the method. It takes this map and shows how a small business uses it to find and own a position, the word in the customer's mind. This first book gives you the ground; the second gives you the move.

The six chapters of this book are the six maps of the Singapore market, in order. They build on each other. The first maps where the money is. The second maps who the people are and how they are changing. The third maps every industry. The fourth maps which names own the money. The fifth maps how AI is changing the ground. The sixth, the decision line, draws the line between what the map can tell you and where you must do the deeper work of finding your own position.

Read them in order, because each one answers the question the last one raised. The map is the market, and this book draws it with the data, and with the caveats, so that a small business owner can see the ground they are actually standing on.
## How to use this map

Before the maps begin, it is worth saying plainly how to use them, because a map is only useful if you know how to read it, and there is a right way and a wrong way to read this book.

**Read it to understand your ground, not to find your answer.** This book tells you where the money is, who the people are, which industries a small business can win in, which names own the money, and how AI is changing it all. It does not tell you your specific position, that depends on your specific market, and it is the work of the second book. Read this book to understand the ground you are standing on, so that when you do the deeper work, you are not standing in the dark.

**Read it with the data in mind, not just the story.** Every claim in this book is tied to a verified number, and every number is confidence-labeled, high, moderate, or low. When you read a claim, ask how confident the number behind it is. A high-confidence number is ground you can build on. A moderate or low one is a direction, not a fact. The discipline of the data is the discipline of this whole series: never build a plan on a number you have not verified.

**Read it in order.** The six maps build on each other. The first shows where the money is; the second shows who the people are and how they are changing; the third maps every industry; the fourth maps which names own the money; the fifth maps how AI is changing the ground; the sixth draws the line between what the map can tell you and where you must go deeper. They are not six separate documents; they are one map, drawn in six layers. Read them in order, and each one answers the question the last one raised.

**Read it for the small business, not the headline.** The headline says the economy is booming, and it is, at the top. But this book is about the domestic, small-business layer, where most Singaporeans live and work, where the margins are thin and the competition is dense. The most important thing this book does is separate the booming headline from the ground where a hawker, a tuition centre, or a salon actually operates. Keep your eye on that layer, because it is the one you are in.

**Read it honestly, including the parts that do not flatter you.** This map is not a pep talk. It will tell you that the market is dense, capped, and dominated by a few names. It will tell you that most small businesses fail to survive. It will tell you the data is sometimes not good enough to act on. Read that, because a plan built on a flattering lie fails, and a plan built on a true, hard picture has a chance.

So read it as a map: to see the ground, to know the data, to understand the structure, and to be ready for the work of the second book, which is where you find your position on this ground.

---

## Reading numbers honestly, the skill this whole book is built on

Every map in this book is built on numbers, and every number carries a confidence label, high, moderate, or low. This chapter teaches you the skill underneath the whole book: how to read a number honestly, so you never build a plan on a figure you have not understood. It is the most transferable skill you will take from this book, because it works on every market, not just Singapore.

### The first question, where does the number come from?

The first thing to ask about any number is not what it says but where it came from. Is it a primary source, the government agency that actually measured it, like SingStat or the Ministry of Manpower? Is it a secondary source, a newspaper or a consultancy reporting someone else's number? Or is it a derived estimate, a number someone built by combining other figures?

The source tells you how much to trust it. A primary number is ground you can build on. A secondary number is directionally useful but one step from the source. A derived estimate is a reasoned number, useful for seeing where to look but not for building a precise plan. The discipline is to know which you are looking at before you act on it.

### The second question, is it current?

A number is a photograph of a moment, and markets move. A figure that was accurate last year may be wrong today. The second question is always: how old is this number, and has the market moved since it was measured? In a market where the economy grows and the population changes every quarter, a stale number is a false guide. The move is to check the date, and to prefer the most recent verified figure.

### The third question, what does it actually measure?

The hardest and most important question is what the number really measures, because the headline often says more than the number means. This book will show you this again and again. You will see that the "senior spending power" headline is not a market a business can enter; the real addressable care layer is far smaller. The "S$72 billion" is total spending power, not a business. The average household hides the diversity of the composition. The number measures something specific, and reading it honestly means asking exactly what.

The practical rule: when you see a big impressive number, ask what it actually measures and whether a small business can sell into it. Often the impressive number is a whole economy, and the layer a business can actually own is a small slice of it.

### The fourth question, is it one number or a range?

The honest answer is often a range, not a precise figure. Where sources disagree, or where a number is derived, the truthful statement is a range with the reason. This book does that, it gives the range and the reason, never a fabricated single number. The discipline for the reader is the same: prefer the range over the false precision. A range you understand is worth more than a single number you do not.

### The skill is the discipline

Reading numbers honestly is a discipline, not a technique. It is the habit of asking, before you trust any number: where did it come from, is it current, what does it measure, and is it one number or a range? The owner who runs that habit on every figure they meet does not get fooled by a headline, does not build a plan on a stale number, and does not mistake an impressive economy for a market they can enter.

This is the skill this book is built on, and it is the skill you take with you. The maps in this book are drawn with it, every number confidence-labeled, every claim traced to a source, every estimate flagged as an estimate. And it is the skill you apply to your own market, when you go to verify the slot the map points to, before you commit.

---


## Two economies, one island, and the quiet structure that decides who wins







---

There is a hawker in Toa Payoh who has been frying the same kway teow for thirty years. His rice is good. He works harder than almost anyone you know, up before dawn, cooking through the lunch crush, closing only when the last bowl is wiped clean and the metal counter hosed down for the night. And yet, some months, he looks at his takings and asks the question that haunts a very large part of Singapore: *if I work this hard, why am I not getting richer?*

He is not alone. There is a boutique studio in a HDB estate. There is a family-run clinic on the second floor of a shophouse. There is a tuition centre in a heartland mall, and a man who repairs watches in a coffeeshop that has not changed its signboard since the nineties. They all work hard. They are all, in the official statistics, part of "the Singapore economy." And they are all, in a way that is never quite explained to them, on a completely different boat from the one the headlines describe.

The headlines say the economy is booming. And the numbers say the headlines are right.

| What Singapore is | Value | Source | Confidence |
|---|---|---|---|
| Gross domestic product (2025) | **S$789.5 billion** | SingStat | High |
| Real GDP growth (2025) | **+5.0%** | SingStat | High |
| Foreign direct investment stock | **S$3,130.4 billion** (2024) | SingStat | High |
| Trade-to-GDP ratio | **~320%** | World Bank | High |
| World competitiveness rank | **#1 globally (2026)** | IMD | High |

Read what a few of those rows are really telling you. Foreign direct investment is the money foreign companies have parked in this country, and at S$3.1 trillion it is more than four times the size of Singapore's entire annual economy. Trade, everything the island buys and sells across its borders, runs at roughly three times the size of the economy, one of the highest ratios anywhere on earth. When a country's numbers look like that, its name gets spoken in the same sentence as "miracle" and "model." In 2025, nominal wages rose 4.9 per cent and real wages 4.0 per cent, the gap between them is inflation, and by the truer real-wage measure, purchasing power genuinely improved. This was a good year, and it was not invented.

The problem is the decade, not the good years. Between 2016 and 2024, labour productivity grew about 2.5 per cent a year while real income grew only 1.3 per cent. Read what that means in human terms: every year, the country gets better at making things, nearly twice as fast as the people who do the making are getting paid for it. The economy got more productive; the people who work in it did not get the gain in proportion. That gap compounds quietly, year after year, until it becomes the structure a small business has to live inside. The last row of the table above tells the same story one final way: the share of national income that actually goes to employees, called "compensation of employees", has fallen to its lowest five-year point in the entire 45-year series. More value is being created, and a smaller slice of it is being paid out as wages. For a small business owner, that is the water you are swimming in, not an abstraction.

| Productivity vs. income | Value | Source | Confidence |
|---|---|---|---|
| Labour productivity growth (2016–24) | **2.5%/yr** | Nat'l Wages Council | High |
| Real mean income growth (2016–24) | **1.3%/yr** | Nat'l Wages Council | High |
| Nominal wage growth (2025) | **+4.9%** (real +4.0%) | MOM | High |
| Employee share of GDP | **37.8%** (lowest in 45 years) | MTI | Moderate |

How can an economy grow that fast and still feel stagnant at the ground level? The answer is that there is not one Singapore economy. There are three. They sit side by side, on the same island, under the same flag. One is rich, fast, global, and connected to the world's capital. A second is the state itself, its public service, its spending, its power to shape markets. The third is where most Singaporeans live and work. And the single most important thing a small business owner can understand about their country is not how big the economy is, but **which of the three they are actually in.**

---

## Chapter 1, Where does the money come from?

Consider three Singaporeans on the same Tuesday morning.

The first works for a global bank in Marina Bay. He earns a salary that puts him in the top tenth of earners in the country, north of thirteen thousand dollars a month. His company runs operations across three continents. His productivity is powered by global markets, global clients, global capital. He wakes up, and the entire world is his potential customer. He is, in a real and measurable sense, working for the world.

The second works for the government. She is a director in a ministry, or a senior civil servant in a statutory board. She does not sell anything. There is no market that prices her work, no competitor she out-bids. Yet her salary is closer to the banker's than to the hawker's, and that, as we are about to see, is the most revealing fact in this entire chapter.

The third runs a two-man renovation company in a heartland town. His customers are local. His market is the people who live within a few kilometres of him. He cannot sell to a client in New York, or a manufacturer in Germany, or a distributor in Jakarta. The island, all of its five-point-nine million people, is his entire universe.

These three people are not in the same economy. They happen to live in the same country.

| | **The global engine** (foreign MNCs) | **The government engine** (the state) | **The domestic layer** (local SMEs) |
|---|---|---|---|
| **What they are** | Foreign multinationals, foreign-owned subsidiaries | Civil service, statutory boards, public education & health, the GLCs | Local shops, clinics, tuition, professional services, trade |
| **What they do** | Manufacturing, finance, HQ, exports, R&D | Run the country: defence, law, education, health, public services | Serve the domestic market (5.9M people) |
| **The market they face** | Global / regional (effectively unbounded) | None, they do not sell; they are funded by tax and the state's balance sheet | Domestic (capped at ~5.9M people) |
| **What they're backed by** | Global demand, capital, brand | The state's fiscal capacity, its brand, the law | Local competition, local costs, local demand |

The three engines create very different value per worker, and that difference is the whole argument of this chapter. Look at the table below and the pattern jumps out. The global engine, wholesale trade and finance, creates a third of a million to half a million dollars of value per worker. The domestic layer, retail and food, creates a few tens of thousands. The government engine sits in between, at a hundred thousand or more per worker. Then read the last row: the whole economy averages S$194,000. Every number below is measured by Singapore's own statistics, industry by industry.

| Industry | Value created per worker (2025) | |
|---|---|---|
| **Wholesale Trade** (global engine) | **S$494,000** | the trading spine |
| **Finance & Insurance** (global engine) | **S$436,000** | the engine's core |
| Manufacturing (global engine) | S$282,000 | capital-intensive |
| Professional Services | S$146,000 | |
| **Education** (government engine) | **S$150,000** | |
| **Public Admin & Defence** (government engine) | **S$116,000** | |
| **Health & Social Services** (government engine) | **S$94,000** | |
| Retail Trade (domestic layer) | S$58,000 | |
| **Food & Beverage** (domestic layer) | **S$32,000** | |
| **The whole economy** | **S$194,000** | the average |



![Value per worker: the gap between the engines.](print/figures/fig-value-per-worker.pdf)




Now ask the question nobody asks. Is the banker at his desk at six in the morning simply more hardworking than the hawker who is up before dawn, or the renovation man loading a van at seven? More capable? The answer is no, and the reason is the whole point of this chapter.

The global worker is not more hardworking. They are more *leveraged*. Three things stand behind them that the domestic worker does not have, and none of them is effort.

**First, the world vs the island.** The banker's product, a loan, a trade, a fund, is sold into a market of billions of people and trillions of dollars. The hawker's product is sold to the five-point-nine million people who can reach his stall. The same hour of work, aimed at the world, returns more than the same hour aimed at a neighbourhood.

**Second, capital intensity.** Behind the banker sits a building, a trading floor, a software stack, a global network, billions of dollars of machinery that multiply the value of every hour of human work. The hawker's capital is a wok and a rented stall. The gap in value per head is, in large part, a gap in the machinery standing behind each person.

**Third, and this is the one this series cares about, the brand.** The bank's name, the airline's name, the semiconductor's name, these are not neutral labels. They are decades, sometimes a century, of accumulated trust, reputation, and goodwill. A customer pays more for a product because of the name on it. That premium, the extra dollars a powerful brand commands over an identical product with no name, is pure value that flows to the people the brand employs. The brand is the multiplier. It is why one worker's hour, stamped with a trusted name, is worth several times the same hour stamped with no name at all.

Now look at the government worker through that lens, and you will see something almost nobody notices. A teacher creates more measured value per worker than a retailer or a restaurant worker, and is paid like a professional, yet the teacher sells to nobody and is not backed by a trading floor. The government worker has none of the first two advantages, no global market, no capital intensity. The entire value of the government engine, the S$116,000, the S$150,000, the S$94,000 per worker, rests on exactly one of the three: brand. Trust. Goodwill. The most powerful name on the island, which lets the state command the salaries it needs to keep the country running.

And here is where it gets truly interesting, because the state knows this, and has built its salary system on it. The government benchmarks its public-sector pay against the private market, so it can attract and keep able people and keep the civil service honest. The rules are exact and public. Political salaries are pegged to a mathematical formula tied to the top private earners: the benchmark for an entry-level Minister is set at **60% of the median income of the top 1,000 Singaporean citizen earners**, a mandatory 40% discount applied to the market rate "to reflect the ethos of political and public service," with the Prime Minister pegged at exactly twice that norm. Civil servants are matched to the private sector directly, at the **65th to 75th percentile** of the matching private roles.

Read what that means. **The government engine does not generate its own wages from a market, it borrows the global engine's benchmark and pays it through the state's brand.** The teacher's pay, the civil servant's pay, the senior officer's pay, these are the global engine's salary levels, funneled through the state's fiscal capacity. The brand of the state is what lets it fund pay at the 75th percentile of the private market for work that no market prices at all.

So the three engines are not three silos. They are one chain. The global engine sets the top of the market, finance and professional salaries. The government engine borrows that benchmark and pays it to the state's people through the state's brand. And that payroll feeds the domestic layer, the teacher and the civil servant buy dinner at the local restaurant, coffee at the café, tuition for their kids, care for their parents, a holiday, a renovation. Every government salary is a standing order into the domestic economy, exactly like the banker's.

This is the deepest lesson of the three engines, and the reason this whole series exists. The domestic worker is not less capable. They are less *branded*. The global worker is not more hardworking; they are leveraged, by the world, by capital, and above all by a name people trust. The government worker is leveraged by *nothing but* a name people trust, and it works, because the name is powerful enough to fund it. A powerful brand does not just raise a company's price; it turns an ordinary hour of work into several times its value, for everyone who stands behind it.

And here is the part that matters for every small business reading this. **The brand is the one asset a small business can build too.** You cannot build the world, and you cannot borrow capital, but you can build a name people trust, and a name is exactly what turns the domestic worker's hour into the government worker's, and the government worker's into the banker's.

### What the gap is actually made of, and what the brand claim rests on

Before this book leans on the brand as the answer, it owes you the accounting of the gap. The value-per-worker table, wholesale at S$494,000, finance at S$436,000, food and beverage at S$32,000, is real, but it is a composite of several forces, not a clean measure of brand, and a reader who knows how the numbers are built will not trust the book if it pretends otherwise. So here is what is actually in that gap, and what the brand claim does and does not depend on.

**The first thing in the gap is tradability.** A banker's product, a loan, a trade, a fund, is sold into a world market of billions of people and trillions of dollars. A hawker's product is sold to the five-point-nine million people who can reach the stall. The same hour of work, aimed at the world, returns more than the same hour aimed at a neighbourhood. This is the size of the market the work is sold into, not brand. It explains a large part of the gap before brand is mentioned at all.

**The second thing is sector composition and how value is booked inside multinational accounts.** A large share of Singapore's finance and wholesale value added is generated inside the accounts of global multinationals. Transfer pricing, the internal prices at which a multinational books transactions between its own subsidiaries, can concentrate profit in the Singapore entity for tax and treasury reasons, inflating the measured value added of the sector without any corresponding difference in the work done by the people in it. This is a real, documented feature of a small open economy that hosts global headquarters. It means part of the finance and wholesale numbers is an accounting artefact of where profit is booked, not a measure of what the workers there produce.

**The third thing is the foreign-worker wage floor in the domestic layer.** The domestic layer, retail, food, personal services, employs a large share of foreign workers on work permits, whose wages are set by policy and by the supply of labour, not by the value they create. This holds the measured value per worker in the domestic layer down, independent of brand. A hawker centre that runs on work-permit labour will show low value per worker even if the brand is strong, because the wage floor is low.

**The fourth thing is how value added is booked differently across sectors.** Value added is output minus the cost of bought-in inputs. In a capital-intensive sector like manufacturing or finance, the machinery and the network are bought-in inputs that are subtracted, and the residual is the human and brand contribution. In a labour-intensive sector like food service, almost everything is the human work, so the value per worker is low and the brand contribution is a smaller slice of a smaller number. The two sectors are not comparing like with like.

**What this book cannot separate out.** With public data alone, this book cannot cleanly divide the gap into its parts. It cannot say how much of the finance premium is tradability, how much is transfer pricing, and how much is brand. It cannot strip the foreign-worker wage floor out of the domestic numbers. Anyone who claims to have done that with SingStat tables is overstating what the data can do. This book does not.

**What the brand claim actually is.** The brand claim is narrower and more defensible than "brand explains the whole gap." It is this: brand is one of the multipliers in the gap, it is the only one a small business can build, and the book's argument does not require it to be the largest. The small business cannot build the world market, cannot restructure multinational accounts, and cannot change the foreign-worker wage floor. It can build a name people trust. And a name is the one multiplier that is available to a single operator, because it is built from the one thing a small business controls: consistent delivery of a word the customer can recall and repeat. The argument of this book does not need brand to be the biggest force in the gap. It needs brand to be real, and to be the only one within reach.

**What would settle the question.** The honest test would be a controlled comparison: two otherwise identical domestic businesses, one with a strong brand and one without, in the same industry, serving the same customers, with the same capital. The difference in their value per worker would be the brand premium, isolated. That study does not exist in Singapore's public data. What exists instead is the indirect evidence this book uses, the brands that demonstrably command a premium over identical unbranded competitors, and the referral-driven buying behaviour that shows the name is what moves the decision. That evidence is real, but it is circumstantial. The reader should hold the brand claim at the strength the evidence supports: brand is a real multiplier, it is the one a small business can build, and it is the lever this book teaches. It is not the whole story of the gap, and no honest book would claim it is.

### Where the domestic business's demand comes from

So where does the money in the domestic layer actually come from? The answer is the crucial plot turn: the three engines are not hermetically sealed. The engines' wealth flows down into the domestic layer, through channels that are specific, measurable, and hugely consequential for a small business owner.

The first channel is wages. The engines are where the high earners work. They are not being paid by the domestic economy, they are being paid by the global engine and the government engine. And they spend that money in the domestic economy. They buy dinner at a local restaurant, coffee at a local café, tuition at a local centre, a clinic, a trainer, a holiday. Every one of those high-income households is a concentrated bundle of domestic-layer demand. The banker's monthly salary is a standing order that shows up at your counter, your clinic's reception desk, your kid's tuition centre, every single month, as reliably as rent. And the concentration is growing, read the first row of the table below.

| The demand engine | Value | Source | Confidence |
|---|---|---|---|
| Households earning ≥S$30K/mo (2025) | **13.4%** (up from 7.4% in 2020) | SingStat | High |
| Median resident household income (2025) | **S$12,446/mo** | SingStat | High |
| Top-10% earners in foreign-owned firms | **~60%** | Factually / MOM | High |

There are two payrolls feeding the domestic layer, and the second one is the quietest. The banker's salary is one. The **government's payroll, the 158,000 public servants, plus the teachers, nurses and officers who serve the country**, is the other. A civil servant or a public-school teacher is, in effect, an employee of the most powerful brand in the country, paid at the private market's level. Their salary then does exactly what the banker's does: it shows up at the restaurant, the clinic, the tuition centre. The government engine is a second, steadier pipeline into the domestic layer, one that does not rise and fall with the global business cycle in the same way.

The second channel is the quality of the workforce. The engine does not just pay people; it educates and trains them, and when those professionals move between jobs they carry skill into the domestic layer. Singapore's own Ministry of Trade and Industry did the study. Read the table below, and pay attention to the "spillover channel" row, because it is the one that matters most. The engine's benefit arrives overwhelmingly through the **labour market, not through procurement.**

| MTI spillover study (EDB firms) | Value | Source | Confidence |
|---|---|---|---|
| 10% rise in exposure to EDB firms → domestic firm value added | **+8.3%** | MTI (2025) | High |
| → productivity / employment / wages | +6.2% / +1.5% / +1.6% | MTI | High |
| Spillover as share of EDB firms' total contribution | **41%** | MTI | High |
| Spillover channel | **Labour market, NOT procurement** | MTI | High |
| Value per EDB firm | S$48.5M/yr (2012–19) | MTI | High |

A quick word on what that study measures, so the row that says "41%" does not mislead. It tracks **EDB-supported firms**, the foreign multinationals the Economic Development Board recruited into Singapore, plus a set of high-potential local companies. That is not every foreign-owned firm, but it is the closest public measure of the engine that exists. And one row deserves a careful reading: the study found a small negative "backward spillover" for upstream domestic firms, the local suppliers selling to those multinationals. Do not mistake that for a verdict that selling to big companies is impossible; it is an average across all suppliers, and the government itself treats it as fixable, which is exactly why MTI is pushing supplier-development programmes.

The bottom line is simple and practical. For most domestic firms the engine's benefit arrives through payroll, not through business-to-business purchasing. **The bank executive is your customer. The bank itself is, for most domestic firms, probably not.** A domestic business that positions itself for the premium, quality-conscious, high-income segment is, in effect, positioning itself for the engine's payroll, the channel that works at scale.

### What the engine's payroll actually buys

Who are these customers, concretely? The engine's payroll, the wages and salaries the foreign multinationals and the state pay their staff, which then flow out into the domestic economy, is not an undifferentiated mass of well-off people. It clusters in a handful of professions and industries, and knowing *which* is the difference between aiming at a segment and hoping.

| The demand engine, profiled | Value | Source | Confidence |
|---|---|---|---|
| Median resident income (2025) | **S$5,775/mo** (incl. employer CPF) | MOM | High |
| Highest-paid occupations | Diagnostic radiologist, derivatives dealer, flying instructor, **~S$20,000/mo median** | MOM / ST | High |
| Top industry by median income | **Financial & Insurance: S$8,736/mo** | SingStat | High |
| Managers & administrators median | **S$10,820/mo** | SingStat | High |
| AI/ML engineers (ages 25–29) median | **~S$9,000/mo**, the young-and-rich exception | MOM | High |
| HNW individuals (2024) | **~330,000 HNW + 1,739 UHNW** | Credit Suisse | Moderate |

Three things matter for a small business owner reading this list. First, the **highest earners are professionals whose work is client- and trust-driven**, derivatives dealers, radiologists, private-practice doctors, not bureaucrats pushing paper. Their spending habits match the trust-first buying culture of this chapter: they value reputation, discretion, and referrals, because their own work is built on those same things. A man who earns his living because wealthy clients trust his judgment is a man who buys the same way. Second, the income is concentrated in **finance and professional services**, which cluster downtown, and this is what ties the geography to the money: the premium demand physically sits in the CBD, while most new businesses open outside it. Third, the top of the earning ladder is a **small club**: the gap between the ~S$5,775 median and the ~S$20,000 top earners is more than a three-fold spread. It is those few hundred thousand households, the affluent segment, roughly 13–15% of households, that carry the premium domestic demand. The mass market is the median; the premium business is the tail. A domestic business has to choose which one it serves.

**What the engine's payroll actually buys, concretely.** The premium households the engine pays are not a vague "affluent", they spend on a specific, named set of things. At the premium end, that means: **premium dining** (a couple on two incomes dining out is routine, and restaurants/cafés are the fastest-rising share of food spend), **private health and wellness** (specialist and TCM consultations, gyms, trainers, the categories up nearly half in five years), **tuition for their children** (top-income households pay four times what lower-income ones do on private tuition, S$162 vs S$36 a month), **travel and experiences**, and **financial/estate planning**. The engine's payroll flows into the domestic layer through exactly these premium categories, the ones with the highest margin and the lowest competitive density for a small business that positions itself there. A small business that wants the engine's money is offering the specific premium service these households demonstrably pay for, not "catering to rich people" in the abstract.

---

## Chapter 2, What's it like to compete there?

Once you know where the money comes from, you need to know what it is like to compete for it. The answer: a small, dense, brutal market, with a cost structure that punishes the wrong move.

**The density.** There are roughly three hundred and seventy thousand enterprises in Singapore. To feel the weight of that number, put it against the population: 371,000 businesses all chasing the attention of 5.9 million residents. That is one business for roughly every sixteen people on the island, including the babies and the elderly. There is no geographic insulation, you cannot open a shop "far away" where there is less competition, because "far away" is fifteen minutes in Singapore. There is no digital insulation, the moment a niche works, everyone can see it on their phone and copy it within a month.

| The density | Value | Source | Confidence |
|---|---|---|---|
| Total enterprises | **371,000** | SingStat | High |
| SMEs (of which) | **369,500 (99.6%)** | SingStat | High |
| Restaurants / fast-food | **6,355 / 837** | SingStat | High |
| SMEs citing competition as top challenge (2025) | **50%** (up from 39% in a year) | QBE 2025 | High |
| Getting / keeping customers | **55%** (top concern) | QBE 2025 | High |
| New companies registered (2025) | **77,579 (+8.5%, 213/day)** | ACRA | High |
| 6-year survival rate (2020 cohort) | **~49%** still active | ACRA/Emerhub | Moderate |
| Low-barrier consumer survival | **low** (most entrants fail) | ACRA/Emerhub | Moderate |

One note on the two numbers, because this book uses both. 371,000 is every enterprise in Singapore. 369,500 is the SME subset, which is 99.6 percent of them. Where this book says "businesses like yours", it means the second number.

That headline number is gross registrations, not net growth, a detail that matters more than the headline. Every month, some 6,000 to 7,500 new businesses open their doors while 4,000 to 9,000 close them. Picture the island's shopfronts as a constantly rotating door: a flood of hopeful new signs going up, almost as many coming down, and the total count barely budging. The survival data makes the churn concrete: only about **49 per cent of companies registered in 2020 were still active six years later**. And the failure is front-loaded, most businesses that die do so in their first three years. The first few years are the canyon most newcomers never cross.

And survival is not uniform across industries. The split is brutal and directional: **high-barrier sectors, those needing more capital or serving B2B buyers, show 70 per cent-plus survival rates, while low-barrier consumer trades, retail, food, gig-style services, see most entrants fail.** This matters for the small business owner in two ways. It confirms the pressure the QBE numbers show (half of SMEs call competition their top challenge). But it also reframes the "everything gets copied within a month" fear: the crowding is real, yet it is a churning tail of entrants most of whom do not survive, not a swarm of durable, copying competitors. The durable threat is the few who *do* survive, not the crowd, and the low-barrier industries where most new entrants keep dying are exactly the commoditized price-war trades this chapter warns against. The gap between the high-survival and low-survival sectors is the same gap between a positioned business and an undifferentiated one.

**Why is competition so fierce? Because the market is capped.** A domestic-only business hits the ceiling of its market quickly, there are only so many mouths to feed, only so many families within reach. Growth is not "expand the market." It is "take a larger share of a fixed pie," against a dense, established crowd. And when the market is capped and the players are many, the default move is to undercut, to shave a dollar off the price to steal the customer. That is why price competition is so common, and so dangerous, in the Singapore domestic layer. It is the natural physics of a small, crowded room, not a phase or a passing fad.

The cap is real, and it is worth stating precisely so an informed reader does not find a hole in it. A domestic small business is not literally sealed inside the island. It can sell to the inbound tourists who pass through, Singapore hosted tens of millions of visitors a year before the pandemic and is rebuilding toward that. It can sell services across the border, a Singapore tutor, consultant, or designer can serve clients in Malaysia, Indonesia, or anywhere the internet reaches. And it can sell online regionally, into the same cross-border market that already takes more than half of what Singaporeans spend online. These are real escape routes, and a business that uses them is not capped the way a pure neighbourhood shop is. The argument survives because most small businesses do not use them, they serve the people who can reach the stall, the clinic, the salon, and for that majority the cap is the description of the ground.

But the cap is a description of how most small businesses actually operate, not a law of physics. The business that deliberately builds a cross-border or online channel is choosing to leave the capped room, and the map is better for acknowledging that the door exists.

### Small is not the problem

There is a widely believed story that small businesses in Singapore are unproductive *because they are small*. The data says something more interesting, and more hopeful. First, a quick definition, because "productivity" gets thrown around a lot and almost never explained. Productivity is simply the value a business produces per worker, how much output each person on the payroll creates. It is the closest thing there is to a report card on whether a business is running well or just running hard.

Globally, SMEs do produce less per worker than large ones, about sixty-five percent on average. So the gap is real. But here is what the numbers reveal. **The gap is not mainly about size.**

| The productivity data | Value | Source | Confidence |
|---|---|---|---|
| SME productivity vs large firms | **~65%** (OECD avg) | OECD 2026 | High |
| Productivity dispersion *within* size classes | **~95% of industry variance** | OECD MultiProd | High |
| Best micro firms vs median large firm | **Can approach the median large firm** | OECD MultiProd | High |

Within any size class, among the small businesses, among the medium ones, there is a seven-to-one spread between the most productive and the least productive. Pause on that: the best-run small shop produces seven times as much per worker as the worst-run small shop of the same size. Size barely enters it. The productivity difference *within* a group of small firms explains about ninety-five percent of the variation across an industry. In plain English: which small business wins is decided almost entirely by how it is run, not by what it is. Size is a weak predictor. Position, management, and execution are the real drivers. And the most productive micro-firms, the two-to-four-person businesses, can match the productivity of a median firm with two hundred and fifty workers. **Small is not automatically a productivity handicap.** A positioned, well-run micro business can beat a mediocre large one.

This changes the framing. The "Singapore small business productivity problem" is that most small businesses live in the low-productivity tail and a few escape it, not that small equals doomed. The difference between the tail and the leaders is the quality of the business's position and its execution, not size. That is more than a hopeful finding, it is the single most useful thing a small business owner can take from the numbers. If the gap were about size, you would be stuck; nothing you did would close it. But it is about how you run the business. And that is a problem you can actually do something about.

### The cost structure, why the price war is a trap

Now put the cost structure on top, and the picture sharpens. There is a reason that competing on price in Singapore is not just a bad idea but a structurally dangerous one.

A small business in Singapore has two fixed, unavoidable costs: rent and labour. Singapore has among the highest commercial property costs in the world; a retailer or a restaurant pays a rent that does not fall when revenue falls. If a slow month comes, the landlord still wants his cheque in full. Wages are the largest single line, and they face pressure from both directions: they must keep rising to retain staff, good people will leave for a better offer across the street, but the margin to absorb those rises is thin.

| The cost squeeze | Value |
|---|---|
| Real wage growth (2025) | +4.0% (good year, the exception, not the trend) |
| Productivity vs. income growth (2016–24) | 2.5% vs 1.3% |
| Unit business cost, manufacturing (2025) | +0.1% (eased from +3.2%) |
| Commercial property costs | Among the highest in the world |

So the domestic small business faces a triple squeeze: a high, fixed cost base (rent, labour); a capped market; and a productivity-wage gap. The margin to absorb a price war is thin. Competing on price is structurally dangerous here, not merely a bad strategy, because the cost base does not bend, and the market is capped. The business that cuts its price does not get margin relief. It gets a slow, structural bleed: each discount shaves profit, the fixed rent stays exactly where it was, and there is no new volume big enough to make up the difference. You can cut your way to zero customers and still owe the month's rent.

---

## Chapter 3, Who holds the power, and what room do you have?

Now the question that decides your options: who actually holds the power in this market, and what room is left for you? The state holds power. The platforms hold power. The banks hold power. And a set of ten structural forces, including AI, define what is left for a small business. Let us go through them, and be straight about which ones touch your counter this decade.

**The state is not only the maker of rules; it owns companies that compete with you.** The Singapore state is the most active actor on the board. It subsidises categories, it anchors the price of certain services at zero, and it shapes whole markets with regulation. And it is a direct market participant: the top three listed state-linked companies, DBS, Singtel, SIA, control a fifth of the country's market cap. A small business can buy from the state, but it can also be competing against the state, and a state-linked company has more capital, staff and access than any small business. If one competes in your market, you cannot beat it on size. Know that early, so you do not spend years on a fight you cannot win.

The state also writes cheques for a specific kind of ambition. Consider what it offers every business. The SME Centres give free advisory sessions, roughly twenty-five thousand of them a year. A state-funded consultant will sit with you, look at your numbers, and hand you advice at no charge. That is generous. And it is also, quietly, a lesson about value: *generic* business advice is worth nothing in Singapore. Anything generic is competed down to zero. Anything that is specific, deep, and does not fit the government's template must earn its price on depth, speed, and niche focus. If a free hour of advice can fix it, it was never going to be what you sold.

| The state's money | What it funds | Co-funding | Source | Confidence |
|---|---|---|---|---|
| Enterprise Development Grant (EDG) | Business transformation, innovation, capability, internationalisation | Up to **50%** of eligible costs (SMEs); 70% for sustainability | EnterpriseSG | High |
| Productivity Solutions Grant (PSG) | Pre-approved IT solutions and equipment for automation | Co-funded | EnterpriseSG | High |
| SME Centres | Free advisory sessions (~25,000/yr) | 100% free | EnterpriseSG | High |
| Green Plan 2030 direction | Sustainability segment created by regulation | Co-funded | MTI | High |

Read the pattern in that table. The money is **purpose-directed**. EDG co-funds defined projects like innovation, new capabilities, or going overseas; it does not fund your day-to-day running costs. PSG co-funds pre-approved IT tools and equipment for automation, meaning the government has already vetted exactly which systems count. In both cases, the state will pay a large share of a *defined* improvement, a new system, a new market entry, but not to keep an undifferentiated business alive. You cannot walk in and ask for money to keep doing what you already do. The grants reward specificity and a plan. And the generic advice being free is itself the tell: any advice that fits the government's template is available at zero cost, which means it carries zero value. What survives the free tier, and what a business must actually pay for, is the advice that does not fit the template: the deep, specific, niche positioning this series is about. The state's grants shape the *floor* of the market; they do not confer the *edge* that lets one business beat another.

Regulation is just as active a market-shaper. The Green Plan 2030 is actively creating a whole sustainability segment where none existed before. And the alphabet soup of agencies, HSA (the health regulator), ACRA (the company registrar), IMDA (media and tech), NEA (environment), each constrain the market, and for those who comply well, each confers trust. A food business that is HSA-compliant, or a tech firm that is IMDA-accredited, is doing more than obeying the law; it is wearing a badge that customers can see. A small business that sees the government only as a cost, or only as a source of grants, is missing half the picture. Being on the right side of a policy direction is a structural force of its own.

### The ten structural forces the numbers don't show

Beneath the aggregate numbers, there are ten structural forces that decide who survives, and they rarely appear in any macroeconomic report. They group into four questions. Let me keep them numbered, because each one is a force you should be able to name and hold on to.

**Who is actually buying, and what do they reliably pay for?**

**1. The national-savings model suppresses consumption.** Singapore runs one of the most disciplined household savings systems on earth. The CPF, the Central Provident Fund, the national retirement scheme, takes 20 per cent from your salary and 17 per cent from your employer, and it is locked away for housing, health, and retirement, not for spending. Add the HDB housing system, and the result is that a large share of income is redirected away from discretionary spending. Gross domestic savings run about fifty-eight percent of GDP, among the highest in the world. Here is the practical consequence for a shopkeeper: the high earner's twenty thousand a month is not fully spendable. A large share never reaches the retail till. There is a vast pool of money in Singapore, and a surprising amount of it is resting in a savings account, not passing through your cash register.

**2. The domestic helper is a regular household expense.** There are roughly 1.23 million foreign workers, and about 317,000 foreign domestic workers, the live-in helpers who run the households, cook the meals, and mind the children, in about one in five households. A helper is someone hired from outside the family to bear the load of running the household, and it is something many Singaporean families pay for on an ongoing basis. To grasp how central they are, try to picture a dual-income family without them: in Singapore, when both parents work and there is no extended family around, the helper is the person who makes the whole arrangement hold. They are what makes the dual-income household work, and, by extension, what puts both salaries into the spending pool that reaches your shop.

**3. The heartland-downtown geography.** Premium demand concentrates downtown; eighty-three percent of new businesses register outside the CBD. The premium, higher-spending customers sit downtown, while the mass market lives across the heartland. A domestic business must choose which geography's economics it serves, downtown premium or heartland mass. Trying to serve both at once usually means serving neither well.

**Who holds the power in your market?**

**4. The platform economy owns the customer relationship.** Shopee alone captures about 53 percent of the platform business; the top three platforms, Shopee, Lazada, TikTok, take about 99 percent of it. What that means for a seller is not just where customers find you, but who owns the data of who bought what, who they are, and when they will buy again. Most domestic businesses do not own their customer relationship, the platform does. You may be the one packing the boxes, but the platform is the one who knows your customer's name. That is a quiet, slow transfer of power, and it is nearly complete. The main defence is to build a direct relationship with your customers, so the platform is not the only way they can reach you.

**5. The SME finance ceiling.** There are about 800 local companies with revenue over a hundred million dollars, a number that has barely moved since 2017. That is a striking fact: Singapore has been "becoming a start-up nation" for years, and yet the club of companies big enough to outgrow small-business lending has stayed frozen at roughly the same eight hundred names. SME lending is bank-dominated and collateral-based, meaning banks lend against physical assets like property and machinery, not against ideas, software, or growth. A high-growth, intangible-heavy SME, one whose value is in its code, its brand, its customer list, hits a wall the big banks aren't built to serve. The money is there; it just cannot see businesses that are worth more than they physically own.

**What are your actual options?**

**6. The Johor-Singapore Special Economic Zone.** The 2025 JS-SEZ offers the land and labour that are scarce and expensive in Singapore, next door, 100 projects, 20,000 skilled jobs, special tax incentives. The "twinning model", front office in Singapore, back office and factory in Johor, is the practical template for escaping the domestic cost cap, for a firm that wants to stay an operator rather than become a brand.

**7. The fiscal machine.** The state can afford to be the active shaper it is because of its budget surpluses and its sovereign reserves. A small business on the right side of a policy direction rides the state's capacity. For most small businesses, this is a background force rather than something to act on directly.

**8. Risk-aversion and the high cost of failure.** The high cost of failure in Singapore has made entrepreneurs more risk-averse. High rents, committed leases, sunk costs. This is why entrepreneurship skews toward side-hustles and incrementalism, and why a decisive, well-positioned business can move where risk-averse competitors won't. Most of the competition will not commit to one clear position; that leaves room for a business that will.

**And the force changing all the others.**

**9. Artificial intelligence, the force now reshaping all the others.** In 2024, only 14.5 percent of Singapore SMEs had adopted AI, but that had tripled from 4.2 percent in a single year. Large businesses had adopted it at 62.5 percent. The gap is 48 points. The state is committed to lift 10,000 enterprises and 100,000 workers into AI capability. AI is amplifying the other nine forces, not replacing them, collapsing the cost of a new competitor (213 new businesses a day), and making execution cheaper for everyone. When execution is cheap for everyone, what decides who wins is whether a customer chooses you for a clear reason.

*(Note: the state-as-competitor, named as the opening of this movement, is the tenth force in the full series, the direct market participant through its linked companies, the DBS/Singtel/SIA fifth-of-market-cap player we met above. It belongs at the head of the power question, which is why it leads rather than sits in the numbered list.)*

### The external forces, where the domestic business's best demand comes from

There is a temptation to treat the world outside the island as background noise. That would be a mistake. A large share of the domestic economy's best demand is externally constituted.

| The external forces | Value | Source | Confidence |
|---|---|---|---|
| International visitor arrivals (2025) | **16.9M (+2.3%)** | STB | High |
| Tourism receipts (Jan–Sep 2025) | **S$23.9bn (+6.5%), record** | STB | High |
| Tourism F&B / sightseeing / entertainment / gaming growth | **+15% each** | STB | High |
| Family offices in Singapore | **2,000+ (2025)** | Empaxis / Dakota | High |
| Family office AUM | **S$66.8bn (+43% YoY)** | Empaxis | High |
| Share of SG AUM invested abroad | **88%** | MAS | High |
| China as principal trading partner | Since 2013 | GIS | High |
| Singapore exports to China (2025) | **>S$70bn (14% of total)** | GIS | High |

These forces are not abstractions in a government report. Each one shows up as a specific customer. **Tourism** is a recurring injection of high-spending visitors walking past your door, and the growth is in the high-margin lines: tourism food, sightseeing, entertainment, and gaming each grew about 15 percent. A tourist's S$200 dinner is pure new money dropped into the domestic layer. **The wealth-migration economy**, here is where the money from abroad settles. A family office is a private firm that manages the fortune of a single wealthy family; Singapore now hosts 2,000 of them, managing S$66.8 billion, and 88 percent of that money is invested abroad, not in the local economy. What that means on the ground is not factories or jobs but *people*: the wealthy principals and their families who live here, eat here, and spend here. **The geopolitics**, Singapore's neutrality is why the capital sits here in the first place, and it is not moving. **The regional gateway**, Singapore connects to a ~680-million-person ASEAN market through its free trade agreements, which means a small business here has a legal doorway into nearly 700 million customers if it wants it.

**The spillover, quantified.** Remember the MTI finding: a ten percent rise in exposure to the engine's EDB firms raises a domestic firm's value added by 8.3 percent. These external forces are the concrete sources of the domestic layer's premium demand. **A domestic business that can serve the affluent foreign-talent and high-net-worth segment, or plug into the regional gateway, is leveraging external forces most local businesses ignore.**

### The demographic currents

The three engines are also turning in a demographic direction that matters enormously for small business.

| The demographic currents | Value | Source | Confidence |
|---|---|---|---|
| Citizens aged 65+ | **20.7%** (up from 13.1% in 2015) | Population.gov.sg | High |
| Resident total fertility rate (2025) | **0.87** | SingStat | High |
| Resident live births (2025) | **27,393 (−11.1%)** | SingStat | High |
| Seniors living alone | **88,000** | SingStat | High |
| Senior share of HDB households | **31%** (2023/24) | SingStat | High |

Singapore is ageing rapidly, fertility has collapsed, and the household is shrinking. To feel the speed of that last change, look at the fertility number: 0.87 means the average woman is having fewer than one child, less than half of what is needed to keep the population replacing itself, one of the lowest rates on earth. Who is buying? An ageing population. What are they buying? Healthcare, independence, care, services that compensate for shrinking households and absent younger relatives. The direction of travel is unmistakable, over a quarter of the population will be 65 or older by 2030, and national health expenditure could reach US$44 billion that year. Every one of those grey hairs is a customer.

It is worth splitting that into the concrete demand segments it creates, because each is a different business with a different customer:

- **The ageing-and-health consumer.** The fastest-growing spend, and the one with the clearest trajectory. More than one in five residents is already 65-plus; national health expenditure is projected to nearly double by 2030. The demand is independence and care that compensates for shrinking households, more than it is medical: home services, mobility, companionship, financial and legal planning for a long old age. A childless eighty-year-old does not just need a doctor; she needs someone to fix the aircon, drive her to the clinic, and help her sort out her will. And the government engine has a heavy hand in this exact market. The state spent **S$97 billion operating** in 2025, of which **S$55 billion went to Social Development**, the largest single block, including **S$18.5 billion on health** and **S$5.2 billion on social and family development**. That last line is where the care market is being built: the Home Caregiving Grant, the eldercare centres, the subsidies that make a family able to pay a home-care aide or put a parent in a day centre. When the state writes those cheques, it is the government engine's money flowing, through families, into the domestic layer's care businesses.

A small business in care, health, or ageing-in-place is standing in a current the state has chosen to strengthen, not riding a current that happens to be moving.
- **The shrinking-household consumer.** With fertility at 0.87 and live births down 11 per cent, the buying unit is getting smaller and older.

Single and childless households buy in smaller portions, value convenience and services over bulk, and increasingly buy *for* themselves rather than for a family. A household of one does not want a family-sized pack of rice or a six-seat restaurant booking; it wants a single portion, delivered, fast. The businesses built around a family-sized transaction need to rethink the unit they serve.
- **The single-senior consumer.** 88,000 seniors live alone, a number that only grows as the 65-plus cohort expands. They are a distinct and under-served market: services that deliver to a locked and often isolated single person, meals, care, transport, safety checks, and that can be bought on trust, which is exactly how this market already buys. If someone in her eighties lives alone, the person she lets into her flat is the person she trusts; that is your customer, and she will pay well to feel safe.

- **The high-net-worth consumer.** At the other end of the age curve sits the concentrated wealth: roughly 330,000 high-net-worth individuals and 1,700 ultra-HNW individuals, and a luxury goods market crossing US$9 billion. This is the affluent foreign-talent and family-office segment from the external-forces section, spending in the domestic layer. It is a smaller, richer, and harder-to-serve segment, the premium tier the rest of this series will return to.

Each of these is a structural drift in *who* buys, with a different trigger and a different willingness-to-pay. The mistake is to treat "an ageing population" as one market. It is several.

---

## Chapter 4, So how does Singapore actually decide?

All of the above describes the terrain. But one question remains, and it is the most important in this chapter: given this terrain, how does Singapore actually decide who to buy from? The answer is the reason the whole book works, and it runs against the narrative of the global digital economy.

There is one more force that belongs in this map, and it is the least statistical and possibly the most important of all. Every statistic in the tables above points the same way, and the pattern runs against the whole narrative of the global digital economy.

| How Singapore buys | Value | Source | Confidence |
|---|---|---|---|
| SMEs who prefer to buy offline | **65%** | QBE 2025 | High |
| Fellow owners as most trusted advisor | **31%** (vs coaches 24%, family 18%) | TAB | High |
| Buyers finding solutions via personal referral | **~85%** | TAB | Moderate |
| Offline buyer channel: agents | **29%** (rising, from 27%) | QBE 2025 | High |
| Offline buyer channel: banks / brokers | **10% / 13%** (both falling) | QBE 2025 | High |

Sit with those numbers for a moment. Two-thirds of small businesses prefer to buy offline. When an owner wants to know who to trust, the most-cited advisor is **another business owner**, ahead of a coach, the family, or the internet. And roughly 85 per cent of buyers find their solutions through a personal referral. That is not a picture of a slick, screen-first market. Singapore's domestic economy buys on trust, offline, and peer-first. This is a structural advantage for the domestic business, not a quaint local habit, and a structural wall for the commoditized one.

But the picture is more specific, and more interesting, than "people like to buy in person." Strip away the general trend and the detail is telling. When Singapore's small business owners do buy offline, they are not walking into a shop. They are buying **through a person**. The advisor channel is the only one growing: the use of agents and brokers across the buying journey is up, while the impersonal channels, banks, aggregators, are in decline. And when they do buy online, they prefer direct contact with a known seller over a faceless marketplace. The surface of the story is "offline." The structure is "through a named, trusted person."

There is a counterpoint worth facing: Singaporeans are among the *least* word-of-mouth-driven consumers in Asia, YouGov finds fewer than a fifth say word-of-mouth helps their purchase decisions "a great deal." So this is not a country run on casual gossip about products. The survey data points to something narrower and sharper: it is a country that buys on **curated, advisor-mediated trust**, not on broadcast chatter. The referral that wins in Singapore is a *named person, an advisor, a fellow owner, a professional whose judgment the buyer already respects, putting their own credibility on the line to vouch for a specific provider*, not a friend saying "I liked this."

That is the mechanism, and it is exactly what AI cannot imitate. A language model can sound warm, know the local context, and answer fluently. It cannot make a third party stake their reputation on recommending it. The moat is not "a relationship" in the abstract, that is cheap and now simulable. The moat is *being inside the referral economy*, such that a trusted person is willing to risk their own standing to send someone to you. No machine can manufacture that standing.

The practical consequence for a domestic business owner is blunt and useful. It is not enough to be good. You must be **referrable**, a business a fellow owner or an advisor will confidently stake their own name on. That means a clear, specific, defensible position (so a referrer knows exactly what you do and when to send you), a delivery that never risks the referrer's reputation, and enough visible record that the referral feels safe. An AI-powered competitor can copy your price, your menu, your opening hours, even your tone of voice. It cannot copy the accumulated willingness of real people to vouch for you, and in a market that buys through people, that willingness is the asset.

### What the structure means

So where does this leave the small business owner? The structure produces four ways to win, and they are worth taking seriously.

- **Scale and consolidation.** A fragmented, thin-margin market, 371,000 firms, a bank-dominated SME-finance ceiling that starves the middle, is exactly where someone buys up and integrates a struggling category. It is a real play, and the finance-ceiling force (fifth above) explains why the field is open. It is simply not the play of a single owner-operator, which is who this series speaks to. Consolidation needs capital and a portfolio mindset.
- **The Johor escape.** The JS-SEZ twinning model, front office in Singapore, back office and factory across the causeway, is a genuine path out of the cost cap, for a firm that wants to stay an operator rather than become a brand. It asks for a cross-border operation.
- **Owning the customer relationship.** The platforms own 99 per cent of the commerce relationship. Clawing that relationship back, owning the client list and the re-order loop directly, is real and durable. It asks for a tech and logistics build.
- **Owning a position.** In an economy that runs on offline, peer-referred trust, a clear and defensible position is what a lone operator can build and hold. It asks only for consistency, the willingness to own one specific, referrable thing.

None of these is ruled out by the data. But three of them ask more of the owner than the fourth, capital, a cross-border operation, or a tech build. The fourth is the one that fits how this market actually buys, and it is the winning move *available to a single owner-operator in this specific terrain*. The kway-teow hawker we opened with, and the clinic worker, and the tuition teacher, is exactly who this is for: someone without a chain's capital, a logistics team, or a cross-border operation, but with the ability to own something specific enough to be referred, remembered, and re-hired in a market that runs on trust.

That is the terrain. And the rest of this series is about how to find, and hold, that position.

---

## Where this goes next

This chapter has mapped the terrain, the three engines, the channels that connect them, the density and churn, the productivity reality, the cost squeeze, the state's money and direction, the ten structural forces, the external demand, the demographic segments, and the trust-first buying culture. Each thread has been traced as far as the verified data allows, and each one is a foundation the later chapters in this series build on.

The next chapter, *The Demographic Waves*, takes up the four consumer segments this chapter only sketches, and turns each into a map of who buys, why, and what they will pay for. After that, the series moves from the *landscape* to the *position*: how a single owner-operator finds and holds the one thing that cannot be competed away.

## Sources & confidence

All figures are confidence-labeled. **High** = primary source (SingStat, MTI, MOM, IMDA, QBE, OCBC, ACRA, STB, MAS, EnterpriseSG) or multiple independent sources; **Moderate** = secondary or single-source, directionally sound; **Low** = derived estimate. Key sources: Singapore Department of Statistics (enterprise counts, household income, GDP, births, fertility, senior households); **SingStat Table Builder / MCP (public-service employment ~157,997 in 2025, M182831; value added per worker by industry 2025, M015811: wholesale ~S$494K, finance ~S$436K, manufacturing ~S$282K, education ~S$150K, public admin ~S$116K, health & social ~S$94K, retail ~S$58K, F&B ~S$32K, whole economy ~S$194K; government operating expenditure 2025, M130581: total ~S$97.5bn, social development ~S$55.1bn, health ~S$18.5bn, social & family development ~S$5.2bn)**; Ministry of Trade and Industry (spillover study, productivity-wage data, compensation-of-employees share); Ministry of Manpower (nominal and real wage growth, Report on Wage Practices 2025, occupational wages); National Wages Council (productivity and income);

Public Service Division (public-service salary benchmarking framework, political pay pegged to the median of the top 1,000 earners with a 40% discount; civil-service pay matched to the 65th–75th percentile of equivalent private roles); Enterprise Singapore (EDG, PSG grant architecture); IMDA (AI adoption); QBE and OCBC (small business challenges); Singapore Tourism Board (visitor arrivals and receipts); MAS and Empaxis (family offices, AUM); ACRA (registrations, formations and cessations);

Emerhub (registration survival cohort and industry distribution, derived from ACRA/data.gov.sg); Credit Suisse Global Wealth Report (HNW and UHNW counts); the Straits Times (occupational wage profile); the CIA World Factbook and World Bank (engine characteristics, trade-to-GDP, savings ratio); IMD (competitiveness). Where a figure is directional or derived, it is flagged. All figures as of August 2026.











# PART TWO, THE DEMOGRAPHIC WAVES

In 2026, there is a wedding venue in Singapore that sits half-empty on most weekends. It is not a bad venue, and it is not badly run. The florist who books it, the photographer who fills its banquet halls on Saturdays, the caterer who feeds two hundred guests at a sitting, they will all tell you the same story if you push them, which is that they have no idea why. Business is not bad. Business is just *gone*. Nobody has cancelled on them. The customers simply stopped coming.

Last year, 24,688 couples got married in Singapore. That is down 6.2 percent in a single year. It is a number so modest it fits in one sentence, and it is quietly the most important number in this chapter, because it is about what a country becomes when it stops having children, not really about weddings.

A wedding venue that sits empty in 2026 is the victim of a decision, not of a downturn or a bad manager or a competitor across the street that Singaporeans started making, quietly and at scale, forty years ago. That is the strange thing about demography. Every other force a business faces is fast. A business cycle turns in months. A technology is here and then it is replaced in years. But a population is a thing that is already decided, long before it shows up in your profit and loss. The children who would have married and filled that hall were never born, and no amount of marketing will ever bring them back. When a country stops having children, it does not happen all at once. It happens one empty Saturday at a time, for decades.

This chapter is about the four forces doing that work. They are not four separate stories. They are one story, and it has a shape. Read the people in this order and it becomes obvious: who is here, what they earn, what they spend, and where their attention goes. Follow that thread and the four waves, fertility, ageing, the household, care, stop being statistics and start being the thing that decides which businesses win.

---

## Where the money is, the five streams a small business actually sells into

There is a way to think about a market that most owners never get taught. We talk about customers, and we talk about products, and we talk about margins. But the customer is not the real unit. The real unit is the stream. A stream is a body of money that moves through Singapore every month, in a direction you can trace, from a source you can name, into the hands of people who have to spend it. Your job as a small business owner is not to attract customers in general. Your job is to stand in the path of one of these streams and take a small cut as it passes.

When you see the country as five separate streams instead of one blurry market, a lot becomes clear very fast. Some streams you can stand in as a small operator with two employees and a rental unit. Some you cannot realistically enter at all, no matter how good you are. Knowing which is which is worth more than any amount of marketing. Because the owners who fail are not usually the lazy ones. They are the ones who aimed their whole business at a stream that was never going to carry them.

This chapter walks through the five streams in plain terms. For each one we say who the customer is, what they actually buy, and whether a small business can sell into it. We are not selling you a dream here. We are showing you where the money is, and where it is not, so you can choose your stream with your eyes open.

### Stream one: the domestic consumer spend

The first stream is the one everyone pictures when they think about opening a shop. It is the money that households in Singapore spend on the ordinary business of living. Food, clothes, furniture, school bags, haircuts, birthday cakes, the weekly groceries, the occasional night out. This is the stream most small businesses are born aiming at, because it is the easiest to imagine. You open a door, you put your product out, and a person walks in and pays you. Simple.

The size of this stream is worth putting a number on, because most owners have no idea how big it is. There are roughly 5.9 million people living in Singapore. The median household income is about S$12,446 a month. Median means the middle. Half of all households earn more than that and half earn less. So when you picture the average Singaporean family, the one who lives in a four-room HDB flat in Bedok or a condominium in Sengkang, you are picturing a household that brings in a bit over twelve thousand dollars a month, before the money is split, taxed, and locked away.

Now, here is the part that matters for you. That twelve thousand dollars is not free money the household gets to spend. The Central Provident Fund, which we call the CPF, takes a fixed share first. The employee pays in twenty percent of their wage, and the employer pays in another seventeen percent on top. All of that is locked up for housing, for healthcare, and for retirement. You cannot spend CPF money on a meal. You cannot spend it on a handbag. So when a household in Singapore counts its spending money, it is working with the portion that is left after CPF, not the full twelve thousand, after income tax, after the mortgage or the rent on the flat.

Let us say that portion is something like two-thirds of the gross income, once you allow for CPF, tax, and the fact that many households carry housing costs. That still leaves a household with several thousand dollars a month to spend on the actual business of living. Multiply that by the number of households in a five-point-nine-million-person country, and you have a domestic consumer stream measured in the tens of billions of dollars a year. That is the water a small shop is trying to drink from.

So what does this customer actually buy? You have to be precise here, because the shape of the spending matters as much as the size. Singaporean households spend heavily on food, and a large share of that food is eaten away from home. The hawker centre is the great equaliser, but the same household that eats chicken rice for three dollars at lunch will happily pay thirty-five dollars for a birthday dinner and seventy for a decent bottle of wine to go with it. The consumer stream is a ladder of occasions, not one thing, and a business can only stand on one rung at a time.

The other thing to know about this customer is how they find what they buy. This is the single most useful fact in this chapter, so do not skim past it. About eighty-five percent of buyers in Singapore find their solutions through personal referral. Someone they trust tells them about you. That is the dominant channel. Not advertising, not social media, not a sign outside your door, though those help. The word of a friend, a colleague, a neighbour, a relative. If you are a small consumer business in Singapore, your real marketing department is your existing customers telling other people about you, and everything else you do is just trying to make that conversation happen more often.

Now the part. Is the consumer stream open to a small operator? Yes, but it is the most crowded stream in the country, and the most punishing. Roughly two hundred and thirteen new businesses register in Singapore every single day. A large share of those are small consumer-facing shops. The stream is huge, but the competition for a place in it is correspondingly huge, and the failure rate is brutal. Fewer than one in four food-and-beverage businesses in Singapore are still alive five years after opening. You read that right. For every four restaurants, coffee shops, and stalls that open, more than three are gone within five years.

That number is a reason to be clear-eyed, not a reason to stay away. The consumer stream rewards the owner who has picked one rung of the ladder and does that one thing better than the street around it. It punishes the owner who opens a generic shop that could be anyone's. If you sell into the domestic consumer stream, your survival depends on referral, on repeat custom, and on being the place that a specific kind of neighbour wants to come back to. Stand in that stream with a clear identity and the water will carry you. Stand in it with a vague product and the water will wash you away with the hundreds of others who opened the same shop on the same day.

### Stream two: the government money

The second stream is the one almost nobody thinks about, and it is the one that surprises people the most when we lay it out. It is the money that the Singapore government spends every year, and it is far bigger than most owners assume. The state runs an operating budget that runs into the tens of billions of dollars annually. To give you a number you can hold on to, the government's annual operating spend is on the order of a hundred billion Singapore dollars a year. About S$97 billion in the most recent full figures. That is not the reserves, and it is not borrowing. That is the money the state moves through the economy in a single year to run the country.

Now, a lot of that money goes to things no small business will ever touch. Defence, infrastructure, the salaries of public servants, the machinery of government itself. If you are a small owner, you are not going to build an MRT line and you are not going to supply the navy. But here is the key that unlocks this stream: a very large share of government spending in Singapore is spent on the domestic services, not on government that the state funds and that ordinary people and families depend on. Care for the elderly. Health services. Early childhood education. Social support. Community programmes. And the state does not run most of these services directly. It funds them, and it buys them from providers.

So the government money stream, for a small business, is about the funded services that sit right in your neighbourhood, not about selling to some faceless ministry, the ones a growing elderly population and a young population both pull at. Singapore's population is ageing. The median resident is forty-three years old, and that number keeps climbing. That means day-care for the elderly, home-care, physiotherapy, meal delivery for seniors, respite services, and the thousand small services that keep an ageing population safe and fed and mobile. These are not exotic. They are ordinary services that the state wants delivered, and the state funds them through grants, through subsidies, through vouchers, and through contracts.

Let us make this concrete, because owners have a hard time believing it. The government does not want to own and run every eldercare centre in the country. It wants those centres to exist, so it pays for them, and it expects the sector to provide them. A small operator who can run a reliable eldercare programme, who can manage a team of carers, who can meet the licensing and reporting standards, is a provider the state actively needs. The same logic runs through early childhood. Childcare, infant care, and preschool places are in constant demand, and the state funds the supply. A small, well-run childcare centre is helping the government meet a demand, not fighting it the government itself has declared.

The part here is a real one, and we will not hide it. The government money stream has a gate, and the gate is compliance. You cannot drift into this stream the way you can drift into a consumer shop. There are standards to meet, staff qualifications to hold, audits to pass, and a long sales cycle measured in years rather than weeks. If you are a lone owner with no tolerance for paperwork, this stream will frustrate you. But if you are willing to build a proper organisation, this is the most defensible stream a small business can enter. Government-funded services do not vanish in a downturn. The demand for care does not fall when the economy slows. In a country where the population is ageing and the state has committed to funding the answer, this stream is steady, and it is growing.

The other door into the government stream is smaller but worth naming. The state spends money every day with small vendors on the ordinary goods and services it needs to keep running. Printing, cleaning, catering, maintenance, equipment. Getting onto the government's vendor list takes work, and the competition is real, but it is not closed. If you can supply a reliable, modest service at a fair price, the state is actually a good customer. It pays on time, it pays in full, and it does not vanish in a downturn. For a small business that wants a floor under its revenue, a few government contracts can be that floor.

So who is the customer in this stream? Sometimes it is the state itself, buying a service. More often it is the citizen who receives the funded service, with the state standing behind the payment. What do they buy? Care, health, education, and the social services that hold a dense, ageing city together. Can a small business sell into it? Yes, genuinely, and more openly than most owners believe. But it is a stream you qualify for, not one you walk into. The door is real, and the door is locked, and you need the key of compliance and standards to open it.

### Stream three: the business-to-business spend

The third stream is the money that one business pays to another. Most small owners never even look at this stream, because they spent their whole working life thinking of the consumer as the only customer. But in Singapore, the business-to-business stream is enormous, and for many small companies it is the difference between surviving and closing. We call it B2B for short, business to business. It is the money a company spends buying what it needs from other companies, instead of buying from the end consumer.

The anchor of this stream is the small group of very large local companies. Singapore has roughly eight hundred local companies that pull in more than a hundred million Singapore dollars in revenue a year. That number is worth pausing on, because it has barely moved since 2017. Eight hundred companies. In a country with about three hundred and seventy-one thousand businesses, that is a tiny fraction of one percent. But these eight hundred companies sit at the top of the corporate pyramid, and everything below them feeds them.

Now here is what most owners misunderstand. These eight hundred big companies do not make everything they sell. A large construction firm does not build its own cranes. A large food manufacturer does not grow its own chicken and does not press its own packaging. A large hospitality group does not launder its own sheets and does not print its own menus. A big company is, at its core, an engine that coordinates. It holds the brand, the contract, the relationship with the final buyer, and then it buys everything else from suppliers. It buys raw materials, components, logistics, cleaning, security, catering, printing, IT support, transport, maintenance, professional services. And a great deal of that buying flows down to small suppliers.

That is the whole game in the B2B stream. You are not trying to compete with the big company. You are trying to be one of the small companies the big company buys from. Think of it as a pyramid. The eight hundred big companies sit at the top. Directly below them are their tier-one suppliers, who may themselves be substantial. Below that, the tier-two and tier-three suppliers, and this is where small businesses live. A small print shop that handles a construction firm's site signage. A small laundry that services a hotel group. A small logistics operator that does the last-mile delivery for a manufacturer. A small cleaning company that keeps an office tower presentable. None of these need to be big. They need to be reliable, and they need to be exactly where the big company can reach them.

What does this customer buy? Everything, is the answer, but let us be specific about what is realistic. The big company buys services it does not want to run itself. It buys anything that is peripheral to its core competence. If a company's core is construction, it does not want to own a fleet of trucks, so it buys logistics. If its core is food, it does not want to own a repair workshop, so it buys maintenance. The small B2B supplier wins by finding the thing the big company considers an inconvenience, and becoming so good at that one thing that the big company never wants to change supplier.

The part of this stream is that it is slow to enter and it is the most relationship-driven stream there is. Nobody hands a contract to a stranger on the strength of a website. The big company buys from people it knows, people who have been recommended, people who have proven themselves on a small job first. This is where that eighty-five percent referral number does double duty. It is not just consumer buyers who buy on referral. Corporate buyers are even more conservative. The person who places a S$50,000 order with a supplier they have never worked with is risking their own reputation. They do not take that risk lightly. So the path into the B2B stream is almost always the same: get one small job, do it perfectly, and let that job become the reference for the next, larger job.

Can a small business sell into this stream? Yes, and this may be the single best stream for a small operator who wants stable, recurring revenue instead of the daily drama of walk-in customers. But it requires a different temperament. You need to be patient, because the first contract takes time. You need to be disciplined, because the big company will audit your safety, your insurance, your reliability. And you need to understand that your marketing here is a reputation, not advertising. In the B2B stream, the currency is trust, and you earn it one delivered job at a time.

### Stream four: the foreign-worker and expatriate payroll

The fourth stream is the money that foreign workers and expatriates earn in Singapore and then spend in Singapore. This is the stream owners almost never count, and it is bigger than you think, because the number of people behind it is huge.

Let us put the number in front of you. There are about 1.23 million foreign workers in Singapore. These are the men and women who build our buildings, who keep our ports moving, who work in the factories and on the construction sites and in the marine and process industries. On top of that, there are about 317,000 foreign domestic workers, the helpers who live in roughly one in five Singaporean households. And above and around both sits the expatriate population, the managers, the bankers, the engineers, the professionals on assignment from the global companies that have made Singapore a regional headquarters hub.

Now, here is the part that makes this a stream and not just a collection of people. All of these people are paid in Singapore, and a meaningful portion of what they are paid is spent in Singapore. The foreign worker does not bank every cent. He buys his meals, he buys his phone cards to call home, he buys his groceries, he buys the clothes he needs, he sends some remittances and spends some. The domestic helper lives in the household but still buys herself things, and she is part of a household budget that spends. The expatriate, especially, has a high income and spends heavily on the domestic economy, on rent, on dining, on schooling, on recreation, on everything that makes up a comfortable life in a dense city.

The shape of this stream is not one uniform thing. There are really three different currents inside it, and a small business needs to know which one it can stand in.

The first current is the foreign-worker spend, and this one is modest per person but enormous in aggregate. A million and a quarter workers, each spending some portion of their wage in Singapore, adds up to a very large domestic consumer stream that is concentrated in specific places and specific categories. The shops near the dormitories, the remittance agencies, the budget eateries, the mobile-phone and SIM-card sellers, the stores that sell the practical goods a worker needs. If your shop is near a construction site or a dormitory or an industrial estate, this current is your real market, and it is a market most business-school thinking completely ignores. It is also a market that pays cash and buys on necessity, which makes it stable in a way that discretionary consumer spending is not.

The second current is the domestic-helper economy, and this one flows through the household. Roughly one in five Singaporean households has a helper, which means the helper is part of the normal operation of a very large number of homes. The helper buys the groceries. The helper takes the children to the playground. The helper cooks the meals. In practical terms, the helper is often the person in the household who actually goes to the shops and actually decides, at the shelf, what gets bought. If you run a small grocery or a neighbourhood provision shop or a market stall, the helper is one of your most important customers, and she is often under-appreciated in the way owners think about their customer base. She is the one who remembers which stall gives good service, because she is the one who goes back every week.

The third current is the expatriate spend, and this is the premium end. The expatriate community in Singapore has a high income and a specific pattern of spending. They rent, and the rental market they occupy supports a whole ecosystem of property agents, moving companies, furniture suppliers, and home-styling services. They eat out, and they eat out at the mid-to-upper end. They send their children to international schools, and that supports a whole service ecosystem around the school. They buy services they took for granted at home and now have to source fresh. This is a concentrated current, and it flows most strongly in the same places we will talk about in the next stream.

Can a small business sell into this stream? Yes, and this is the most overlooked opportunity in the whole book. The foreign-worker current is open to any shop physically located where the workers are, and it is loyal and stable once you serve it well. The helper current is open to any neighbourhood business that treats the helper as a proper customer instead of ignoring her. The expatriate current is open to any service business that can cater to the expectations of a well-paid, time-poor professional who will pay a premium to have a problem solved properly and promptly.

The warning is this. The foreign-worker and expatriate payroll is real money, but it is money that is sensitive to policy. The number of work passes the government issues is a tool of national policy, and it moves up and down with the economy and with political priorities. A business that builds its whole model on the foreign-worker current is building on a base that can be tightened. That does not mean it is a bad stream. It means you should know, going in, that this stream has a tap that you do not control. Build into it, but do not let it be your only water.

### Stream five: the premium downtown tier

The fifth stream is the one that is easiest to see and the hardest to actually stand in. It is the concentrated premium money that sits in the middle of the city. This is the tier of customers who are not shopping for value. They are shopping for something else, and you need to understand what that something else is if you want to serve them.

The geography of this stream is stark, and the numbers make it clear. About eighty-three percent of new businesses in Singapore register outside the central business district. Think about what that tells you. The vast majority of the people starting businesses in this country are deliberately choosing not to be downtown. They are opening in the heartlands, in the HDB estates, in the suburban malls, in the industrial parks, anywhere that is not the core of the city. The downtown is expensive, and the small business that cannot afford it, or cannot see the value in it, stays away.

But here is the other half of that fact. The premium customers are concentrated downtown, exactly where the new businesses are not. The people with the highest disposable incomes, the executives, the professionals, the expatriates we described in the last stream, the visitors and the tourists, they cluster in the centre. Raffles Place, Marina Bay, Orchard Road, the new downtown at the waterfront. The money is not spread evenly across the island. It pools in the middle, and it pools there in a concentration that is far greater than the eighty-three percent of businesses staying away would suggest.

So you have a genuine mismatch. A premium pool of customers sitting in the centre, and the vast majority of small businesses choosing not to serve them because it is expensive to be there. That mismatch is the opportunity of this stream, but it is also the trap, and we need to see both sides.

What does the premium downtown customer buy? This is the tier where price stops being the deciding factor. The customer here buys convenience, they buy certainty, and they buy a certain standard of experience. The executive who pays a premium for a lunch does not want a faster, cheaper lunch. They want a lunch they can rely on, in a place that feels right, in a place where they are known. The expatriate family buying furniture for a rental does not want the cheapest sofa. They want the sofa that will be delivered this week, assembled properly, and not fall apart. The visiting buyer wants a service that feels effortless, because their time is worth more than the fee you charge.

This stream is the hardest for a small business to enter, and here is why. It is not the rent that is the real barrier, though the rent is real. The real barrier is that the premium downtown customer does not tolerate inexperience. In the heartlands, a customer forgives a slow service or a rough finish because it is cheap. Downtown, nobody forgives anything. The customer who pays a premium expects the standard that the premium is for, and a small business that cannot deliver that standard will not get a second chance. There is no trial period. There is no sympathetic local customer base. There is a demanding professional who has a hundred alternatives and will not return if you disappoint them once.

So can a small business sell into this stream? The answer is yes, but only if you are genuinely ready. This is a stream you have to be excellent to stand in, not one you drift into. The small business that succeeds downtown is the one that is so good at one thing, not the one that is cheap, so reliable, so professional, that the premium customer trusts it. It is the small law firm that serves corporate clients. It is the boutique consultancy. It is the specialist contractor that the developers call because they know it will show up. It is the chef who runs a twenty-seat restaurant so well that the tables are booked out for a month.

And there is one more note about this stream that most people never consider. You do not have to be physically downtown to serve the downtown customer. The premium customer will come to you, or you can go to them, if you have a reputation. The eighty-three percent of businesses that register outside the CBD are not automatically cut off from the premium money. The premium customer is not loyal to a postal code. They are loyal to a standard. If you can build a reputation for excellence anywhere on the island, the premium customers will travel to you, or they will hire you to travel to them. The geography matters, but the reputation matters more.

### Choosing your stream

We have laid out the five streams, and now we have to look at what it means to choose one, because choosing is the actual job. Most small business owners never choose a stream at all. They open a shop in whatever space they could afford, selling whatever they happened to know how to make, and then they wonder why the money does not come. They are standing in a stream, they just never checked which one it was, or whether it was big enough to carry them.

The first point is this. You cannot stand in all five streams at once. Each stream asks for a different customer, a different product, a different temperament, a different way of selling. The consumer stream asks for identity and referral. The government stream asks for compliance and standards. The B2B stream asks for patience and trust. The foreign-worker stream asks for location and service. The premium tier asks for excellence and reputation. These are not the same skills. The owner who tries to serve all of them serves none of them well, and the market punishes a business that does not know what it is.

So the real question is which stream you are actually built to stand in, not which is biggest. If you are a people person who loves the street and knows your neighbourhood, the domestic consumer stream is your home. If you are a patient, organised person who does not mind paperwork, the government-funded services stream can give you a business that does not disappear in a downturn. If you are disciplined and you like recurring contracts, the B2B stream is the most stable income a small operator can build. If you are willing to go where the workers are and serve them well, the foreign-worker stream is wide open and almost nobody is serving it properly. And if you are genuinely excellent at one thing, the premium tier will pay you for it, whether you are downtown or not.

Let us give you the verdict on each, because you asked for it and here it is. The domestic consumer stream is open to everyone and it will kill most of you, because it is the most crowded and the least forgiving. The government stream is open, but only to the organised, and it is the most defensible once you are in. The B2B stream is open and it is the best place to build stable, recurring revenue, but it rewards patience over flash. The foreign-worker and helper stream is the most overlooked and the most open to a small operator with a good location and good service. The premium downtown tier is real and it pays the best, but it is the hardest to enter and it does not forgive a single failure.

Here is the deepest truth of the whole chapter, and it is a simple one. The money in Singapore is not scarce. The country runs on a domestic economy that is far larger than most owners believe, and it is fed by five streams that all flow every day. The scarce thing is not the money. The scarce thing is the owner who has chosen a stream and built a business that fits it. There are three hundred and seventy-one thousand businesses in this country, and two hundred and thirteen more are born every single day, and almost all of them fail to do this one thing. They never choose. They just open.

You do not have to be one of them. Look at the five streams we have described, look at yourself, look at what you are actually good at and actually willing to do, and choose one. Then build everything you do around that choice. Choose your stream, and you have already done what most of your competitors will never manage. Stand in the wrong stream and you will work yourself to the bone for nothing. Stand in the right stream and the water will do a great deal of the work for you. That is the difference, and it is the whole difference.

---

## Chapter 1, Who is Singapore, and how does it spend?

Singapore has 4.2 million residents. That is citizens and permanent residents, the people who actually live and spend here, and the number in our heads, 6.11 million, is bigger because it also counts the people who come here to work. Forget them for a moment. They are a story for later.

The residents, sorted by age, look like this. About one in eight is a child. One in ten is a student or a young adult just entering work. Roughly three in ten are in the thick of it, twenty-five to forty-four, earning, raising children, buying houses, spending more than they will ever spend again. Another three in ten are the peak earners, forty-five to sixty-four, at the top of their incomes, parents of adults, quietly the richest the country has. And almost one in five, the fastest-growing group on the island, is sixty-five or older.

The median resident is forty-three. That is the whole country in a sentence. Singapore is a middle-aged nation now, already tilting hard toward old, not a young one anymore.

Now the money. Because a demographic map means nothing until you ask how much each of these people has to spend. And here is where the story stops being what people assume. Everyone assumes the money is at the top, in the hands of the very rich. The data says the opposite.

| Household income (2025) | Share of resident households |
| --- | --- |
| Earning ≥ S$30,000/month | **13.4%** (up from 7.4% in 2020, nearly doubled) |
| Earning ≥ S$12,000/month | **51.6%** (up from 38.2% in 2020) |
| **Median** household income | **S$12,446/month** |

Half of all resident households now earn more than twelve thousand dollars a month. Not the top half of a tiny elite, but literally half of every household on the island. Roughly one in seven earns more than thirty thousand. The middle is not a thin sliver of the population. The middle is the whole country.

The real finding is where the business opportunity in an ageing Singapore sits, not that Singapore is ageing, everyone already knows that. It sits where the money sits: in the large, growing middle. And the four waves are not four different threats. They are four shifts in the one thing the middle spends on.

### What the money buys

Follow the money one level down and it stops being abstract. Every five years or so, the government conducts a Household Expenditure Survey, a census that tracks, dollar by dollar, what every kind of family in Singapore actually spends its money on. Picture an interviewer sitting in a living room in Tampines going through a month of receipts with a family of four, then across the island doing the same with a young couple in a one-room flat in Clementi, until the whole country has been weighed. What it tells us is the whole budget. The average household in Singapore spends 5,931 dollars a month. On what?

| Expenditure category | Share of monthly spend |
|---|---|
| **Housing & related** | **29.8%** |
| **Food** | **20.0%** (~$1,422/mo; two-thirds is eating out) |
| **Transport** | **13.4%** |
| **Health** | **~8.0%** |
| **Education** | **~6.8%** |
| **Recreation, sport & culture** | **~5.6%** |
| **Info & communication** | **~4.6%** |
| All other (clothing, furniture, personal care, insurance) | remainder |

Nearly thirty cents of every dollar goes to housing. Twenty cents to food. Thirteen to transport. That is 63 cents of every dollar, before anything is chosen, gone to the non-negotiable. The floor is the floor, and no business is going to persuade a household to spend more on rent.

What is left is the interesting part, and it is where the argument actually lives. The left-over money goes to health, and education, and recreation, and communication. And the detail that will matter to anyone who sells anything is this: two-thirds of the money spent on food, in Singapore, is spent on someone else cooking for you, not on groceries. The hawker, the restaurant, the café, the delivery rider. Singapore did not quietly become a place where everyone eats out because it is lazy. It became a place where cooking is outsourced, because that is the shape of a country where everyone works.

The pie is the shape of the country at one moment. The movement inside the pie, which is the point of the whole chapter, comes next.

### What is moving

A demographic map is not the map. The map is a list of what is standing still. The real question, and it is the only one that matters to a small business, is what is moving, because that is the only thing a small business can beat. A small business cannot out-spend a supermarket on housing. It cannot out-compete a bank on transport. But it can get ahead of a thing that is growing.

Five things are growing, and they grew so fast, so consistently, over five years, that they are not trends. They are a verdict.

| Trending demand | The five-year move |
|---|---|
| **Health & care** | $320 → **$474/mo** per household (**+48%**) |
| **Online purchases** | 4.7% → **11.9%** of total spend |
| **Eating out (F&B)** | $810 → **$966/mo** (+19%) |
| **Private tuition** | $1.4bn → **$1.8bn** (+29%) |
| **Video streaming** | 6.9% → **41.1%** of households |

Health. The average household went from spending 320 dollars a month to 474, an increase of almost half, the biggest jump of any category in the survey, and it is not even close. A visit to the general practitioner is 40 to 70 dollars. A specialist is 150 to 250. Home care is 20 to 25 dollars an hour. And there is nothing cyclical about this. It is the demographic wave in purest form.

Online buying. In 2017, online was five cents of every dollar spent. Now it is twelve. And here is the number that should decide your strategy: more than half of all the money Singaporeans spend online goes to sellers in other countries. Singapore is the most cross-border shopping nation on earth. That is the second most important number in this chapter, and it is a warning and an opening at once. It means the marketplace, the Shopee and the Lazada of it, is already won, by the big platforms and by foreign sellers who can undercut you. But it also means the one thing a foreign seller cannot do, a local seller can. The race is not to sell online. The race is to sell online to someone a foreign seller cannot serve.

Eating out. Two-thirds of food spend, remember, and the delivery market is three billion dollars a year and still growing. The meal you eat is increasingly arrived by scooter. The habit is not going anywhere. It has nothing to do with income. It is structural.

Tuition. This is the irony of the whole fertility crisis hiding in a single number. The education bill for the average household rose, but the tuition industry, the private one, is worth 1.8 billion dollars, and it grew by twenty-nine percent in five years, and by sixty-four percent since 2013. The average household now spends 104 dollars a month on private tuition. And the gap inside that number is the whole story of the fertility concentration: the top-fifth of households spend 162 dollars a month, the bottom-fifth just 36, a four-and-a-half-fold spread, and the widest inequality gap in the entire spending map. Fewer children does not mean less money on children. It means far more money on each of the few children, and the families with the most money spend the most on the fewest.

And streaming, the sixth of the movers, does not belong in this list at all if you think it is about entertainment. Six point nine percent of households streamed in 2017. Forty-one percent stream now. Netflix charges 16, 23, 30 dollars a month in Singapore. A household with two services is paying 30 to 60 dollars a month, as much as it used to pay the cable company, for a thing that did not exist fifteen years ago. And the people doing the growing are the young, the eighteen-to-twenty-fours, forty-three percent of whom subscribe and intend to keep going. The streamers are, it turns out, the opposite of the health spend. Health grows because the country ages. Streaming grows because the country's young, and the young are the part of the population that is disappearing.

That is the pattern, and it is the entire chapter in miniature. The moving money splits two ways. It goes to the digitised, the online, the streamed, the delivered, and it goes to the old, to the health and the care and the tuition of a country that is out-living itself. And the trick, if you are a small business, is to be on the side of the country as it actually is, not as it pretended to be.

### Where the attention goes

There is one more layer above the money, and it is the one the money answers to. The money does not fall to a category because the category is a good idea. It falls to a category because someone, somewhere, is spending their attention on it. And attention, unlike money, is the truly scarce thing, because it is the one resource you cannot print.

The old spend their hours in a way they never have before. The state has spent 800 million dollars building something called Active Ageing Centres, community drop-in hubs for seniors, with exercise classes, karaoke nights and a free cup of coffee waiting, and in five years it went from 119 of them to 223, reaching 8 in 10 seniors. And at the same time the seniors are moving onto the screens. Ninety percent own a smartphone now. Some of them spend ten to fourteen hours a day on them, on the streaming and the video calls and the social media, filling the hours that work used to fill. That is a market, not a lonely fact about old people. The whole silver economy, the monitoring, the meals, the companionship, the classes, is built on the simple, giant fact that a retired person has more hours in a day than anyone else in the country, and every hour is a slot waiting to be filled.

The young people who have chosen not to have children have done something even more interesting. They have not stopped spending. They have redirected. The money that would have gone to a child, to the school and the nappies and the enrichment, it did not vanish. It went somewhere else. It went to the dog, and Singapore's dog population is growing two percent a year and its cat population seven percent a year, and the pet-care industry, worth 350 to 400 million dollars, is largely a creation of young households who are raising a pet the way their parents raised a child. It went to the table, and four in ten Singaporeans eat out at least once a week, and half of the young eat out constantly. The fertility crisis is a huge, silent reallocation, not a shrinking of spending, out of nappies and into restaurants and dogs and trips. The childless are not poor. They are the most free-spending adults in the country, on the wrong categories.

The single householders, meanwhile, are each running a household of one, with no one to share the cooking, the errands, the decision, the argument. They are buying the services that replace a missing person, the ready-to-eat meal, the delivery, the pet that keeps the house from being silent. The whole economy is shifting from families that share a thing and a cost, to a series of individuals who each buy the whole thing alone. And that is not a loss. That is a hundred and sixty thousand new demand points.

The attention is the first domino. The money is the second. If you can see where the attention is going, you do not need to predict the money. You have already seen it land.

---

## Chapter 2, Where does the money go beyond spending?

The spend side tells you what people buy. But money in Singapore does not stop at the till. There is a second half of the map every business forgets to ask about, because it is invisible: where the money is saved, and where it is borrowed. These are not a side-note. They are the demand map pulled forward and in reverse, and they move with the same four waves.

### Where the savings go

Singapore does not spend everything it earns. It saves. It saves at a rate that is close to half of everything the country produces, about 47 percent of GDP, one of the highest rates on earth. Put it the way an accountant would see it: for roughly every two dollars the country brings in, one of them never makes it to the shops; it is put aside instead. And when a country saves at that rate, the savings are not idle. They are the second largest thing people do with their money, after spending, and they have their own destination.

The biggest single pool of it is locked in the Central Provident Fund, the CPF, the state's forced savings system that every working Singaporean pays into automatically. A slice of every salary is swept into it before the money ever reaches the bank, from the first day of work to retirement, and it cannot be touched freely. That fund now holds 677 billion dollars. That is three-quarters of the country's entire GDP, not a number to skim past, sitting in a system every working Singaporean is compelled to contribute to, and it is the largest single repository of personal wealth on the island. Almost nothing in the spend-side of this chapter touches it.

The rest of the savings go somewhere too. They go into insurance policies that bundle investment with protection. They go into unit trusts and exchange-traded funds, into the savings bonds and treasury bills the government sells, into the real-estate investment trusts that pay out a dividend like clockwork, and, most of all, into property, which is the single asset Singaporeans trust above all others. And here is the thing a business needs to understand: where the savings go is decided by the same four waves as the spending. The savings are not exempt from demography. They are the purest expression of it.

The person who is going to retire is trying to turn their savings into income, into something that pays out while they live, and every product that does that, the annuity, the dividend-paying trust, the instrument that sends a cheque every month, is a beneficiary of the ageing wave. The young couple with no child has no education to endow, so the money that their parents would have set aside for a child's school and a child's marriage goes somewhere else, into the property, into the portfolio, into the savings for their own old age. Then there is the sandwich generation, the adults squashed in the middle, caring for an ageing parent on one side and a child on the other, with their own working life between. They are saving for two futures at once, and the long-term-care policies and the MediSave top-ups, extra money poured into the medical savings account the government runs for every citizen, and the retirement-account top-ups are where that worry gets priced. And the senior, at the end of it, is not saving at all.

They are undoing it, turning the accumulated wealth of a working life back into income, buying the care and the decumulation that this chapter sized in the care section.

The savings are not a thing apart from the demand map. They are the demand map in reverse. The four waves decide what the spending becomes, and they decide, just as surely, what the savings become. A business that only reads the monthly bill is reading half the story. The other half is the accumulated money, the largest half, and it is moving with the same tide.

### Where the borrowing goes

There is one more place the money comes from, and it is the most revealing of all, because it is the money people spend before they have earned it. Singapore does not pay for everything with savings. It borrows. And the things it borrows for, and the places it borrows from, are a map of what the country wants badly enough to go into debt for.

A Singapore household now owes about 108 dollars for every 100 dollars of income it earns in a year. That is below the country's own ten-year average, not reckless, and it is mostly a single kind of debt. The home loan is the whole shape of Singapore borrowing, it is about 70 percent of everything a household owes, and it is the debt the country takes on the most willingly, because it is debt against the one asset everyone trusts. When a young couple borrows half a million dollars, and the average home loan for a home owner in their twenties is now 523,000 dollars, they are not really borrowing to consume. They are borrowing to buy into the thing Singaporeans believe in more than any other: property. The mortgage is how the saving country turns its future income into the one asset it refuses to be without.

But the second bucket of debt is where the story gets interesting, because it is not the house. Personal loans have grown for nine straight quarters, to 118 billion dollars, and they are not home loans. They are the debts that pay for the things the spend-side of this chapter described, and they are driven, quarter after quarter, by two things: the car, and the other unsecured borrowing that sits beside it.

### The car, the most expensive want

The car is the single most misunderstood number in Singapore's household economy, and it is the reason every other statistic about the country's wealth feels wrong. In most of the world, a car is a purchase you save toward. In Singapore, the right to own a car is a luxury so scarce it is auctioned, and the price of that right has become one of the highest single prices in the world.

Consider what a car actually costs in Singapore in 2026. Before you buy the car, you must buy a Certificate of Entitlement, the COE, the state's auctioned right to put a vehicle on the road, the reason car prices here are the talk of the region. In 2025 that right sold for a record 107,889 dollars, and by 2026 it reached 129,000 dollars for the smallest category of car. That is just the *permission*, not the car, not the tax, not the insurance, not the fuel. A modest Singapore car, all in, can pass a quarter of a million Singapore dollars, and the certificate alone is worth more than the car itself for most models. Singaporeans do not buy cars. They buy a ticket, and the ticket is the most expensive part.

And they borrow to do it. The car loan in Singapore is a hire-purchase loan, offered by the same banks that lend for houses. A bank will finance up to seventy percent of the car's value, for up to seven years, at a flat rate around 2.5 to 3 percent, the effective annual rate closer to five. The average Singaporean borrowing to put a car on the road is not paying for it. They are buying a monthly payment, a few hundred dollars a month for six or seven years, for the right to drive something that loses a third of its value the day it leaves the lot, on top of a certificate that expires in ten years and is then gone entirely. It is the one purchase in the whole country where the depreciating asset, and the borrowing used to buy it, and the debt that follows the buyer for years, all point the same direction.

What does that tell a business? That the car is the thing the Singapore household is most willing to borrow for, beyond housing. It is the premium display of the country's wealth, the visible proof of the two-income household, of the promotion, of the position. A household that buys a car is signalling that it has arrived, and it is willing to go into debt for years to prove it. When a business sees a car, it is seeing a household that is already committing a large slice of its future income to a monthly payment, and that is both the sign of a household with confidence, and the sign of one with very little left over for other big-ticket spending. The car is the centre of the whole economy of borrowed desire, and no map of Singapore demand is complete without it.

### Where they borrow from

The borrowing, like everything else, has a specific and divided geography. There is no single "loan." There are four different places a Singapore household goes, and they serve four completely different kinds of desire.

**The bank.** The banks are the biggest door, and the most respectable. The home loan comes from a bank, DBS, OCBC, UOB, and the foreign banks, and so do the car loans and the personal loans. The bank is where the country borrows for the thing it can defend, the house and the car. The bank is the sensible debt: the mortgage at a rate that today can be as low as around 1.3 percent, the car loan at 2.8, the unsecured personal loan advertised at 1.3 to 1.8 percent and repaid in a matter of a few hundred dollars a month. The bank lends to the household that can prove it can repay, and most of Singapore's debt sits here, because most of Singapore's debt is a house.

**The government.** The second door is the state itself. For the public-housing buyer, the loan comes from the HDB, the Housing and Development Board, the government agency that builds and sells the flats eight in ten Singaporeans live in, at a fixed concessionary rate pegged to the CPF, currently 2.6 percent. This is the loan that makes the great middle possible: the HDB loan is why a young couple in their twenties can borrow half a million dollars and carry the country's highest average home loan balance without defaulting, at a delinquency rate of a tenth of a percent. The state is one of the two biggest lenders to the middle, not a neutral observer of Singapore borrowing, and it lends the cheapest.

**The card.** The third door is the credit card, and it is the one that quietly and constantly grows. Unpaid credit-card and charge-card balances, the money Singaporeans spend and do not pay off, now stand at more than nine billion dollars, the highest in ten years, and they are still growing at close to seven percent. The card is the spending that is neither planned nor justified, not the car and not the house: the dinner, the holiday, the phone, the thing that was bought before the money existed. The card is where the spend-and-save, the aspirational and the actual, collide.

**The licensed moneylender.** And at the bottom of the whole ladder is the door that no one announces, the licensed moneylender, the legal, regulated high-cost lender that serves the borrower no bank will take. The moneylender is the borrowing of the last resort: the household that cannot borrow from a bank, at a rate that is a multiple of what the bank charges. It is the smallest door by volume and the most consequential by cost, and it is the clearest signal in the whole map of where the money is not, the bottom of the income ladder, the households for whom the four waves, and the buying on debt, and the aspirational spend, are all far away.

The borrowing is the demand map pulled forward in time, not a side-note to it. The savings told you what the country keeps. The debt tells you what it wants badly enough to pay for tomorrow. And the deepest lesson of it is the car: the thing a household is most willing to borrow for, in a country that has the world's most expensive permission to drive, is the clearest single proof of where the confidence, and the borrowed money, actually goes.

---

## Chapter 3, The waves: how the country is changing

Now the waves themselves. There are four of them, fertility, the people who replace the missing children, the ageing, and the shrinking household, and one force underneath that changes everything: the remaking of care. They are not four separate stories. They are one story: a country that has stopped having children is, at the same time, a country that is ageing, and a country whose household is collapsing inward. Follow them in order and the shape becomes obvious.

### The first wave: fewer children



![The four demographic waves.](print/figures/fig-four-waves.pdf)



The deepest wave, the one underneath all the others, is the collapse of the fertility. It is so low that it has stopped being a metaphor. The average Singaporean woman has fewer than one child.

Here is what that means in ordinary terms. Demographers measure a country's baby-making with a single number called the total fertility rate, the average number of children a woman can expect to have over her whole life. If it sits at 2.1, a population keeps its size, because every couple roughly replaces itself. Below that, and the country quietly shrinks from within. Singapore's number is 0.87, less than one child per woman, so far below replacement that a large share of couples will never have a child at all, and most of the rest will stop at one. Picture the little boy in a buggy at the mall on a Sunday morning, waited on by parents who had planned, and planned, for the sibling who never came.

| The fertility collapse (2025) | Value | Confidence |
|---|---|---|
| Resident total fertility rate | **0.87** (down from 0.97) | High |
| Resident live births | **27,393, down 11.1%** | High |
| Total live births | **29,864, down 11.4%** | High |
| Natural increase (births − deaths) | **3,365** (from 22,323 in 2015) | High |
| Chinese-community natural balance | **−3,071** (more deaths than births) | High |

The rate is 0.87, lower than Japan, lower than South Korea, the two countries that have been the global byword for the end of it. Singapore is now the end of the line for it.

And it is not going to be a wedding, or a baby, or the school, or the whole base of a market. Take away the people who come from other countries, and the citizen population is already not replacing itself. It is already a shrinking it.

What does a fertility collapse do to demand? It is not what people assume. It does not kill every young market. There are two offsets, and they matter. The first is immigration, the people who come from outside to replace the children the island isn't having, and that is a whole story of its own. The second is the concentration. Parents who have a child, when the country has almost no children, spend everything they have on the one they have. The base is shrinking. The spending per child is rising. The tuition boom is the proof of it. The child, once a rare thing, becomes the most expensive rare thing the parents will ever buy.

It is a lagging. The child who is born today is a consumer in five years and a worker in twenty. So the direct market effect, the thing a business can act on now, is the education and the parenting and the child care. And the other effect is the one this chapter is really about, because fewer births are the other side of the same coin as a rising elderly share. A country is not "fertility is down" and "population is ageing" as two separate problems. They are one mechanical connection. Fewer babies in, more old people out.

### The second wave: the people who replace them

But Singapore has not been shrinking. Its total population grew to 6.11 million in 2025. The whole trick is that the country is not making its own people anymore, and so it is importing them, and it is importing them in two utterly different versions.

| The replenishment (Dec 2025) | Count | Confidence |
|---|---|---|
| Total foreign workforce | **1,635,700** | High |
| Employment Pass (foreign talent) | **203,300** | High |
| S Pass (mid-skilled) | **178,900** | High |
| Work Permit (total) | **1,222,700** | High |
| Work Permit (migrant domestic workers) | **316,900** | High |
| Foreign workforce share of total labour force | **~40%** | High |

The top is foreign talent. About 203,000 Employment Pass holders, the professionals and managers and specialists, who now must earn a minimum of 5,600 dollars a month, more in finance, rising to 8,600 by middle age. India is the largest single source, roughly a quarter of them. These are not workers. They are the global engine's high earners. They are the people whose payroll feeds the premium demand of the previous chapter, and they are by every statistical measure the same as the affluent resident. They eat, they spend, they buy, they are the customer.

The bottom is the labour force. Over 1.22 million work-permit holders and mid-level S-Pass workers who build the buildings, staff the kitchens, do the work. They earn a little. They send a huge share of their wages home. And locally, almost nothing flows back through them into the economy beyond the essentials. And the migrant domestic workers, 317,000 of them, the third group, are not really consumers at all. They are the opposite of the customer. They are the labour that frees the working household to have attention and money to spend. The dual-income family only exists, only works, because the domestic worker is doing the care the family no longer has time for.

The mistake is to let the two inflows take the whole screen, because neither one is the actual engine of the market. The engine of the market is the middle of the island, the resident household earning twelve to thirty thousand a month, half of all households, the working families who live and spend and raise the children. The people who come from outside add to it. The waves are about the people who are already here.

### The third wave: the grey

One in five Singapore citizens is now 65 or older. It was one in eight ten years ago. And it is not stopping; it is headed to one in four.

The ageing is three separate markets, and the failure to separate them is the single most expensive mistake a business can make with the senior. There is the silver economy, the senior as a consumer, buying independence, health, care, financial planning, because they are going to live longer than any generation before them. There is the working elderly, because a striking sixty-seven percent of people between 60 and 64 are still employed, and fifty percent of those between 65 and 69, one of the highest rates in the world, and they are at the same time both a labour pool and a customer base. And there is the senior who lives alone, 88,000 of them, more than double what there was in 2015, who buys everything, the meals, the safety, the transport, the monitoring, because there is nobody at home to do it.

A 65-year-old who is still working, and an 82-year-old living alone, are not the same customer. They are almost not the same species of customer. The ageing is real. The segmentation inside it is the opportunity.

### The fourth wave: the house

And the household itself is collapsing inwards. There are 1.49 million resident households, and they are getting smaller, more numerous, more single. The single-person household is a distinct object with its own spending rhythm. There is no one to split a dinner with, so they buy the single-serving, the ready-to-eat, the delivery, the service that replaces the missing other. The decline of marriage and the rise of the never married means more people spending their best earning years alone, each one running a small, individual economy. The shrink of the household is, in plain, a shift from shared consumption to individual, service-bought consumption, and the whole market for convenience and loneliness and delivery is downstream of that.

### The remaking of care

Which is the fifth wave, and the one with the most structural force of all, because it breaks something that used to hold the whole country.

Ninety-five percent of working-age adults in Singapore say it is their responsibility to care for their parents. The number is rising. It is one of the strongest familial norms in the world. But the capacity to actually do it, to give that care for free inside the home, has collapsed. Because the adult who is supposed to care is also working, and also raising a child, and by 2030 one in four of them is the sandwich generation, caught between an ageing parent and a child, in a two-income household with no one at home.

Care is being monetized. This is the quietest and most structural commercial shift in the whole country. The care that was once given by a daughter for nothing must now be bought, because the daughter is working and has no time. Think of the 45-year-old who clocks out at six, hurries to collect her own child, then drives across town with a container of food for her ageing mother, the meal the mother will reheat alone, because there is no one left in the house to cook it with her. The daughter wants to help. She simply has no hours left. And the state is actively building the market, not just watching. The Home Caregiving Grant is the state's direct payment to a family that is caring for a senior with serious disability, up to 600 dollars a month, and it is being expanded in April 2026. The state is writing a check to make sure the market exists.

So here is the silver economy sized, and it matters because the number everyone quotes is a lie. The US 72 billion dollar "silver economy" that all the media cite is the total spending power of every over-60, not a market, including the groceries and the housing and the things any business would serve anyway. It is a number that makes a headline and tells you nothing.

The real market is the layer beneath it, the services a business can actually own, and it has to be built from parts. About 6.6 percent of Singaporeans over 65 have a serious disability, the ones who need care, about 52,000 people today. About 75 percent of the care they receive is informal, unpaid, family, and the paid help mostly comes through 317,000 migrant domestic workers hired privately, not through an agency. Only about twelve to twenty-two percent of the care-needy ever buy licensed care, the agencies, the day care, the home care. That is the whole market a small business can actually touch. And it comes to 280 million to 850 million dollars a year, and it grows with every year of ageing, and it is the most structurally-backed, state-supported demand in this entire chapter.

And the prices inside that market are now real, published, and knowable, which is itself an opportunity. The day-care centre charges from 55 dollars a session, which is why the demographic chapter's "900 to 1,400 dollars a month" is not a guess but the shape of the actual bill a working family faces. Dementia day care runs a little higher, from 63 dollars a session. Home care comes by the hour, from 23 dollars, and the state's own Enhanced Home Personal Care programme prices a supervised personal-care shift at 176 to 222 dollars, with a subsidized rate that can fall to nearly nothing for a low-income family. At the top sits the nursing home, 2,000 to 4,500 dollars a month before subsidies. And the Home Caregiving Grant, the cheque the state writes to the caring family, rises to 600 dollars a month from April 2026. Every one of these is a printed, public price that a family must pay and a business can charge. The care market is a priced, subsidized, and growing one, not a mystery, and the pricing is now on the record for anyone who wants to build for it.

---

## Chapter 4, So what?

None of these waves tells a specific business what to do. That is not what they are for. But they change what it is to be on the right side of a market, because they say who is going to be rich and who is going to be poor.

The wave tells you which words are becoming scarce. The word that an ageing country is running out of is dignity and independence, so the business that owns "aging well" is on the side of the tide. The word a shrinking household is running out of is convenience, and the person who owns the word "easy" for a single person is riding the current. The word the sandwich generation is running out of is time, and the whole business of care is the business of buying time back.

The savings carry the same warning. A business can read the demand map from the monthly bill, and that is real, and it is half. The other half is the accumulated money, and it is moving with the same waves, toward the income-producing instruments of a retiring country, toward the property of a childless one, toward the two-future savings of the sandwich generation. The business that sees only the spending is reading the country through one eye. The savings are the second, and they point the same way.

And the borrowing is the third eye, and it points the same way too. The household that is willing to go into debt for the car, for the house, for the thing that proves it has arrived, that is a household betting on its own future. Where the borrowing goes is where the confidence is. The car tells you where the desire is, the bank and the HDB tell you where the faith is, the card and the moneylender tell you where the strain is. Read the borrowing and you read the country's confidence in its own years ahead. It is the demand map pulled forward in time, and it is moving with the same four waves.

These are not trends. They will not reverse because someone woke up and changed their mind, or because the government makes one more announcement. They are facts already in motion, and the business that rides them for decades, and the business that fights them swims upstream. The people are already here. The money is already spent, and the rest of it is already saved, and the borrowing is already committed. The attention is already moved. The only remaining question is whether you are on the side of the wave or the wrong one, and it is the rare moment in a market when that question has a clear and hard answer.

### What the map does not say

Read these waves the wrong way and they will quietly sell you a false version of your market. Here are the mistakes to avoid.

Ageing does not mean every over-60 is one market. The 60-year-old who is still working and the 82-year-old who lives alone are not the same customer, and the business that treats them as one makes the single most expensive error in this chapter.

Demography is a headwind, not a verdict. A falling birth rate does not kill every education business. A rising elderly share does not guarantee every care product succeeds. The waves set the direction; they do not do the work.

The household average is a lie if you read it as a truth. The average household size hides the whole diversity. The useful number is the composition.

And the care market, the thing this chapter keeps coming back to, is a built number, an estimate, a floor, not a single clean figure anyone publishes. The 72 billion dollar headline is senior spending power, not a business you can enter. The 280 to 850 million is the layer a business can actually own, and even that leaves out the migrant-worker channel and the healthy majority's discretionary spend, which would multiply it. It is the lower bound, and the lower bound is the number you can trust.



### Reading the waves as a single customer

The waves are statistics until you bring them down to a person. It is worth doing that once, in full, because it is the difference between knowing the country is ageing and actually understanding who you are serving.

Take one customer, built from the real profile of the median resident. She is forty-three, the median age of the country. She works, and her household earns around the median, about twelve thousand dollars a month. She is part of the 51.6 percent of households earning more than twelve thousand. She has a parent who is now in her seventies, part of the senior wave, and that parent wants to keep living independently in her own HDB flat. She has one child, part of the smaller family, and the household is not going to get bigger. She is, in one person, every wave this chapter has described: the ageing parent, the shrinking household, the sandwich generation, the saving country.

Now ask what this one customer needs. She does not need "demographic trends." She needs someone who can help her parent age well at home, not institutional care, but dignified, independent living, supported. She needs convenience, time is the scarcest thing she has. She needs a business she can trust and refer, because her time is short and she cannot afford a wrong choice. And she has the money to pay for it, the 51.6 percent household income, the accumulated savings, the willingness to spend on the people she loves.

This is the whole demographic map in one person. The waves are not abstract; they are the shape of her life. And a small business that serves her, the senior's carer, the home-convenience provider, the ageing-well specialist, is riding every wave at once. The country is ageing into her parent, shrinking into her household, and running out of time in her calendar, and she has the money to pay for the business that helps.

The lesson of reading the waves as a customer is that the statistics and the person are the same thing. The ageing share, the household size, the savings rate, they are not separate trends; they are one customer's life, measured from four directions. The business that can see the customer behind the wave is the business that can serve her. The business that only sees the statistic is the business that will not understand who it is actually serving.

---

### Where this goes

The next chapter overlays this demographic ground on the map of who already competes there, from the first chapter, to show where each wave meets a position a small business can actually take. The one genuinely open question, the gap worth chasing, is the local-spend split of the foreign workforce, how much of that global engine's payroll and that work-permit inflow actually circulates in the domestic economy. It is the number that would tell a small business whether the premium tier or the mass middle is the surer bet. Everything else here is now measured. That one, in the end, is the number worth the next chapter.

---

## The care economy, the wave that changes everything



![The care economy: the wave that changes everything.](print/figures/fig-care-economy.pdf)



---

There is a forty-five-year-old woman who leaves her office in Raffles Place at six o'clock, takes the MRT to Toa Payoh to collect her own child from the childcare centre, then drives with a container of food across town to her mother's flat. She reheats the meal, sets it on the table, and leaves before it gets cold, because she still has a report to finish and a child to put to bed. She does this three nights a week, and she is not unkind, and she is not neglectful. She is simply out of hours. Her mother will eat the dinner alone, because there is no one left in the house to cook it with her.

That woman is not a sad story. She is the most important customer in Singapore right now, and she is the reason a whole economy exists that almost nobody has named.

We spent the last part of this book establishing the terrain. Who is here, what they earn, what they spend, where their attention goes. We met the four demographic waves, the collapse of fertility, the imported people who replace the missing children, the ageing, the shrinking household, and we saw that they are really one story: a country that has stopped having children is, at the same time, a country that is ageing, and a country whose household is collapsing inward. This chapter takes the deepest of those waves and pulls it out of the statistics and onto the ground. It is about the care economy, and it is the one part of the demographic story where a small business owner can actually stand and win.

Let us be plain about why this chapter matters more than the others. Every other wave we met is mostly a warning. Fertility tells you who is not coming. The household tells you who is buying alone. But care is not a warning. Care is an opening. It is the wave that breaks the thing that used to hold the country together, the free, invisible, unpaid work of a family looking after its own, and it is the wave that turns that broken thing into money a small business can earn. Understand it right and you are not fighting the tide. You are standing where the tide has to go.

---

### Why ageing is the single most powerful structural force in Singapore

Let us start with the one number that should decide more of your strategy than any other. The median resident of Singapore is forty-three years old.

Read that number slowly, because it is the whole country in a single line. The median is the person in the exact middle of the population, half of everyone is younger, half is older. When that number is forty-three, it means the country is middle-aged now, already tilting hard toward old, not young anymore. And unlike a business cycle, or a fashion, or a technology, this is not going to reverse. There is no announcement that will un-age the country. The people are already here, and their age is already set.

Now look at the two forces underneath that number, because they are the engine.

The first is the collapse of fertility. You remember the number from the previous part: the average Singaporean woman is now having fewer than one child. The total fertility rate, the average number of children a woman can expect over her whole life, is 0.87, lower than Japan, lower than South Korea, the two countries that have been the world's byword for the end of it. Singapore is now the end of the line for it. A population needs a rate around 2.1 to replace itself; below that it quietly shrinks from within. At 0.87, a large share of couples will never have a child at all, and most of the rest will stop at one. Fewer babies in. That is the first half of the machine.

The second force is the ageing itself. One in five Singapore citizens is now sixty-five or older. It was one in eight ten years ago. It is not stopping; it is headed to one in four. And here is the mechanical connection that too many people miss. A country is not "fertility is down" and "population is ageing" as two separate problems. They are one machine. Fewer babies in, more old people out. Every year the balance tips further. The children who would have filled the schools and the workplaces were never born, and the people who are already here are living longer than any generation before them. The two ends of the country are moving in opposite directions, and the middle is being squeezed between them.

Why does this matter for a business? Because ageing is the ground the whole country now stands on, not a trend and not a market segment you can ignore or choose to sit out. Consider the shape of it. The fastest-growing group on the island is the sixty-five-plus. The number of seniors living alone has more than doubled since 2015, there are about 88,000 of them now, people running a household of one with nobody at home to help. Nearly a third of HDB households are headed by a senior. And the state, which reads these numbers better than anyone, is building for it, not merely reacting to this, spending eight hundred million dollars on community drop-in hubs for seniors, pouring subsidies into care, writing cheques to families who care for a parent. The whole machinery of the country has turned to face the grey.

And here is the part that makes ageing different from every other force a business faces. It is not fast, but it is certain. A business cycle turns in months and you can lose to it. A competitor across the street can beat you in a year. But a population is a thing that is already decided, long before it shows up in your profit and loss. The seniors who will need help in 2035 are already alive. They are already in Singapore, already ageing, already accumulating the savings that will pay for their care. There is no uncertainty in this wave. The only question is whether you are on the right side of it.

But, and this is the crucial caveat, the one almost every business gets wrong, an ageing population is, by itself, a crowd of people, not a market. The crowd is real, and it is growing. But what any of them will actually pay for, and how much, and who they will pay it to, that is decided by something much more specific, not by the headline, and that specificity is the whole subject of this chapter.

---

### What the care economy actually is

Every few months, some report or another announces the size of the "silver economy", the spending power of the over-sixties, and the number is always enormous. In the global press you will see figures like seventy-two billion dollars for a region, or the total spending of every senior, and the implication is that a vast ocean of money is waiting for anyone who will dip a bucket in it.

The seventy-two-billion-dollar number is a lie. Not a malicious lie, but a misleading one, and it will cost you dearly if you build your business on it. Because that number is the total spending power of every person over sixty, not a market, including their groceries, their rent, their electricity, their transport, the same things any business would serve anyway. A senior's grocery bill is a supermarket customer, not a care-market opportunity. A senior's housing cost is a landlord, not a care-market opportunity. The seventy-two billion tells you that old people spend money, which you already knew, and it tells you nothing about what a care business can actually own.

The real market is the layer beneath it. It is smaller, it is harder to see, and it is the only layer a small business can actually stand on. Let us build it from parts, the way you would size any real market, and you will see how small and how specific it is.

Start with the people who actually need care. Not every senior needs care. The healthy majority, the sixty-five-year-old who still works, drives, cooks, and plays mahjong with her friends, does not need a care service; she needs groceries and entertainment and transport, which are other businesses. The people who need care are the ones with a disability serious enough that they cannot manage the ordinary day on their own. In Singapore, about 6.6 percent of people over sixty-five have a moderate-to-severe disability. That is the group that genuinely needs help. At current numbers, that is roughly fifty-two thousand people. Not two million. Fifty-two thousand. That is your starting market, and it is the floor that the billion-dollar headlines are built on top of.

Now ask the question that decides everything: of those fifty-two thousand, how many are actually paying for care, and to whom?

The answer is the most important single fact in this chapter. About seventy-five percent of the care those people receive is informal. That means unpaid. That means family, the daughter who rushes across town with a container of food, the son who takes a day off work, the spouse who does everything. It means the care happens inside the home, by people who are not paid and who are not running a business. Only about a quarter of the care-needy's help is paid at all, and a large share of even that paid help goes to the migrant domestic worker, the live-in helper, not to an agency or a licensed care service. The licensed, professional paid layer, the home-care agency, the day centre, the residential facility, the meal service, the monitoring service, is what a small business can actually own. And that layer, the whole of it, is estimated at somewhere between two hundred and eighty million and eight hundred and fifty million dollars a year.

Let that sink in, because it is the correction to every headline you have ever read. The care economy that a business can actually enter is a few hundred million, spread across home care, day care, residential care, meals, and safety monitoring, not seventy-two billion. It is a real market, and it is growing with every year of ageing, and the state is actively building it with subsidies and grants. But it is a river with very specific banks, not an ocean.

Here is the beautiful part, and it is the part that should make a small business owner sit up. That paid layer, small as it is, is not small relative to what a single business needs. A market does not need to be billions of dollars to support one excellent business. It needs to be big enough for the customers you can reach, in the geography you can serve, to sustain you, and the care market, precisely because it is so local, so word-of-mouth, so trust-based, is exactly the kind of market where one good business in one neighbourhood can own its patch. The river is small, but it flows through every neighbourhood in the country, and almost nobody has built a reliable boat on it yet.

So here is what the care economy is. It is the paid layer of care for the roughly fifty-two thousand seniors in Singapore who need real help, sitting on top of a much larger mass of unpaid family care, and it is worth a few hundred million dollars a year and growing. It is the layer a business can actually own. Everything else, the groceries, the housing, the trips, is someone else's market.

---

### Who the customer is

Now we come to the part every business owner wants to know: who is actually paying, and why.

The first thing to understand is that the customer is almost never the senior. It is the senior's adult child. This is the single most common mistake in the entire care market, assuming the person who needs care is the person who buys it. In Singapore, that is usually wrong.

Think about who is in the position to pay. The paid layer of care is bought by someone with money, someone with a parent who needs help, and someone with no time. That is the sandwich generation, the working adult in the middle, squeezed between an ageing parent on one side and a child on the other, with their own working life between. Ninety-five percent of working-age adults in Singapore say it is their responsibility to care for their parents. It is one of the strongest family norms in the world. But the capacity to actually do it, to give that care for free inside the home, has collapsed, because the adult who is supposed to care is also working, and also raising a child, in a two-income household with no one at home. By 2030, one in four working adults is expected to be in that squeezed position.

The sandwich generation is the customer. And the customer's problem is that they have no hours, not that they do not want to care. The forty-five-year-old woman we opened with wants to be a good daughter. She simply has nothing left to give. Every paid care service exists to buy back her time, and it is she, not her mother, who makes the decision, signs the cheque, and worries about whether it is good enough. Sell to the daughter, and you sell to the person with the money and the anxiety. Sell to the mother, and you are selling to someone who may have neither.

The second customer is the shrinking household. You remember the shape of the country from the earlier part: the household is collapsing inward. More households, more single-person households, each one running a small, individual economy with no one to share the cooking, the errands, the decision. The senior who lives alone is the most extreme version of this, 88,000 of them, more than double what there was a decade ago, each one buying everything because there is nobody at home to do it. The meal, the safety check, the transport, the monitoring, the companion who comes to sit. Each of those is a service that replaces a missing person. And a household of one does not just need services; it needs services it can trust, because the person who lives alone is letting the provider into her flat, and she will only let in someone she trusts.

The third customer is the person with no time, which, in a country where everyone works, is almost everyone. Two-thirds of the money Singaporeans spend on food is spent on someone else cooking it, because cooking is outsourced in a country where everyone works. The same logic drives care. The working adult has outsourced the care of the parent, the way she has outsourced the cooking and the cleaning and the childcare. The live-in domestic helper is the most visible version of this, about one in five households has one, 317,000 of them across the island, but the paid care service is the professional, specialised version. It is the outsourced care of a family that has more obligations than hours.

Notice what all three customers have in common. They are not the elderly. They are the working middle of the country, and they are buying the same thing: time back. The care economy is, at its core, the business of selling time to people who have run out of it. That is why it is structurally backed. It does not depend on a fashion or a whim. It depends on a working adult with a parent who needs help, and there are more of those every year, and no amount of marketing is going to make the parent need less help.

There is one more customer worth naming, and it is the one people forget because it is not about the elderly at all. The care economy, in its widest sense, includes the care of anything that depends on people being too busy to do it themselves. The pet, for instance. The money that used to go to a child has gone to the dog and the cat, and the pet-care industry, worth three hundred and fifty to four hundred million dollars, is largely a creation of young households raising a pet the way their parents raised a child. The dog needs walking when nobody is home; the cat needs feeding on the weekend. That is care, and it is bought by exactly the same person, the busy adult with money and no time. Keep the definition wide enough and the customer becomes the whole working country.

---

### The specific openings

So the market is real, it is specific, and it is anchored on a working adult who needs time back and has a parent, or a pet, or a household, that needs care. The question now is the one that actually matters: what do you build?

Here is the level of the answer. This chapter cannot tell you exactly which business to start; that is the work of your own map and your own ground. But it can name the openings that the structure of the country has created, and it can tell you what each one requires. These are the specific words a small business can own, and each one is a hole in the market that almost nobody has filled well.

**The dementia-specialist carer.** This is the deepest and most defensible opening in the whole care economy, and it is the one most businesses run from, because it sounds hard. It is hard. But that is exactly why it is an opening. Caring for a person with dementia is not like caring for a person who is merely old. It requires patience, training, and a way of working that general carers do not have. The family of a person with dementia is desperate, not for a generic carer, but for someone who understands the condition, who will not panic, who knows how to redirect and soothe. They will pay more, they will be more loyal, and they will refer you to every other family in the same boat, because the dementia family network in Singapore is tight and it talks. General home care is a commodity, competed down to an hourly rate. The dementia specialist is a position nobody can undercut, because the trust is specific and hard to build. If you want the highest-margin, most defensible word in the entire care economy, this is it.

**The ageing-in-place consultant.** You remember that almost three-quarters of senior care is informal and unpaid, happening inside the home. Ageing in place is the idea that a senior stays in her own flat, in her own neighbourhood, instead of moving to a facility, and it is what most seniors and most families want, and what the state is actively encouraging. But ageing in place is a project, not passive. The flat needs to be safe, grab bars, better lighting, a layout that works for a body that no longer moves the way it did. The senior needs services coordinated, the meals, the transport, the appointments, the bills. And the family needs a plan, because they are trying to keep a parent at home with no hours to do it themselves. The ageing-in-place consultant is the person who does the thinking, the assessment, the coordination, and the arrangement that the family cannot. It is a trust business in the purest form, you are advising a family on the safety of their parent, and it is almost completely unowned. Families are improvising, piecemeal, buying a grab bar here and a meal service there, with nobody tying it together.

The person who ties it together, and who is trusted to, owns the whole relationship.

**The home-convenience provider.** The shrinking household is a machine that produces convenience purchases, and the senior household is the most extreme version. A person living alone needs the things a family used to do collectively, done one at a time, and done by someone else. The repair, the errand, the transport, the installation, the small job that a family would handle internally but a single person must buy. This is not glamorous, and that is the point, the unglamorous convenience work is exactly what nobody wants to do and what everyone needs. The provider who shows up on time, does the job, and is honest about the price will be re-hired and referred, because in a market of one-person households, reliability is the whole product.

**The meal and nutrition service.** You remember that two-thirds of food spend in Singapore is on someone else cooking it. The senior household is the extreme of this, but it has a specific twist: the senior does not just need food, she needs food that fits her body. A ninety-year-old with a swallowing problem, a diabetic with a restricted diet, a person who has lost her appetite and her ability to cook, she needs meals that are the right texture, the right nutrition, the right portion, delivered to her door. This is a specialised nutrition service, not a restaurant and not a hawker, and it sits at the intersection of the two biggest movers in the whole country, the ageing and the outsourced cooking. The families buy it because the daughter cannot cook for her mother three times a week and the mother cannot cook for herself. It is a recurring, monthly, subscription-shaped purchase, which makes it exactly the kind of business a small operator can build a base on.

**The safety and monitoring service.** The 88,000 seniors living alone are a walking argument for this business, because the single deepest fear of a family with a parent living alone is that the parent will fall and nobody will know, more than that the parent is lonely. A fall is the event that ends independence. The family wants to know that if it happens, someone will find out. The monitoring service is the answer: the daily call, the check-in, the sensor that notices a door that has not opened by nine in the morning, the button that calls for help, the person who actually goes and looks. This is a care business that is also, in part, a technology business, and it is the one opening here where a little equipment can multiply what one person can serve. But the equipment is not the product. The product is the peace of mind it buys the daughter, the certainty that her mother is not lying on the floor with nobody to help. Sell the peace of mind, and the sensor is just the delivery.

Notice what all five of these have in common, because it is the whole argument of this chapter. None of them is "a care business." Each one is a specific word, the dementia specialist, the ageing-in-place consultant, the home-convenience provider, the meal service, the safety monitor. Each one is owned by a person or a small team, in a neighbourhood, on trust, on referral. And each one is a hole in the market that the structure of the country has opened and almost nobody has filled well. The river is not an ocean, but it is flowing through every neighbourhood, and the boats are few.

---

### The caveats

Now the part that separates a real strategy from a hopeful one. Because the care economy has four caveats, and if you ignore them, they will quietly ruin you.

**The first caveat: the paid layer is much smaller than the headline.** We have been over this, but it is worth restating, because it is the single most expensive mistake in this market. The "senior spending power" headline is seventy-two billion dollars of noise. The market you can actually own is a few hundred million. This is a reason to run toward specificity, not a reason to run from care. A business that goes into "care" because old people spend money will discover that old people spend money on groceries and rent, which they were never going to buy from you anyway. A business that goes into one specific hole in the care layer, the dementia specialist, the safety monitor, has found a market that is real, defensible, and exactly the right size for one excellent operator. Small is not the problem. Vague is the problem.

**The second caveat: you must own a specific word, not "care."** This is the deepest lesson of the whole chapter, and it is the one that connects back to the very first part of this book. "Care" is a category, not a position, and a category is competed to zero. There are three hundred and seventy-one thousand businesses in Singapore, and the moment a vague category shows a profit, everyone can see it on their phone and copy it within a month. The position that survives is the specific, referrable one, the word a fellow owner can put her own name on when she tells a friend "call this person, she is the one who does dementia care properly." A business that owns a specific word is competing on the thing nobody can undercut, not on price: a named, trusted, specific reputation. The dementia specialist, the ageing-in-place consultant, these are words a person can be referred for. "The care company" is a phrase nobody can be referred for, because nobody knows what it means.

**The third caveat: the customer is the family, and the family is anxious.** This cuts both ways. It is an opening, because an anxious family is a motivated buyer who will pay for peace of mind and stay loyal. But it is also a burden, because an anxious family is a demanding customer. You are handling the safety and dignity of someone's parent. The trust is hard-won and easily lost, and one failure, one missed check, one meal that arrives wrong, one carer who is unkind, is the end of the relationship and the referral, not a complaint. The upside of the care market is its loyalty; the price of that loyalty is that you can never, ever slip. If you are not prepared to be the person who is trusted with a parent, do not enter this market. The trust is the product, and it is the whole product.

**The fourth caveat: the paid layer is small, but the unpaid layer is where the growth is.** Here is the tension of the care economy, and it is the most strategic thought in this chapter. The paid layer, a few hundred million dollars, is built on top of a much larger mass of unpaid family care. About three-quarters of care is free, done by family. And that free layer is the part that is breaking. The daughter cannot keep doing it; she is out of hours. As the family layer fails, and it is failing, quietly, in households all over the country, the care moves from unpaid to paid. That is the wave, and it is still mostly ahead of us. The paid layer you can own today is small because most care is still free. The reason this is the single most structurally-backed opportunity in the whole country is that the free layer is not going to hold, and every dollar of care that stops being free is a dollar that moves into a market a business can own.

So the verdict is this. The care economy is real, and it is the strongest structural current in Singapore, and it is also not what the headlines say it is. It is a few hundred million dollars, not billions. It is bought by anxious working adults, not by the elderly. It is won by specific, trusted, referral-worthy words, not by vague categories. And it is growing, steadily, certainly, year after year, because the thing it replaces, the unpaid family care, is the thing that is breaking.

There is a forty-five-year-old woman who leaves her office in Raffles Place at six o'clock, and drives across town with a container of food for her mother. She is the customer, not a sad story. Every year, there are more of her, and every year she has less time, and every year her mother needs more help. The question is not whether the care economy will grow; it is already growing. The question is whether you will be one of the few who has built a boat on that particular river, owning one specific word that she trusts, before the water rises.

---

## Sources & confidence

All figures confidence-labeled. **High** = primary source (SingStat, MSF, Population.gov.sg, MOM, MOH, ICA) or multiple independent sources; **Moderate** = secondary or single-source. Key sources: Singapore Department of Statistics (fertility, births, marriages, households, seniors living alone, resident seniors 65+ count, median resident household income S$12,446/mo, the 13.4% of households earning ≥S$30,000/mo, the 51.6% earning ≥S$12,000/mo, resident population by age band); General Household Survey 2025 (income-share trends, singlehood); SingStat Household Expenditure Survey 2023 (spending pie; five-year moves in health, F&B, tuition, online, streaming); SingStat Monthly Retail Sales & F&B Services Index (2026) current-period check; Netflix Singapore pricing (primary); YouGov (streaming, dining-out), secondary; Momentum Works / CNA (food delivery ~US$3bn), secondary; WhiteBox / Statista / e-Conomy SEA (e-commerce US$8–11bn, cross-border share), secondary; private GP/specialist/TCM price points (secondary); private tuition (SingStat HES via TISG); IMDA smartphone ownership among seniors; Annals / MOH Age Well SG (Active Ageing Centres); pet market (secondary). Savings: CPF balances ~S$677bn (CPF Board, 2025), High; gross savings rate ~47% of GDP (CEIC/World Bank), High; CPFIS/SRS/T-bills/SSBs/REITs investment structure (CPFB), High.

Debt: household liabilities 107.9% of disposable income, mortgage ~70% of liabilities, personal loans S$118.6bn (9 straight quarters), home loans in 20s avg S$523,199, credit-card balances >S$9bn (SingStat household balance sheet via ST, MAS), High;

COE prices S$107,889 (2025) to S$129,000 (2026) (Bloomberg/The Diplomat), High; car loan terms 2.48–2.98% flat / ~5% EIR, up to 70% financing over 7 years (DBS/OCBC/UOB), High; HDB loan rate 2.6% fixed pegged to CPF (CPFB), High; personal-loan rates 1.3–1.8% (HSBC/SC), High; licensed-moneylender last-resort channel (secondary). The care-services market estimate (S$0.28–0.85bn/yr) is a secondary estimate, flagged Moderate.






# PART THREE, THE INDUSTRY MAP

## Every industry in Singapore, its size, its trend, and where the data is good enough to act on

![The industry map.](print/figures/fig-industry-map.pdf)

---

Picture a street in Singapore, and the mix of businesses on it. At one end, a gleaming glass tower that houses a global bank. In the middle, a shophouse where a lawyer and an architect share a floor. Along the pavement, a hawker centre, a few boutiques, a clinic, a tuition centre, a man who fixes watches. They all look like they are part of the same economy. They are not.

The bank tower, the shophouse professionals, and the hawker centre are in *different industries*, and the industries, not the businesses, are what this chapter maps. Because the single most important thing a small business owner can know about the terrain they are standing on is which industry they are in, what that industry is worth, how fast it is moving, and whether the public data is good enough to make a decision on, more than how hard they work.

This is the map of that terrain. It shows every industry in Singapore, what it is worth, its share of the economy, its trend, and whether the data on it is trustworthy enough to act on. It then asks the question the headline numbers never answer: *which industries are structured so that a well-run small business can actually win, and which are structured to grind you down no matter how well you execute?*

It does not recommend specific businesses. It maps the terrain, industry by industry, so that a business owner can see where they stand.

---

## Chapter 1, Here's the map

### How Singapore officially classifies its industries

Before any analysis of industries, you need the map of industries itself.

Singapore classifies every economic activity using the **Singapore Standard Industrial Classification (SSIC 2020)**, the national standard, aligned to the international ISIC framework, maintained by Singapore's statistics authority and enforced by the company registrar at incorporation. Every single business in Singapore, at the moment it is born, must declare its principal activity under an SSIC code.

The structure is hierarchical, five levels deep:

- A **section** (a letter from A to U, twenty-one in total), say, C, Manufacturing.
- A **division** (two digits), say, 26, Computer, electronic & optical products.
- A **group** (three digits), say, 261, Electronic components & boards.
- A **class** (four digits), say, 2611, Electronic components.
- A **sub-class** (five digits), say, 26112, Wafer fabrication.

The twenty-one sections run the whole gamut of human economic activity: Agriculture & fishing (A), Mining & quarrying (B), Manufacturing (C), electricity, gas, and air-conditioning (D), water and waste (E), construction (F), wholesale & retail trade (G), transport (H), accommodation & food (I), information & communications (J), finance (K), real estate (L), professional services (M), admin & support (N), public administration (O), education (P), health (Q), arts & recreation (R), other services (S), households employing domestic workers (T), and extra-territorial organisations (U).

Two of these sections are astonishingly detailed: Manufacturing (C) breaks down into 355 five-digit sub-classes, and Wholesale & retail trade (G) into 168. That granularity is itself a signal, these are the two most closely tracked parts of the Singapore economy.

But why should a small business owner care about the bureaucratic code they declare at registration? Because the SSIC code is not a formality. It decides which statistical series your industry appears in, which grants you are eligible for, and how the government counts your sector. A business that picks a broad, or wrong, SSIC code disappears into an aggregate and becomes invisible, to the data, and to the policy that follows the data. **Choosing the right code is the first act of positioning. It decides which map you appear on.**

### The scale, the size of the whole, and how it splits

The macro frame first, all of it from 2025, out of Singapore's statistics office. Two words appear on every page, so here is what they mean in plain dollars. **GDP**, gross domestic product, is the total value of everything produced in Singapore in a year, the whole economy measured in dollars. **Value added** is one industry's own slice of that, after the materials and services it bought from other industries are subtracted; it is the fairest measure of how big an industry truly is on its own.

- GDP at current market prices: **S$789.5 billion**, up 3.1 percent.
- GDP in chained (real) dollars: **S$593.9 billion**, up 5.0 percent, the real growth of the economy.
- Per capita GDP: **S$129,194**.
- Enterprise value added: **S$714.7 billion**.
- Total enterprises: **371,000**.
- Total employment: **4.12 million** (including foreign workers).

**The services-producing industries generate over 70 percent of nominal GDP**; the goods-producing industries, manufacturing, construction, utilities, generate the rest. This is the three-engine structure from the landscape chapter, now visible at the level of industries. There is the **global engine**, the industries that build and trade with the world, like manufacturing, finance, and wholesale trade. There is the **government engine**, public administration, education, health, the industries the state runs. And there is the **domestic layer**, the industries that serve people where they live, like retail, food & beverage, accommodation, and personal services. They are not just separate places. They are separate industries, with entirely different economics. Think of it as the machine room versus the shop front versus the state's own workshops: the engines make money for the whole country; the domestic layer takes that money from the people who hold it.

### The industry-by-industry map

Here is the core table, the full sweep of every industry in Singapore, its value added in 2025, and its share of GDP. Each figure is verified directly from the statistics office's detailed national-accounts table.

A map that shows you everything is no help unless you know how to read it, so here are three habits to hold on to as you work through the table.

**First, separate value from entry.** The industries with the biggest numbers, wholesale trade, manufacturing, finance, are the engine's territory. Capital-intensive, meaning they need billions of dollars of machinery and scale before they turn a profit, dominated by multinationals and state-linked giants, and structurally closed to a typical small business. Do not read "biggest share of GDP" as "best opportunity." Read it as "most concentrated, hardest to enter."

**Second, read the domestic tail, not the head.** The industries a small business can actually enter, retail, food & accommodation, personal services, admin & support, health, education, arts, are each a small slice of GDP, but collectively they employ a huge share of the workforce. That is where the density is, where the competition is fierce, and where differentiation, not price, is the only durable way to survive.

**Third, weigh the data against the opportunity.** The industries with the best data, manufacturing, finance, wholesale, are the ones you cannot enter. The industries you can enter have good aggregate data but coarse competitive data. That inversion is the reason to keep this map: it tells you where the value is, where you can realistically play, and where you will have to do your own research, because the public data will not hand you the answer.

Here is the map.

| Industry (SSIC section) | Value added 2025 | Share of GDP | 2025 real growth | Data quality |
|---|---|---|---|---|
| Wholesale trade (G) | S$146.5bn | 18.6% | +5.0% | High |
| Manufacturing (C) | S$137.6bn | 17.4% | +8.7% | High |
| Finance & insurance (K) | S$104.2bn | 13.2% | +4.2% | High |
| Transportation & storage (H) | S$60.1bn | 7.6% | +5.0% | High |
| Information & communications (J) | S$47.1bn | 6.0% | +4.2% | High |
| Professional services (M) | S$41.8bn | 5.3% | +4.2% | High |
| Construction (F) | S$30.0bn | 3.8% | +5.2% | High |
| Real estate (L) | S$22.2bn | 2.8% | +3.1% | High |
| Health & social services (Q) | S$20.7bn | 2.6% | +3.1% | Moderate |
| Admin & support services (N) | S$18.4bn | 2.3% | +3.1% | Moderate |
| Education (P) | S$18.4bn | 2.3% | +3.1% | Moderate |
| Public admin & defence (O) | S$17.6bn | 2.2% | n/a | High |
| Utilities (D) | S$11.4bn | 1.4% | n/a | High |
| Retail trade (G) | S$9.0bn | 1.1% | +5.0% | High |
| Other services (S) | S$8.6bn | 1.1% | +3.1% | Moderate |
| Food & beverage services (I) | S$7.6bn | 1.0% | +3.1% | High |
| Arts, entertainment & recreation (R) | S$7.6bn | 1.0% | +3.1% | Moderate |
| Accommodation (I) | S$5.6bn | 0.7% | +3.1% | High |
| Agriculture, fishing, mining (A, B) | S$0.2bn | 0.02% | n/a | Moderate |

\begin{quote}\footnotesize
Ownership of dwellings (S\$29.7bn, a national-accounts adjustment for owner-occupied housing) is not an industry, it is excluded here. Figures are gross value added at basic prices; the shares of GDP sum to about 97\%, the balance being taxes less subsidies on products.
\end{quote}

\begin{quote}\footnotesize
\textbf{On retail trade (S\$9.0bn, 1.1\% of GDP):} this figure should be read with care, because it is sensitive to how wholesale and retail are split within SSIC section G. Wholesale trade (S\$146.5bn) and retail trade (S\$9.0bn) are both booked under section G, and the split between them depends on how each establishment classifies its principal activity. A large share of what a consumer thinks of as "retail", the big-format stores, the online sellers, the distribution that sits behind a shopfront, may be booked under wholesale or under another section. The S\$9.0bn is the official retail-trade line, but it is a narrow measure of the retail activity a small shop actually competes in.
\end{quote}

\begin{quote}\footnotesize
\textbf{On health \& social services (S\$20.7bn) and education (S\$18.4bn):} these two lines sit partly inside and partly outside the government engine. The government engine's value added includes the public hospitals, the public schools, and the public administration that runs them, funded by the state, not by a market. But the same SSIC lines also include the private clinics, the private hospitals, the private tuition centres, and the private schools that compete in the market. The book leans on the government-engine distinction elsewhere, so it matters that these two lines are a blend: part state-funded, part market-funded. The private-tuition market alone is roughly S\$1.8bn a year, a small slice of the S\$18.4bn education line, which is dominated by the public school system.
\end{quote}

Now read it. The three giants, wholesale trade (18.6%), manufacturing (17.4%), and finance (13.2%), together account for **almost half of Singapore's GDP.** These are the engine-layer industries. Capital-intensive. Export-oriented. Dominated by multinationals. They are where the *value* is, but they are not where most small businesses live.

And the domestic-layer industries, retail, food, accommodation, the fragmented personal and admin services, are each tiny as a share of GDP. But together, they employ a huge share of the workforce. This is the density, the cap, the competition, of the landscape chapter, now quantified: **the industries where most Singapore small businesses compete are individually tiny slices of the economy, in a market that is capped.**

Here is the practical reading of the table: do not chase the big numbers. Wholesale, manufacturing, finance are the engine's territory, capital, scale, and corporate dominance make them hostile to a typical domestic SME (small and medium enterprise, the shops, clinics and centres with a handful of staff). The domestic-layer industries are small in GDP terms, but they are where the *people* are, where the *premium demand* of the engine's payroll flows, and where differentiation actually decides who survives.

---

## Chapter 2, Which way is it moving?

A map of what is standing still is not enough. A business owner needs to know which way the terrain is tilting, where the demand is landing, and which industries are growing, stale, or declining. That is what this movement answers, in two connected reads: where the demographic waves land as industries, and which industries the growth numbers actually favour.

### Where the demand lands, the bridge from the demographic chapter

The demographic chapter ended with a map of people: who is here, what they earn, what they spend, where their attention goes, and the four waves reshaping all of it. This chapter is the map of industries. A bridge between the two is the answer to the question, not a decoration every small business owner is actually asking: *I have read about the ageing, the shrinking household, the collapse in births. Now show me where that money lands.*

So here is the concrete answer, and it is more interesting than any headline number.

**Take the oldest person on the island.** The demographic chapter established that about 6.6 percent of Singaporeans over 65, roughly 52,000 people today, have a disability serious enough to need care, and that nearly all of them age in place, at home. Now follow that person to an industry. The care they need is a home-care aide who comes at twenty dollars an hour, a day-care centre that charges nine hundred to fourteen hundred a month, a meal delivery that puts food on the table, a monitoring service that tells a daughter her mother is safe, not an abstraction called "ageing." Each of those is an industry with a national-accounts line, a dollar figure for its size, an establishment count, a tally of how many operators are actually in it, and a growth rate. The demographic wave did not stay in the demographic chapter. It is sitting, right now, in the value-added of health and social services, which the Ministry of Trade and Industry (MTI, the government ministry that publishes Singapore's growth figures) describes as "resilient" even as other domestic industries slow.

**Now take the childless couple.** The demographic chapter showed that a young adult who does not have a child does not stop spending, they redirect the money that would have gone to a child into something else: the dog, the table, the travel, the experiences. Find that in the industry map and you find the food-and-beverage services line, the recreation line, the personal services line. The money did not disappear when the birth rate fell. It moved sideways, into industries, into lines of GDP that a business owner can name.

**And take the shrinking household.** A person who lives alone cannot share a dinner, a rent, a washing machine, a conversation. So they buy single servings, delivery, a laundromat, a pet, a streaming subscription. Every one of those is an industry, and the household wave is the growth line in food delivery, in convenience retail, in the personal services that keep a household of one running, not a sociological note.

That is the bridge. Here is the real shape of it:

| The demographic wave | Where it becomes an industry | The mechanism |
|---|---|---|
| **Ageing** (65+ one in five, rising) | Health & social services, home care, day care, wellness education, food services near home | The care-needy buy services; the healthy majority buy independence. Both land in health and social services, "resilient" in MTI's numbers. |
| **Care being monetised** (95% feel it, 1 in 4 sandwiched) | Home care, day care, eldercare centres, safety/monitoring | The state is writing the checks (HCG up to S$600/mo); the family is time-poor and buys the labour. |
| **Shrinking household** (1.49M, smaller, more single) | Food & beverage, convenience retail, delivery, laundry, personal services | One person cannot share; they buy everything individually, service-bought. |
| **Fertility collapse → concentration** (0.87, fewer children) | Private tuition, childcare, enrichment | Fewer children, but the ones that exist are the most expensively raised in the country. |
| **Replenishment** (two-speed inflow) | Wholesale, finance, info-comm | The engine's payroll feeds the premium domestic demand; the low-wage inflow feeds the labour. |

Now here is the part that no single table shows, and the part that should stop a small business owner in their tracks. **The demographic wave with the strongest tailwind, ageing, care, health, lands in the industries where the structure is also most favourable.** Health and social services is the domestic-layer industry where regulation raises the barrier to entry, where trust stops pure price competition, and where the demographic tailwind is strongest. The people-map and the industry-map point to the same place, and that is the reason the series goes from "which wave" to "which industry" to "which slot."

The other way to read the bridge is the warning. The demographic demand does not land evenly. It lands hard in the industries that are *hard to enter*, health, care, premium professional, where regulation and trust gate the door, and it lands softly in the industries that are *easy to enter and brutal to survive*, retail, food, personal services, where the same demand produces a hundred competing shops. The bridge tells a small business not just *where the money is* but *where the money is and the door is open for a positioned player*. Those two do not always coincide, and knowing the difference is the point.

That is the value of the bridge, in one line: **the people are becoming industries, and the industries that the people are becoming are the ones a positioned small business can enter, if they read which wave is their wave before they pick their door.**

### Growth, staleness, and decline, which industries are moving

Now the map that a business owner actually reads: not just which industry is big, but which is growing, which is stagnant, and which is shrinking. The MTI quarterly releases give the verified growth rates (2025 and 1Q2026, year-on-year):

| Industry | 2025 real growth | 1Q26 (YoY) | Trend |
| --- | --- | --- | --- |
| Manufacturing | +8.7% | (strong) | **Growth**, the engine's core, capital-intensive |
| Wholesale & retail trade, transport | +6.7% (collective) | +6.7% | **Growth**, the trading spine |
| Retail trade (broad) | +5.0% | retail +4.0% | **Growth**, the aggregate is growing |
| Information & communications | +4.2% (with finance & professional) | +3.9% | **Growth**, the digitising economy |
| Finance & insurance | +4.2% | (in group) | **Growth**, engine-layer |
| Professional services | +4.2% | (in group) | **Growth**, premium differentiation |
| Health & social services | resilient | resilient | **Growth**, the ageing tailwind |
| Education | resilient | resilient | **Growth**, premium pockets |
| Accommodation, real estate, admin, other services | +3.1% | +2.3% | **Stale**, domestic layer, moderate |
| Food & beverage services | +3.1% (2025) | **−2.3%** (Jun 26) | **Declining in the near term**, softening |
| Department stores | n/a | **−5.7%** | **Declining**, the format losing to online |

Read the retail rows together and the trend is sharp. The retail *aggregate* is still growing, +5.0 percent in 2025, +4.0 percent in mid-2026, so the overall industry is not in decline. But the growth is not evenly spread. Computer and telecommunications sales are up nearly ten percent, the online share of retail is climbing toward a fifth, and the legacy formats are contracting, department stores down 5.7 percent, and F&B services, which boomed, are now softening (down 2.3 percent in June 2026). The retail industry is bifurcating between the formats the country is moving toward and the formats it is leaving behind.

The pattern that matters for a small business: **the growth is at the two ends the map already flagged, the digitising engine (information, communications, online retail, computer/telecoms) and the ageing-adjacent services (health, care, premium professional).** The staleness sits in the middle, the fragmented, price-war domestic services that grow slowly and cut hardest. The decline is concentrated in the legacy retail formats (department stores) and, for now, the F&B services that softened.

A business owner should read this as the demand-traffic map: **growth industries are where the money is heading; stale industries are where it is already crowded and fighting over a slow-growing pie; declining industries are where the format itself is losing to a substitute (online, delivery, a newer way to serve the same need).** Being in a growing industry does not guarantee you win, but it means the current is at your back. Being in a stale or declining one means the current is against you, and only a position that pulls you out of the commodity can save you.

---

## Chapter 3, Where can a small business actually win?



![Friendly or brutal: which industries a small business can win in.](print/figures/fig-friendly-brutal.pdf)



The map told you what each industry is worth and which way it is moving. Now the question that matters most: *inside these industries, where can a single owner-operator or small team actually win?* This movement merges three things that the map used to treat separately, the specific slots, the industry detail, and the structural test of whether a well-run business can earn there. Read together, they answer one question: **which industries are growing AND enterable AND structured so a positioned player can take share.**

### The structural test, where a well-run business can actually earn

Before the specific slots, ask the question the numbers alone cannot answer: *is this industry set up so that a well-run business can actually earn a living, or is it set up to grind you down no matter how well you run it?*

There is a way to test this that has nothing to do with business school. Think about a market you know well, say, the coffee shops in your neighbourhood, and ask five plain questions about it:

- **How easy is it for someone else to start up and do the same thing?** If anyone can register a business in a day and open up next to you, you can never relax. If it takes a licence, a lot of money, or a skill few people have, the crowd stays out.
- **How much can the people you buy from squeeze you?** If you depend on one supplier who can raise prices whenever they like, you have no room. If you have many suppliers, you are in charge.

- **How much power do your customers have over you?** If they can go anywhere and compare every price on their phone, they hold the power. If they need you specifically, you do.
- **Could your customer get the same thing somewhere else, without you?** If your service can be replaced by a cheaper or easier alternative, you are always one step from losing the sale.
- **How hard do the shops around you fight?** If every shop competes by cutting price, the whole street gets dragged down. If the shops are not fighting, each one content, doing the same thing for years, there is room for one that does it better.

Here is the twist that matters, and it is the whole point of this test. **An industry where all five are hard, easy to enter, squeezed by suppliers and customers, easily replaced, fighting on price, is a brutal place to be *if* you are just like everyone else. But it is exactly the place where a business with a clear difference can win.** The difficulty is the same difficulty every shop on the street faces. The one that stands out is the one that stops fighting on price and gives people a reason to come to it instead of the shop next door.

So do not read the industries below as a list of places to avoid. Read them as a list of places where the shops are all fighting on price, and where one operator with a clear difference takes the share of everyone around them. The difficulty is the sign that the incumbents are exposed, not a warning for you.

Here is the whole test across the domestic-layer industries at a glance, using the five plain questions. Read the last column first, it is the one that tells you where to look:

\begin{table}[!htbp]\centering
\caption{The structural test, industry by industry}\label{tab:five-forces}
{\small
\begin{tabular}{@{}p{8.5em}ccccc@{}}
\toprule
Industry & Easy to start & Suppliers squeeze & Customers hold power & Can get elsewhere & Fighting on price\\
\midrule
Retail & \rhigh & \rmed & \rhigh & \rhigh & \rhigh\\
Food \& beverage & \rhigh & \rhigh & \rhigh & \rhigh & \rhigh\\
Professional services & \rmed & \rlow & \rmed & \rmed & \rmed\\
Health \& social services & \rlow & \rlow & \rmed & \rlow & \rlow\\
Education / tuition & \rhigh & \rlow & \rmed & \rhigh & \rhigh\\
Admin \& support & \rhigh & \rlow & \rhigh & \rhigh & \rhigh\\
Personal services & \rhigh & \rlow & \rmed & \rmed & \rhigh\\
\bottomrule
\end{tabular}}
\ratingkey
\end{table}

The opening for you, industry by industry: retail is brutal on price but open to a clear difference; food and beverage is brutal, but the standout wins; professional services has a specific, deep niche open; health and social services is friendliest for the prepared operator; education and tuition has a deep-niche enrichment opening, not plain "tuition"; admin and support is boring but real, and takes a premium tier; personal services is open to a specialist who owns a name.

Two things to notice in that table. **The industries where "Easy to start up," "customers hold the power," "can get it elsewhere," and "shops fighting on price" all say yes, retail, food, admin, personal services, are the brutal ones, and they are exactly the ones open to a business with a clear difference.** The difficulty that grinds everyone down is the same difficulty that leaves every shop exposed. **And the industries with "Hard to start up" or "Low" on customer power, health, professional services, are the friendlier ones, but they are harder to enter and the data is thinner.** That is the whole structural picture in one table.

### The industries, one by one

Here is where the map stops being a list of numbers and becomes a set of arenas. Each industry below is read the same way: what it is, how the structure cuts for a small player, and, for the domestic-layer ones a small business can actually enter, what the concrete opening is.

**The engine's core, manufacturing, wholesale, finance, is where the value is, not where small businesses live.** Manufacturing is the single most important goods-producing industry and the one with the best public data in the entire economy. Its value added in 2025 was **S$132.8 billion**, up 13.9 percent; its total output was **S$479.1 billion**, up 11.5 percent; it pays **S$26.4 billion** in remuneration; it is a fifth of the economy. The 2025 growth was led by electronics, transport engineering, and precision engineering, which more than offset declines in biomedical, general manufacturing, and chemicals. The data is the gold standard, value added, output, productivity all published by cluster, monthly and annually. But the strategic caveat is equally clear: manufacturing is dominated by multinationals and state-linked firms, is capital-intensive, and its value is concentrated in a small number of large firms. A domestic SME does not compete *in* manufacturing; it competes *around* it, as a supplier, a service provider, a niche player in a cluster the giants ignore. The data is excellent. The barriers to entry are brutal.

The same holds for wholesale trade (18.6% of GDP, the engine's trading arm, corporate territory, capital-intensive) and finance (13.2%, heavily regulated, dominated by the banks). These are where the value is; they are not where most small businesses compete.

**Information & communications is the growth engine of the domestic layer, and for a small business, the most strategically important industry in the country.** It is the fastest-growing domestic-layer industry, driven by "continued strong demand for IT and digital solutions." And it is where the differentiation opportunity lives: there is a roughly 48-point gap, a difference of almost fifty percentage points, between how fast small businesses adopt technology and how fast large businesses do, and it is being closed. The businesses that differentiate *now* own positions the late adopters cannot take. For a small operator, this is the arena where a single person with a position and a tool can out-execute a shop that has done the same thing for twenty years.

**Professional services is the most interesting domestic-layer industry.** Legal, accounting, management consultancy, architecture, engineering, research, advertising. The demand for *specific, deep* differentiation is outrunning supply by eight to one, management consulting registrations grew only 1.0 percent while business formations grew 8.5 percent. Competition is intense, and the state's free advisory centres anchor generic advice at zero. But the white space is in the deep, specific, niche position that the state does not provide, not in generic professional services. This is where a positioned small firm can genuinely earn, and where the incumbent advisors are the most vulnerable to a sharper, more specific competitor.

**Health & social services is the friendliest domestic-layer industry for a small business that is willing to do its own homework.** Regulation keeps new players out. Trust stops the fight over price. And the demographic tailwind, ageing, care, the silver economy, is the strongest in the economy. The catch is that the data is coarser, so the businesses that do their own research gain the edge.

**Education is structurally mixed, with clear disruption pockets.** A crowded field and a shrinking base, the fertility collapse. But the concentration of per-child spend creates premium pockets where a specialist takes the concentrated dollar from the generic 1,000+ centres.

**Retail trade is hostile to businesses that compete only on price, which is why it is open to a business with a clear difference.** Anyone can register a business in a day, so the field is wide open. Buyers can compare every price on their phone, so they hold the power. The same need can be met online or delivered, so customers always have another option. And the shops fight on price. The corporate reading is "escape." The small-business reading is the opposite: this is an industry of undifferentiated shops fighting on price, where one operator with a difference, a niche, a reason to be chosen beyond price, takes share from everyone around them. The field is open for you too. Use it.

**Food & beverage is brutal, and brutally ripe for a business that stands out.** High fixed costs (rent, labour), a capped market, intense competition, and a five-year survival rate under a quarter for the ones with no particular edge, meaning fewer than one in four new restaurants with no difference is still open five years later. But most of that competition is menus competing on price at the same ten dollars. The opening is the F&B business that is not competing on the plate, the one that owns a moment, a neighbourhood, a type of eater that people will cross the island for. The incumbents are not different from one another; they are interchangeable. That is the gap.

**Admin & support services, employment agencies, security, cleaning, travel, is the "boring but real" SME economy.** Most of it is a price commodity, but a commodity with complacent incumbents. A positioned operator (specialised security, white-collar recruitment, high-end cleaning) escapes the price war and takes the premium tier. The boring is exactly where a sharp operator with a clear word disrupts the unchanged incumbents.

**Personal services, beauty, hair, repair, is the dense SME heartland.** Retail is S$9.0 billion, food & beverage S$7.6 billion, accommodation S$5.6 billion, each tiny, together about three percent of GDP, yet employing a disproportionate share of the domestic workforce. Personal services looks hostile, but it is a field of undifferentiated shops with no protection. One specialist, one premium salon, one trusted repair brand, takes the premium tier. Because it is the least precisely measured industry, proprietary research is itself an edge.

**Real estate is the industry that sets everyone's cost base.** Not a typical arena for a domestic SME, but structurally powerful for the landlord and constraining for the tenant. A small business cannot change the real estate structure; it can only choose which part of it to pay, downtown premium or heartland mass. That choice, made consciously, is a positioning decision.

**Transportation & storage**, the logistics spine. Land, water, air, warehousing. A domestic-layer industry with real SME participation, though capital-intensive at the top.

### The slots, where the obvious wins are

The structural test told you *which* industries are worth entering. The slots are the *specific openings* a small business can walk into, the word, the service, the niche no incumbent owns. When this chapter says **SMB** (small and medium business, the shops, clinics and centres with a handful of staff) or **OPC** (one-person company, a business run by a single owner-operator), both are exactly the reader this whole series is written for, the small operator who does not have a chain's capital or a corporate team. Read it as three columns. **Wave** is the demand (from the demographic chapter). **Industry** is where it shows up. **Slot** is the specific opening a small business can take. A few of these slots are so clearly exposed that they are the obvious wins, and here they are:

| The wave | The industry | The slot a small business can take |
|---|---|---|
| **Ageing** | Health & social services | Home care that is not an agency but a *specialist*, dementia, post-operative, end-of-life. Trust + regulation gate the big players; the specialist niche is open. |
| **Ageing** | Wellness education | **Ageing-in-place consulting**, the one-on-one service that tells a family what to buy, install, and plan for. Nobody owns it; the demand is exploding. |
| **Care monetised** | Home care, day care | A **boutique day centre** for a single profile, "dementia mornings," "stroke rehab afternoons." The generic centres are full and indifferent; the specialist is not. |
| **Shrinking household** | Personal services, delivery | **Laundry and home-services done for the single, time-poor professional**, subscription, reliable, one named person. The laundromat exists; the *service for a person with no time* does not. |
| **Fertility → concentration** | Education, tuition | **Deep-niche enrichment**, not "tuition" (brutal, 1,000+ centres) but one subject, one exam, one type of student, owned by one name. The concentrated per-child spend is real; the niche operator takes it. |
| **Digitising** | Info-comm, online services | The **small-business technology specialist**, "we fix the tools for the clinic, the salon, the tuition centre." The 48-point SME adoption gap is the open door. |
| **Replenishment** | Professional services | A **trusted advisor to the foreign professional**, the EP (Employment Pass) holder who needs a local specialist they can vouch for (a named, trusted person). Premium demand, thin supply. |

Each of these is a slot, not a business. A slot is where a position can live. And the pattern across all of them is the same: **the winning slots sit in industries the big players find too small or too messy, serving a demand the demographic waves are making bigger every year, with an incumbent who has not changed in a generation.**

Why these are the obvious wins for a small business, an SMB or a one-person company, specifically:

- **They are capital-light.** No manufacturing line, no banking licence, no office tower. The cost is a person, a position, a name, a way of doing one thing well.
- **They are trust-driven.** The buyer wants a named, vouchable operator, not a platform. That is the moat from the first chapter, and it favours the small player who can be a person, not the incumbent who is a brand.
- **The incumbents are complacent.** A fragmented industry of small shops that all do the same thing is exactly the arena where one sharp operator with a clear position eats the share of everyone around them. The barriers are low, but they are low for *you* too.

Do not read this as "the industry is brutal, stay away." Read it as the opposite: **the industries that look brutal from the outside, through a corporate lens, are the ones where a positioned small business can take share from shops that are all doing the same thing.** The very things that make those industries hard, easy for anyone to enter, customers who compare prices, shops that fight on price, are the opportunity, because it means every incumbent is as exposed as you are. The difference is you have a clear position and they do not. The slot is where your position makes the crowd irrelevant.

The slots above are the obvious ones. The demographic chapter and this map give you the method to find the rest: take a wave, find the industry it is growing, and look for the slot the incumbents are too slow or too generic to take.

### Survival and entry cost, the numbers the map does not usually show

The structural test tells you which industries are worth entering. It does not tell you how much it costs to enter, or how likely you are to survive once you are in. Those two numbers matter as much as the structure, and they are thinner in the public data. Here is what is known, and where the gaps are.

**The national survival figure is a single number, and it hides the industry split.** About 49 per cent of companies registered in 2020 were still active six years later. That is the whole-economy average. The split behind it is the more useful number: the high-barrier sectors, those needing more capital or serving business buyers, show survival rates of 70 per cent and above, while the low-barrier consumer trades, retail, food, gig-style services, see most entrants fail. The gap between the two is the gap between an industry that filters entrants by capital and one that filters them by survival of the fittest.

**Sector-level survival data is the gap, and the closest public proxy is sector-level cessation counts.** Singapore publishes annual business-cessation counts by industry, through SingStat's table builder (the "Cessation of All Business Entities by Industry" series). These show which sectors close the most businesses each year: in 2025, retail trade saw about 6,800 business cessations, wholesale trade about 10,000, professional services about 9,600, and food and beverage services about 3,100. That is useful, it confirms which arenas are dense with closures. What it is not is a clean five-year survival cohort by industry: a number that follows one year's entrants forward and reports what share survived. That figure does not exist in the published data. The 49 per cent national survival rate, the high-barrier/low-barrier split, and the sector-level cessation counts are the best the public data supports. The granular version, the five-year survival rate for a hawker stall versus a tuition centre versus a home-care provider, does not exist in the published data, and this book will not invent it.

**Entry cost is knowable as a range, and the range is wide.** The picture of what it costs to open a small business in Singapore, by industry, with wide ranges and confidence labels:

| Industry | Entry cost (range) | Confidence | Notes |
|---|---|---|---|
| Hawker / food stall | S$30k–S$120k | Moderate | Stall rental, equipment, licence, working capital; the range is wide because a coffee-shop stall and a mall kiosk differ by a factor of four |
| Retail shop | S$50k–S$250k | Moderate | Rent deposit, fit-out, stock; the premium end is the Orchard Road or mall format |
| Tuition centre | S$40k–S$150k | Moderate | Rental, fit-out, materials; a home-based tutor starts far lower |
| Home-care / eldercare provider | S$20k–S$100k | Low | Licence and compliance costs dominate; the range is uncertain because the regulatory cost varies by service |
| Professional services (solo) | S$5k–S$50k | Moderate | A laptop, a licence, professional indemnity insurance; the lowest entry cost of any arena |
| Salon / personal services | S$50k–S$150k | Moderate | Fit-out, equipment, rent; the range reflects the difference between a neighbourhood shop and a mall outlet |

These are wide ranges with confidence labels, not precise figures, because Singapore does not publish a standard entry-cost table by industry. They are more useful than silence: they tell you that the capital-light arenas, professional services, home care, tuition, are the ones where a person with a skill and a position can start, and that the capital-heavy arenas, retail, F&B, salon, are the ones where the rent and fit-out are the first filter.

**Owner earnings are the least-published number of all.** The map shows value per worker by industry, but that is not the same as what an owner takes home. A hawker's value per worker is low, but the owner's take is what is left after the stall's costs, and that is not published. The statement is that owner earnings by industry are not in the public data, and the value-per-worker figures in this book are the closest proxy, with the caveat that they measure the business's output per worker, not the owner's income.

The point of these numbers is to make the entry decision honest, not to scare an entrant. The industries with the lowest entry cost and the thinnest survival data, the fragmented consumer trades, are exactly the ones where a position matters most, because the crowd is the thing that kills you, and a position is the one thing that lifts you out of the crowd. The industries with the highest entry cost and the best survival, the capital-heavy, licence-gated ones, filter entrants by money, and a position matters less because the barrier does the filtering. The map's advice holds: if you are entering a low-barrier industry, you are betting on your position to survive the crowd. Enter it knowing that is the bet you are making.

---

## Chapter 4, What can you trust, and what does it mean?

### The data, which industries can you act on?

This section separates a useful map from a decorative one. Not all Singapore industry data is equal. Here is the assessment of which industries have public data good enough to act on, and which are data-poor.

**Excellent data, you can act on it.** Manufacturing (value added, output, productivity by cluster, monthly). Finance (extensive statistics). Wholesale (detailed trade figures). Information & communications (InfoComm statistics, adoption data). Professional services (services + registration data). Transportation. Real estate (property and rental indices).

**Directional data, not precise.** Health & social services (aggregate published, but segment-level is under-quantified). Admin & support (aggregate; sub-segments not separated). Education (aggregate; the private-tuition market not precisely measured). Arts & recreation (aggregate; thin). Other personal services, beauty, hair, repair, laundry, **the least precisely measured industry in the entire economy.** Utilities (aggregate, state-dominated). Agriculture (tiny).

Now read those two lists together, because they reveal the whole point.

**The industries with the best data, manufacturing, finance, wholesale, are the ones a small business cannot enter.** The industries where a small business actually competes, retail, food, accommodation, admin, personal services, health, education, have good aggregate data but coarse competitive data.

This is not a reason to stay away from the domestic-layer industries. Far from it: the industries with the strongest tailwinds, ageing, care, health, are precisely the ones where the public data is thinnest. So the businesses that do their own primary research gain an information advantage the data-poor competitors do not have. **In a data-poor industry, proprietary research is itself a differentiation.**

### The gaps, closed with the data that is available

The national-accounts map stops where the aggregation stops. But the gaps it leaves are not empty. Below are the under-measured industries, sized from the online data that does exist, market research, industry registries, platform counts, and parliamentary answers. None of these is a national-accounts figure. Each is directional, assembled from available sources, and flagged as such. But for a business deciding where to play, a directional number from the real world beats a precise blank.

**Personal services, beauty, hair, repair, laundry, is not actually un-measurable.** The most often-repeated gap in this map has a number hiding in plain sight. The Singapore industry landscape (SkillsFuture / SSG) counts **about 5,540 establishments** in the Personal Care, Beauty & Hair Dressing Services sector, with operating receipts of around **S$1.37 billion a year.** That is the single most useful figure in the whole domestic layer, it tells a business the real size of the arena it is competing in. It is not in the national accounts as a clean line, but it is available, and it is honest about its source: a government skills agency's industry profile, not a precise census. Caveat: it aggregates beauty, hair, and dressing, so a nail-only or hair-only entrant must estimate their slice. But the total is real, and it is over a billion dollars.

**The tuition industry is better measured than the national accounts suggest.** The official numbers understate it because MOE does not track the private industry's total value, but the industry itself is visible from several angles. Households spend about **S$1.8 billion a year on private tuition** (HES 2023). Around **1,000+ tuition and enrichment centres** are registered with MOE, a number that has grown steadily and is now higher than the count of all primary and secondary schools combined. Seven in ten parents send a child for tuition, and eight in ten primary-school children pay for it. The industry has more registered centres than the national education system has schools, which is itself a sentence every tuition operator should read twice. Caveat: the centre count misses the tens of thousands of freelance tutors who are not registered, so the true supply is larger; the household-spend figure misses corporate and online providers. But the scale is no longer "unknown", it is a billion-dollar-plus, thousand-plus-centre, majority-of-families industry.

**Eldercare / home-care providers are countable from the service registries.** The state is building this market deliberately, and it publishes the counts. The plan is to roughly double the number of eldercare centres to **220 by 2025** (MOH), and to double nursing-home beds. Active Ageing Centres have grown from 119 to 223. The licensed home-care and day-care providers are listed in the AIC's care-services directories. The count is not a single published "market size," but it is a countable supply side: the number of centres and beds is available, and it is rising on state funding. That is the caveat-and-use figure for a home-care operator: the supply is growing, and the state is the reason.

**The retail competitive field is readable from the platform/aggregator data.** The national accounts give retail as an aggregate; the fine-grained competition is visible elsewhere. Establishment counts (6,355 restaurants, 837 fast-food outlets, 5,540 beauty businesses) give density. The e-commerce and delivery platforms give share, Shopee and Lazada dominate, cross-border takes over half of online spend, online is ~a fifth of retail. A retail entrant can reconstruct its competitive field from these fragments even though no single table publishes it.

**Ownership of dwellings, the S$29.7 billion imputation for owner-occupied housing, is not an industry.** It is a statistical adjustment, and the map deliberately excludes it.

**The silver-economy market size, the one genuinely open number, is now closed by construction.** The US$72.4 billion headline is senior total spending power, not a market. The demographic chapter built the addressable paid care-services layer, home care, day care, residential care, meals/nutrition, safety/monitoring, at roughly **S$0.28bn–0.85bn a year**, anchored by a verified care-need base of **6.6% of 65+ with moderate-to-severe disability** (NUS/MOH RHS) and Duke-NUS's finding that ~75% of senior care is informal/unpaid family care. It excludes the migrant-domestic-worker channel and the wellness/active-ageing spend of the healthy majority, which would add a multiple. Any business that extends it, or builds the adjacent wellness layer, holds an information advantage no headline provides.

The gaps are now filled with estimates. None of these numbers is a national-accounts figure; each is assembled from available public data, a skills-agency industry profile, an MOE registration fact, a parliamentary household-spend figure, a service-registry count. They are directional and caveated. But they are no longer blank. And in a map where the official data stops early, a directional number built from the available sources is worth more than a precise empty space.

### What this map means for a business

The map is the answer to "where can I even play?" But it answers it in the opposite way to how a corporate strategist would. A corporate reader sees an industry where anyone can enter, customers hold the power, and shops fight on price, and concludes "avoid." A small business owner should read the same industry and conclude "enter", because those are exactly the conditions under which every shop is exposed, and the tool that would once have been a large company's advantage is now available to one person with a clear position and a machine.

Put the whole structural test across the domestic-layer industries, and the picture is clear. **Health & social services and specific professional services are the friendliest**, regulation keeps new players out, trust stops the fight over price, and the demographic tailwind is behind them. **Retail, food, admin, and personal services are hostile to anyone who competes on price, and therefore open to anyone who does not.** The very difficulty that grinds down a new entrant is the same difficulty that leaves every shop around you exposed: easy to enter, customers who compare, shops fighting on price. A business with a clear difference takes the premium tier, the niche, the slot the interchangeable shops have left empty. Education has pockets of premium in a shrinking base. Real estate is powerful for the landlord, constraining for the tenant.

**Your position is the open slot in the industry you can actually enter**, the word nobody in that industry owns yet, the niche the incumbents are too slow or too generic to take. The map does not hand you the word. It tells you which industries are worth looking for one in, and it tells you where the incumbents are weak enough that your word will actually take share.

There is one more force to read into this map, and it is the newest in the economy. **AI does not flatten these industries, it gives the small player the tool the incumbents do not have.** The industries that look "boring" or "brutal", retail, food, admin, personal services, the fragmented professional tiers, are precisely the ones where a single operator with AI can out-execute a shop that has done the same thing for twenty years. AI does the execution work, the scheduling, the quoting, the follow-up, the bookkeeping, the first draft, the analysis, at a cost and speed the incumbent's headcount cannot match. The trust and the judgement and the position remain with the small operator; AI just removes the reason the incumbent could compete on scale. The map is a list of industries where a positioned, AI-armed operator disrupts the incumbents, not a list of industries to avoid. That is the subject of the AI chapter, two chapters ahead; the next chapter, the brand map, names the incumbents it is worth disrupting.

That is why the series moves from "which wave" to "which industry" to "which slot." The demographic wave tells you which demand is growing. The industry tells you where that demand lands. The slot is the opening you can walk into. The next chapter, the brand map, names who already owns each industry, and shows the word no one has claimed. Then the AI map tells you which of those slots a small operator can take faster, cheaper, and better than the incumbents, because they have the machine and the incumbents do not.

### Working the map, three real-shaped industries, read honestly

A map is only useful if you can read it on a real business. It is worth walking the structural test through three real-shaped industries, so you can see how the map turns into a decision. Each is a different answer to the same question: is this a ground a small business can win on, and how?

**The home-care operator.** The demographic chapter showed the care wave is real and growing: the plan is to roughly double eldercare centres, and the senior share of the population is rising every year. The industry map adds the competition: regulation keeps new players out of the licensed layer, trust stops the fight over price, and the state is deliberately building the supply. That is a ground that is friendlier to a small operator than almost any other in the domestic layer, the wave is behind it, the competition is gated, and the customer buys on trust and referral. The small business that can own a slot in that ground, a specialist care team, a neighbourhood champion, a trusted referral name, is entering one of the few industries where the map says the ground is genuinely good.

**The hawker and the small F&B operator.** F&B is the hardest ground in the map. The value of the average F&B business is the lowest of any sector, the survival rate is brutal, fewer than a quarter of F&B businesses make it five years, and the competition is dense and undifferentiated. The structural test says this industry is hostile to anyone who competes on price, because everyone is competing on price. And yet the map does not say "avoid F&B"; it says "avoid being another interchangeable F&B shop." The hawker who owns a dish, a neighbourhood, a word the customer can repeat and refer is doing the one thing that breaks the hostile pattern: not competing on price, but owning a position. The difficulty of the industry is exactly what leaves the interchangeable shops exposed and the positioned one strong.

**The small professional services firm.** Professional services sits on the friendly end of the map, the value per worker is high, the customer buys on trust, and the demographic wave of foreign professionals brings new demand. The map says this is a ground where a small firm can win, if it can answer one question: what is the slot? The generalist accountant or consultant is interchangeable and fights on price. The specialist, the firm that owns one industry, one type of client, one problem, is the firm the customer recalls and refers. The industry is friendly; the position is the work.

Read these three together and the pattern of the map is clear. The map does not tell you the industry to be in; it tells you how to read the industry you are in. The home-care operator is in a friendly ground and still must position. The hawker is in a hostile ground and can still win by positioning. The professional is in a friendly ground and still needs the slot. The map is the ground; the position is the move; and every ground, friendly or hostile, rewards the positioned operator and punishes the interchangeable one.

---

## Sources & confidence

All figures are confidence-labeled in the text. Confidence labels: **High** = primary source (SingStat, MTI, MOM, DOS) or multiple independent sources; **Moderate** = secondary or single-source; **Low** = derived estimate. The industry value-added and share-of-GDP figures are verified directly from SingStat's detailed national-accounts table (M015731, 2025). Growth figures are from MTI's 2025 and 1Q2026 releases (overall GDP +5.0% in 2025; services producing +4.3%; info-comms/finance/professional +4.2%; accommodation/real estate/admin/other services +3.1%; manufacturing +8.8%; wholesale-retail/transport collective +6.7%). Health & social services and education "remained resilient" (MTI 1Q2026). Retail growth +5.0% (2025) and +4.0% (Jun 2026); F&B services +3.1% (2025) but −2.3% (Jun 2026); computer & telecommunications +9.8%; department stores −5.7% (SingStat Monthly Retail Sales & F&B Services Index). Manufacturing cluster detail from MTI 1Q2026. Establishment counts from SingStat. Competitive registration data from ACRA.

**Directional industry estimates (assembled from available online data, caveated):** Personal Care, Beauty & Hair Dressing Services, ~5,540 establishments, ~S$1.37bn operating receipts (SkillsFuture/SSG industry profile, Moderate); private tuition, ~S$1.8bn/yr household spend (HES 2023), 1,000+ MOE-registered centres, 7-in-10 parents send a child for tuition (MOE parliamentary answer; SmileTutor/TODAY secondary, Moderate); eldercare/home-care, ~220 eldercare centres target by 2025, 223 Active Ageing Centres, doubling nursing-home beds (MOH/AIC, Moderate); e-commerce platform share and cross-border share (secondary).

Where a figure is directional, it is flagged in the text. All figures reflect data as of August 2026.






# PART FOUR, THE BRAND MAP

## Who owns Singapore's money, and the words no one owns yet


---

The industry map named the terrain. The demographic chapter named the demand. This chapter names who is already taking that money, and, just as important, what they have not taken.

Because the question every small business owner is really asking, after reading about the ageing, the shrinking household, the growth in care and health, is not "which industry." It is sharper and more personal. **Who is already in this market? And what are they missing?**

The answer has a shape that matters more than any single name. Singapore's brand economy is two things, and they are opposites, not one thing.

In some industries, a handful of names capture four-fifths of the money. Grab owns food delivery. DBS, OCBC and UOB own the banks. PwC, Deloitte, EY and KPMG own the audits. In those, you do not enter unless you find the gap the giant left.

In others, no name owns even a fifth. A billion dollars of tuition is spent a year, and no single centre can claim a meaningful slice. The same is true of home care, of laundry, of beauty, of the food identity people cross the island for. The money is there, growing, and no one has claimed it.

That is the map. And the difference between those two kinds of industries, the concentrated and the fragmented, is the difference between a wall and a door.

---

## Chapter 1, The map, and how to read it

Before the map starts, let me take you through one ordinary evening. It is the fastest way to show you how the way you actually think about buying works, because you will use it, without noticing, before the day is out.

**Six o'clock.** Your phone pings. You are hungry, you have forty minutes before class, and you are staring at a grid of food images on Grab. You scroll past the same three hawkers you always scroll past, and you end up ordering from the one you already know, the stall you'd walk to if you weren't late. You did not think "delivery platform versus sit-down restaurant." You thought *what do I want to eat right now?* and every option in your head, the hawker, the burger chain, the food court, was competing in that same thought. That thought is a **mental category**, and it is the thing a brand is actually fighting for.

**Eight o'clock.** You're at the mall. The kids want bubble tea. You walk past four counters, LiHo, KOI, Gong Cha, Tiger Sugar, and you pick the one your daughter pointed at, which is to say you pick a *name*, not a flavor, because the drinks are nearly identical. The name is the brand. And here is the question this map cares about: is there a bubble-tea *word*, "the one", that any of them owns in your head? Maybe LiHo, maybe not. It is an open question, not a settled fact. I will flag it as such rather than pretend I know.

**Midnight.** You are doing the week's groceries on your phone. The order goes to RedMart, which is a shelf run by Lazada; the products themselves are names you recognise from the aisle. The brand of the *product* and the brand of the *store* are two different things, and the store is really a shelf.

Three things happened that evening, and they are the three layers of every map in this chapter. They are not academic categories; they are the three different ways you think about a purchase without noticing.

**The first layer is the industry, the official category the government uses.** ACRA (the Accounting and Corporate Regulatory Authority, the agency every company registers with) and SingStat divide the economy into industries, food services, retail, education, each with a code and a share of the country's output. It answers *"what business, legally and statistically, is this?"* It is where you get your bearings; it is not where you decide anything.

**The second layer is the product category, how the money is actually spent inside that industry.** Delivery, fast food, coffee, food courts, restaurants, hawker, these are product buckets, and the money flows differently through each. It answers *"how is the money moving?"*

**The third layer is the mental category, the word, and this is the layer where a brand is won or lost.** It is the thought in your head at six o'clock, *what do I want?*, and the name that owns a single word inside it. Starbucks owns "premium coffee." The kopitiam (the local coffee shop) owns "kopi." Whether a bubble-tea name owns its word, that is the *question* the map raises, and the one a new entrant could actually answer.

**And the two shapes, a wall or a door.** In some industries, a handful of names truly hold about 80% of the money (Grab and foodpanda own delivery; the three banks own banking). Those are **walls**, you don't enter; you look for the gap. In others, no name holds even a meaningful slice (tuition, salons, care, laundry), the money spreads across thousands. Those are **doors**. The missing brand is the opportunity.

From here, every section reads the same way: **the industry, then the product, then the word, who owns it, and which one is free.** And whenever the map says a word is "open" or "unowned," read it as a **lead to verify, not a settled finding**, the map shows you where to look, and primary research is what confirms the opening is real.

---

## Chapter 2, The walls: where a few names own the money



![The ladder of the mind.](print/figures/fig-ladder-mind.pdf)



These are the industries where the pattern actually holds: a handful of brands capture the overwhelming share. If you enter one of these, you are entering against a named giant, or into the slot the giant left open.

### Food & beverage, the industry, the products, the words

**The industry.** F&B services is a distinct official industry, about 1% of the country's output, and the largest single share of a Singaporean's disposable spend after housing. Whatever a business in this industry sells, this is the classification that defines it.

**The product categories.** The spend splits into these product buckets:

| Product category | The brands | Structure |
|---|---|---|
| **Delivery platforms** | **Grab over half, foodpanda the main rival, Deliveroo exited** | a two-name shelf, reach, not food |
| **Quick-service / fast food** | **McDonald's ~40%** of the slice; KFC, Subway, BK, Domino's | one giant, global chains |
| **Coffee shops & food courts** | **Kimly, Koufu, Food Republic** | the landlords of the stalls |
| **Full-service restaurants** | **Jumbo, Paradise, Putien, Dian Xiao Er** | a fragmented field of domestic groups |
| **Coffee & bubble-tea chains** | **Starbucks ~140, Luckin ~81, LiHo, KOI ~40, Gong Cha, Tiger Sugar** | contested, no leader |
| **Hawker stalls** | the thousands of independents | the long tail, no brands |

**The mental category, the word each one owns.** Here is what is in the Singaporean eater's head, and which brand has claimed which word:

| Mental category | Who owns the word | The word |
|---|---|---|
| **The everyday meal** ("what do I eat now?") | the **hawker**, authentic local; **McDonald's**, fast | one category, most-contested in the country |
| **The coffee & tea ritual** | **kopitiam**, kopi; **Starbucks**, premium; bubble-tea, **no clear leader, unverified** | two ends of one ritual |
| **The celebration meal** | **Jumbo**, chili crab; the occasion word otherwise **appears open** | the special-occasion budget |

The three layers stack into a single read: the **industry** says F&B; the **product categories** say how the money flows (delivery a shelf, fast food a giant, restaurants a field, hawker the tail); the **mental categories** say which words are taken and which *look* open, the everyday meal is giant-but-nameless, and whether anyone owns the bubble-tea word or the celebration word is a **lead worth verifying**, not a settled fact. **A small business does not enter "F&B"; it enters one product category, competes in one mental category, and takes one word.**

### E-commerce & marketplaces, the industry, the shelves, the words

**The industry.** Online retail sits within the retail-trade industry. Singapore's online retail is worth about **US$5.9 billion**.

**The product category / channel.** Two platforms hold four-fifths of it:

| Platform | Share | What it is |
|---|---|---|
| **Shopee** | **~52%** | the all-category marketplace |
| **Lazada** | **~36%** | the all-category marketplace (Alibaba) |
| Amazon | ~6% | the international marketplace |
| TikTok Shop | ~6% | social commerce |

**The mental category.** This is the map's clearest channel-versus-brand case: **a platform is a shelf, not a brand.** Shopee and Lazada own the marketplace, not the product, trust, service, or identity a customer chooses. When a shopper types a search into Shopee, they get a grid of near-identical products and the cheapest wins, there is no brand in that grid, only listings. The platform is *where you get found*; the brand is *what you must become*. For a small business, that is the whole opening, not a footnote.

### Supermarkets & grocery, the industry, the products, the words

**The industry.** Retail trade is one of Singapore's largest official industries, and grocery is its most routine slice, the weekly shop nearly every household makes. It is a big, stable pot of money: Singapore's retail food & beverage sales were about **US$12 billion in 2024**, and the supermarket format alone holds close to half of that.

**The product categories.** Grocery splits by format:

| Format | The brands | Structure |
|---|---|---|
| **Mainstream supermarkets** | **NTUC FairPrice ~35–42%, Sheng Siong ~28–30%, Macrovalue (ex-DFI, owns Cold Storage & Giant) ~16%** | three groups hold ~four-fifths |
| **Premium / specialty** | Cold Storage, Meidi-ya, Don Don Donki | the upscale and ethnic niches |
| **Budget / ethnic** | Mustafa, the deep-value players | the low-price tier |
| **Online grocery** | RedMart, FairPrice Online, Shopee Supermarket, Cold Storage Online | layered on the physical chains (Cold Storage now under Macrovalue) |

**The mental category, the word each owns.** In the shopper's head, the weekly shop is a reflex, not a decision, and each name holds a distinct word:

| Mental category | Who owns the word | The word |
|---|---|---|
| **"the trusted default"** | **NTUC FairPrice** | *the co-op, the reliable*, the reflex |
| **"the deal"** | **Sheng Siong** | *value, the cheapest* |
| **"the premium / specialty"** | **Cold Storage, Meidi-ya, Don Don Donki** | *quality, imported* |
| **"delivered to my door"** | RedMart, FairPrice Online | *convenience* (Amazon Fresh exited 2026) |

The three-layer read: the industry is grocery; the formats split mainstream/specialty/online; the words are owned by FairPrice (*default*), Sheng Siong (*deal*), Cold Storage (*premium*). One ownership wrinkle matters for anyone mapping this market: the third major player is no longer the international group it was. DFI sold all its Singapore supermarkets, the Cold Storage and Giant chains, to Malaysian group **Macrovalue** for S$125 million in March 2025, so the "third group" in the mainstream table is now homegrown-owned under new management, not an international incumbent. Three words, three reflexes, and the brands that own the weekly shop own a habit a new entrant cannot simply out-price.

### Fashion & apparel, the industry, the products, the words

**The industry.** Apparel and footwear retail is a distinct official industry. There is no official Singapore spend-share census, so the product layer below uses consumer consideration (YouGov) as the closest public measure, how many shoppers would consider a brand before buying.

**The product categories.** The shopping budget splits into very different products, and they are NOT one market:

| Product category | The brands | Structure |
|---|---|---|
| **Value / everyday fashion** | **Uniqlo** (consideration ~51%), H&M (~17%), SHEIN (rising) | Uniqlo owns the head |
| **Sportswear** | **Nike (~26%), adidas (~24%), Decathlon (~25%)** | the activewear pair + the budget sports player |
| **Luxury houses** | **LV, Gucci, Chanel, Hermès, Prada, Dior** | the global flagships at ION / MBS |
| **Domestic labels** | **Love, Bonito** (largest SEA womenswear) | the homegrown flagship |

**The mental category, the word each owns.** In the shopper's head these are NOT one "fashion" market, they are different decisions with different words:

| Mental category | Who owns the word | The word |
|---|---|---|
| **"everyday clothes"** | **Uniqlo** | *affordable basics*, the dominant word |
| **"performance / sport"** | **Nike** | *performance*, with Decathlon owning *value* in sport |
| **"a statement / luxury"** | the houses | *status*, Chanel, Hermès, the LV monogram |
| **"fast, trendy, cheap"** | **SHEIN** | *trend-fast*, rising among the young |

The department stores (Takashimaya, Isetan, TANGS, Metro, OG, BHG) sit across these, they are the *venue* that carries the brands, not a brand of their own, and Robinsons collapsed in 2020. The three-layer read: the industry is apparel; the products split value/sport/luxury/trendy; the words are owned by Uniqlo (basics), Nike (performance), the houses (status), and **no domestic label owns a major word.**

### Private healthcare, a three-group concentration

When a Singaporean says "I'm going to see my specialist," they do not usually mean a government polyclinic. They mean one of a handful of private hospital groups. Private hospital beds are concentrated in a handful of names.

| Brand | Share of private beds | Origin |
|---|---|---|
| **IHH Healthcare** (Gleneagles, Mount Elizabeth, Novena, Parkway East) | ~52% | International |
| **Raffles Medical** | ~380 beds, largest homegrown | Domestic |
| **Thomson Medical** | ~187 beds | Domestic |

IHH + Raffles + Thomson exceed **80% of for-profit private beds.** This is a concentrated market, you do not open a hospital. But the primary-care layer beneath it is a different story.

**The GP / clinic network layer** is where the names most Singaporeans actually visit sit. The clinic chains have consolidated:

| Chain | Position | Origin |
|---|---|---|
| **Healthway Medical** | the largest GP network | Singapore |
| **Raffles Medical** | the largest homegrown integrated provider (hospital + clinics) | Singapore |
| **Parkway Shenton** | the primary-care arm of IHH | Singapore (IHH) |
| **Fullerton Health** | corporate & clinic network | Singapore |

Every Singaporean has a GP brand in their neighbourhood, Healthway, Raffles, Parkway Shenton, Fullerton, and these chains own the everyday-doctor word in a way the hospitals cannot. This is the one healthcare layer a small operator can actually compete in, and the chains are the incumbents it faces.

### The engine layer, where the money is big and the door is shut

The industry map showed that wholesale, manufacturing, finance, transport, information, utilities and professional services hold most of Singapore's output but are closed to a typical small business. The brand map names who owns them, so a reader in these industries sees their own terrain. A small business does not enter these; it serves the people they employ. But naming the giants matters, it shows where the premium demand of the engine's payroll comes from.

**Finance, the three banks, then the world.** Singapore banking is a **DBS, OCBC, UOB** story. Your salary lands in one of them. Your CPF is paid from one of them. Your mortgage, your insurance premium, your kids' school fees, all flow through the same three logos, year after year. It is the plumbing of every Singaporean's financial life, not a market.

| Brand | Position | Origin |
|---|---|---|
| **DBS** | the largest bank; ~a fifth of the stock market | Domestic |
| **OCBC** | #2 local bank | Domestic |
| **UOB** | #3 local bank | Domestic |
| **HSBC, Standard Chartered, Citibank, Maybank** | the minority remainder | International |

The three local banks together dominate loans, deposits, and about a fifth of the entire stock market, the big three, then the world. DBS is the most valuable brand in the country.

Insurance splits in two. In **life**, the market is led by:

| Brand | Position | Origin |
|---|---|---|
| **Great Eastern** | #1 by premiums (est. 1908) | Domestic (OCBC) |
| **Prudential** | #2 | International |
| **AIA** | #3 | International |

In **general insurance**, the motor, home, and health policies, the market is a **S$11.2 billion** domestic-and-offshore book, with **NTUC Income** (now Income Insurance) the long-time #1, especially in motor, ahead of **Great Eastern General, MSIG, AXA, Tokio Marine, and Sompo**. Allianz's bid to take over Income collapsed in 2024, so the market stayed as it was, a homegrown leader holding a fragmented field.

**Telecom, a five-name market.** Mobile subscribers are a five-name game, and one holds roughly half. Your phone is in your hand right now, and the brand on the top-left of the screen is almost certainly one of these, that's how much of daily life runs through this table.

| Brand | Share | Origin |
|---|---|---|
| **Singtel** | ~43–50% | Domestic |
| **M1** | ~22% | Domestic |
| **StarHub** | ~21% | Domestic |
| **SIMBA** | ~14% | Domestic |
| Circles.Life | <2% | Domestic (MVNO) |

**Transport, the national champions.**

| Operator | Position | Share |
|---|---|---|
| **Singapore Airlines + Scoot** | the flag carrier and its low-cost arm | ~50% of Changi's seat capacity; S$19bn revenue |
| **ComfortDelGro** | the largest land-transport operator | ~64% of the taxi market |
| **SBS Transit** | parent-company bus + two rail lines | ~57% of bus ridership |
| **SMRT** | the larger rail network | majority of rail |
| **PSA** | the port operator | world's largest transhipment hub |

The transport champions' shares are directionally corroborated but less cleanly published than the telecom table above. Singapore Airlines and Scoot together make up about **half of Changi's seat capacity**, OAG's network analysis put the pair at exactly that mark, and the group carried a record 42.4 million passengers in its 2024/25 financial year. ComfortDelGro's taxi share is around **two-thirds of the fleet** (it held the dominant position as the market shrank from a 28,736-taxi peak in 2014), and SBS Transit runs about **three-fifths of the public bus market** (9 of the 14 bus packages). These are strong, directional, and consistent with the companies' own reporting, but unlike the telecom table above, they are not published as neat single percentages.

**The car, who sells it, and who services it.** The car is Singapore's most expensive want. To own one, you first buy a piece of paper, the Certificate of Entitlement (the COE, the state's auctioned right to put a vehicle on the road), which by 2026 cost more than S$129,000, then you borrow the rest. It is the premium display of arrival: a monthly payment committing years of future income. And the brand map names who sells that car, and who services it.

**New-car sales** have been transformed by the EV wave. **BYD** (Chinese) is now Singapore's #1-selling car brand, **21.2% of new registrations in 2025**, overtaking the long-time leader **Toyota** for a second straight year. EVs are now ~45% of new registrations.

\begin{table}[!htbp]\centering
\caption{New car registrations by brand, 2025}\label{tab:car-registrations}
{\small
\begin{tabular}{@{}p{9em}p{11em}p{6em}@{}}
\toprule
Brand & Share of new car registrations (2025) & Origin\\
\midrule
BYD & 21.2\% & China\\
Toyota & second (was the long-time \#1) & Japan\\
Tesla, Honda, Hyundai + others & the remainder & International\\
\bottomrule
\end{tabular}}
\end{table}

**Car servicing and the accessories market** is the fragmented tail. Authorized-dealer workshops (BYD, Toyota, etc.) hold the warranty-service layer; the independent aftermarket is a field of workshops, with the only foreign chain being **AUTOBACS** (Japan, 2 outlets). There is no published Singapore brand-share table for servicing, like the other-services repair market, it is genuinely fragmented, and no independent workshop brand owns the category.

**Energy, the state grid, foreign power.**

| Brand | Role | Share |
|---|---|---|
| **SP Group** | the state grid, sole network operator | 100% (grid) |
| **Senoko Energy** | largest generator | 18.7% |
| **Tuas Power** | second generator | 18.5% |
| **YTL PowerSeraya** | generator | 13.9% |

The state owns the wires; international capital owns the plants.

**Professional services, the Big Four's iron grip.** Every listed company in Singapore files its audited accounts with one of four names on the cover. PwC, KPMG, Deloitte, EY, together, essentially **100% of the market**. The same four names sign the audit, year after year, and a board that switches firms is a story, not a routine event.

| Brand | Share of STI audit fees | Origin |
|---|---|---|
| **PwC** | **53.7%** | International |
| **KPMG** | **28.2%** | International |
| **Deloitte** | **13.2%** | International |
| **EY** | **4.9%** | International |

The Big Four's grip is total and growing: every one of the thirty STI (Straits Times Index, the thirty biggest listed companies) companies audits with PwC, KPMG, EY or Deloitte, and the top of the fee pool is the most concentrated of all, PwC's STI clients paid S$81.1 million of the S$151.1 million total FY2025 audit-fee pool (53.7 per cent), and the five largest single audit bills made up nearly half of that pool. (Source: Business Times, "No room for a fifth?", Jul 2026.)

Legal is the three local giants, **Allen & Gledhill** (largest), **Rajah & Tann**, **Drew & Napier**, plus the international magic circle. Consulting is the MBB trio (McKinsey, BCG, Bain) plus the Big Four advisory arms.

**Wholesale, manufacturing, construction, admin, the B2B engine.**

| Industry | The dominant names | Share reality |
|---|---|---|
| **Wholesale** | **Trafigura, Glencore, Vitol** (foreign); **Olam, Wilmar** (Singapore) | the global houses dominate the trading volume |
| **Manufacturing** | **GlobalFoundries, Micron, TSMC** (foreign fabs); **Keppel** | foreign fabs hold the advanced nodes |
| **Construction** | **Keppel, Woh Hup, Boustead, Gammon** | the mega-projects are concentrated in a few |
| **Admin / security** | **Certis** (armed security), **ManpowerGroup, Adecco, Randstad** | Certis near-monopoly in armed security |

**Public administration & defence, the state, not a market.** The industry map lists public administration and defence at about **2% of output**, but this is the state itself, valued by its payroll, not by market transactions. The "brands" here are ministries and forces: **MINDEF** and the **SAF** on the defence side, the **Home Team** (police, civil defence, immigration, and the internal-security bodies) on the law-and-order side, and the **statutory boards** that run everything else. It is not a market a small business enters; at most a firm competes as a vetted government supplier through procurement channels. It matters to the map only as a boundary, a large, closed economy that the domestic layer does not sell into.

**Agriculture, fishing & mining, the policy-funded niche.** This is the smallest industry in the country, about **0.02% of output**, Singapore has no mining, and its farming is a land-scarce micro-economy driven by food-security policy, not scale. The real players are the urban farms: **Sky Greens** (the world's first commercial vertical farm), **Sustenir** (indoor leafy greens, Temasek-backed), **Apollo Aquaculture** (vertical fish farming), **ComCrop** (rooftop). None is a consumer brand of scale; the growth is funded by the state's "30 by 30" food-security goal and grants, not by consumer demand. The read: a subsidized, policy-driven niche, strategically important, commercially tiny.

### The rest of the domestic layer, the walls in your own neighbourhood

**Real estate, the agencies that move the transactions.** The biggest purchase a Singaporean ever makes is a flat. And that purchase is made through an agent whose agency is on the letterhead, not against a developer's name. The market is concentrated at the top: the Council for Estate Agencies counts about **36,800 property agents across ~1,000 agencies**, but four names hold the majority of them, a proxy for where the transactions flow.

| Agency | Agents (Jan 2026, CEA) | Position |
|---|---|---|
| **PropNex** | ~13,945 | Largest, listed |
| **ERA** | ~8,427 | #2 |
| **Huttons** | ~5,760 | #3 |
| **OrangeTee & Tie** | ~2,518 | #4 |

The top four hold about **85% of the 36,800 agents**; the other ~1,000 agencies share the rest. PropNex alone holds over a third of the country's agents. The developers sit above the agencies, **CapitalLand** is the largest, and the REIT (real estate investment trust) managers own the commercial property layer.

**Accommodation, the two resorts at the top.** Singapore's accommodation is anchored by **two integrated resorts**, inside a tourism economy worth a record **S$32.8 billion in 2025** (16.9 million visitors). Hotel performance that year: **81.9% average occupancy, S$273.56 average room rate, S$224.04 RevPAR** (revenue per available room), across more than 400 hotels and 70,000-plus rooms.

| Brand | Share of luxury market | Position | Origin |
|---|---|---|---|
| **Marina Bay Sands** | **~12.8%** | 1 of the two giants | International (Las Vegas Sands) |
| **Resorts World Sentosa** | **~8.5%** | the second giant | International (Genting) |
| **Shangri-La, Capella, Raffles** | n/a | the homegrown luxury names | Singapore |

The two resorts dominate the premium end. The luxury locals, Shangri-La, Capella, Raffles, own the homegrown prestige. The rest of the roughly 400 hotels is a fragmented market of international and local brands.

**Arts, entertainment & recreation.** Recreation splits into two concentrated markets, and both are shrinking or lopsided. In **cinema**, one name towers, and even it is presiding over a declining habit:

| Operator | Share | Origin |
|---|---|---|
| **Golden Village** | **~53% of box office** | Singapore |
| Shaw, Cathay | the minority | Singapore |

Attendance has halved from over 20 million to under 10 million a decade later, so the box office is a shrinking pie that GV dominates.

In **gaming and the integrated resorts**, the market is a two-licence duopoly, and the split is now lopsided:

| Operator | Casino revenue / share | Origin |
|---|---|---|
| **Marina Bay Sands** | **US$2.1bn casino revenue, H1 2026** | International (Las Vegas Sands) |
| **Resorts World Sentosa** | less than a third of MBS; share fell to **~28–31%** (from ~40% pre-Covid) | International (Genting) |

The casinos anchor the top of the recreation spend, and together the two-licence duopoly pulled in a combined **S$7.05 billion in gaming revenue in 2025**, up 24 percent in a year, one of the strongest growth lines in the whole economy. The attractions, Universal Studios, the Oceanarium, Gardens by the Bay, sit under the resorts and the state attractions groups. The other growth line is **live events**: a record tourism year (S$32.8bn) was led partly by exclusive concerts (Lady Gaga, Blackpink, Seventeen), F1, and the arts fairs.

**Consumer goods, the brands in every Singaporean home.** The industry map's "manufacturing" row was about foreign semiconductor fabs, but the packaged goods a Singaporean buys every day are a category of their own. Walk into any Singapore kitchen and you will find the same shelf: the chrysanthemum tea, the Tiger beer in the fridge, the bottle of tiger balm in the drawer that has been there since the 1970s, the bread that the whole family knows by name. A mix of homegrown icons and global giants.

| Brand | What it owns | Origin |
|---|---|---|
| **F&N (100PLUS, Ice Mountain)** | the homegrown drinks giant | Singapore |
| **Yeo's** | century-old beverage staple | Singapore |
| **Tiger Beer** | the national beer | Singapore |
| **Gardenia** | the bread everyone knows | Singapore-origin |
| **Tiger Balm** | the medical-staple icon | Singapore |
| **Maggi, Dettol, Dove, Lifebuoy, Calbee, Oreo** | the most-considered FMCG brands (YouGov) | International |

YouGov's ranking of the most-considered FMCG (fast-moving consumer goods, the everyday packaged brands) brands in Singapore is telling: the top of food is **Maggi (Nestlé)** and the top of personal care is **Dettol (Reckitt)**, both global, with homegrown **Khong Guan** the first Singaporean name to make the food list. The pattern: the global houses own the "consideration" head of FMCG, and the homegrown icons (F&N, Yeo's, Tiger Beer, Gardenia, Tiger Balm) hold the culturally-loaded loyalty. These are the brands a Singaporean cannot picture the country without, and most are absent from a pure industry-share map because they sit inside the manufacturing aggregate.

---

## Chapter 3, The doors: where no name owns it yet



![The walls and doors.](print/figures/fig-walls-doors.pdf)



These are the industries where the 80% rule does not hold. The money genuinely spreads across thousands of small operators, and in these, the missing brand is the opportunity itself.

### Tuition & enrichment, a billion dollars, no owner

Every weekend, the family sedans line the streets outside the tuition centres. The children carry bags twice their size, and the parents sit in the air-con lobby scrolling while a tutor earns more per hour than they do.

**The industry.** Education sits in the official map (~2.3% of output). **The product categories.** Private tuition and enrichment is one product bucket, worth about **S$1–1.8 billion** a year, and the money is concentrating even as the base shrinks. The spend grew **29% in five years and 64% since 2013**; the average household now lays out **S$104.80 a month**, and the top-fifth of families spend **S$162.60** against the bottom-fifth's **S$36.30**, a four-and-a-half-fold spread, the widest inequality gap in the spending map. **The mental category** is the whole story, and it is that no single centre captures even a meaningful slice:

| Brand | Position | Share reality | Origin |
|---|---|---|---|
| **Mind Stretcher** | Largest by footprint | <2% of a S$1.8bn market | Singapore |
| **The Learning Lab** | Premium marquee brand | <2% | Singapore |
| The Write Connection, Ignite, Indigo | Next tier | each <1% | Singapore |
| **British Council, Kumon** | International methods | niche | International |
| ~1,000 MOE-registered centres + freelance tutors | The long tail | the great majority | Singapore |

The result is a category strategy books refuse to believe exists: a billion dollars with no name owning it. A parent does not say "I send my child to the category leader", they name a specific centre, and that centre could be yours. That is the opportunity.

### Senior care, a leader, then a tail

The phone call every adult child dreads comes at two in the morning: the parent has fallen, the caregiver is not enough, and someone has to decide where Mum goes next. That decision, the hardest financial and emotional one a family makes, has no brand that owns it.

**The industry.** Health and social services sits in the official map. **The product categories.** Nursing-home and senior-care beds are the product. **The mental category** is the decision a family makes under pressure, and who, if anyone, owns it:

| Operator | Position | Share |
|---|---|---|
| **Econ Healthcare** | largest private nursing-home operator | ~27% of private revenue |
| **NTUC Health, St Andrew's** | the co-op and charity tier | the balance |
| the VWO / charity long tail | dozens of homes | the balance |

The family that is searching does not say "send her to the category leader", they say "send her to the place the neighbour recommended." No single brand owns the family's decision: a leader around a quarter, then a long tail. Whether a name could own that word, the trusted choice for a hard decision, is the open question a new entrant would test.

### Beauty & personal care, the industry, the products, the words

**The industry.** Beauty and personal care spans retail and other-personal-services in the official map. It is a real, growing pot of money: Singapore's beauty and personal-care market was worth about **US$1.24 billion (S$1.67 billion) in 2024**, and the pharmacy chains that dominate the retail shelf hold roughly **80 per cent of the channel**. That is a meaningful number for a would-be entrant, the product word is not just "taken," it is taken by a pharmacy oligopoly.

**The product categories.** The market splits into three very different products:

| Product category | The brands | Structure |
|---|---|---|
| **Beauty & personal-care products** | **L'Oréal ~10%**, plus the pharmacy gatekeepers | the product leaders |
| **Retail pharmacy channel** | **Guardian, Watsons, Unity** | ~80% of the pharmacy-beauty channel |
| **Salons & services** | **Kimage, Leekaja, 1989, KC Group** | no chain holds meaningful share |
| **Homegrown beauty labels** | **Sigi Skin, Allies of Skin, Skin Inc, Kew, Romi, Estetica** | 34 Singapore brands, going global |

**The mental category, the word each owns.** This is where the market's two halves part:

| Mental category | Who owns the word | The word |
|---|---|---|
| **"the product I buy"** | the global houses | *quality*, owned |
| **"the salon I go to"** | no chain holds a meaningful share | *possibly open*, worth testing |
| **"a Singapore beauty brand"** | the homegrown wave | *local pride*, being built |

Every Singaporean has walked past the same three pharmacy logos on every mall floor, the product word is owned. But the salon where she gets her hair done is a name no one can guess, because no chain holds a meaningful share. That is the same shape as tuition, a fragmented, growing category where a brand could be built, and a lead worth testing with primary research.

### Repair, laundry & the rest of "other services", no owner at all

The official "Other Services" tail, repair, laundry, and the personal-services residual, is the least-measured part of the map, and no brand captures meaningful share in any of it.

| Segment | The names | Share reality |
|---|---|---|
| **Electronics repair** | **Apple** (authorised service), **Song Kwang** (SG, self-claims largest repair fleet) | fragmented; no share data |
| **Watch repair** | **Swatch Group** (OEM), independent specialists | fragmented |
| **Auto repair** | **AUTOBACS** (only foreign chain, 2 outlets) | fragmented |
| **Laundry** | **Piing, WashSquad** (on-demand apps) | no share data |
| **Funeral** | **Singapore Casket, Ang Chin Moh, Nirvana Group** | CCCS found >800 providers, low concentration, genuinely no dominant brand |
| **Barber / salon** | **Truefitt & Hill** (heritage), Kimage | fragmented |

This is where the pattern is strongest, but it must be read carefully: two different truths sit here. **Verified**, the funeral market genuinely has no dominant brand (a competition regulator, CCCS, counted more than 800 providers, that is measured, not assumed). **Unverified**, for repair, laundry, and watch servicing there is simply no published share data, which is a gap in the map, not proof the field is open. Both are opportunities to investigate, but the first is a finding and the second is an absence of evidence.

### Pets, a growing category consolidating around a few names

**The industry.** Pet care spans retail and services. **The product categories.** The market, worth about **S$412 million in 2023** (up 12.5% in a year), splits into pet food (**S$185 million**), veterinary services (**S$120 million**), and retail (the remaining **~S$107 million**, grooming, boarding, and supplies). The food and retail words are consolidating around international names, the top five hold roughly 55 per cent of food spend, while the veterinary word is contested and the category as a whole is projected to keep compounding.

| Brand | Share reality | Position | Origin |
|---|---|---|---|
| **Mars Veterinary** (Mount Pleasant, VES) | corporate vet leader; no published % | the vet-group leader | International |
| **Pet Lovers Centre** | largest pet retail chain in SEA | the domestic retail end | Singapore |
| **Mars, Nestlé, Colgate, WellPet** | **top five hold ~55%** of pet-food spend | the product leaders | International |

**The mental category.** A pet owner's decisions are three different ones, *what I feed* (owned by the global product houses), *who treats my pet* (the corporate vet groups, but no single name), *where I buy the stuff* (Pet Lovers Centre). Of the three, only the veterinary decision is genuinely up for grabs, a name that could own "who treats my pet" in a growing S$120 million market. It is a growing category with the ownership still settling, an open slot as it consolidates.

### The iconic homegrown brands, known to every Singaporean, small in share

Ask a Singaporean what their country tastes like and they do not name a share leader. They name a curry puff from a chain that does not dominate its kiosk category. They name a bottle of chrysanthemum tea a century old. They name the bakery their grandfather went to. These are the names every Singaporean knows even though none dominates its category, old, trusted, and culturally loaded even where their market share is small.

**The heritage consumer-goods names**, **Yeo's** (beverages, a century old, one of the region's largest), **Tiger Beer**, **Tai Chong Kok** (bakery since 1935), **Lim Chee Guan** (bak kwa), **Kele** (pineapple tarts), **Old Chang Kee**, are household names that anchor Singaporean identity. Their share is small in fragmented categories, but the *word* they own, "this is the Singapore original", is huge.

**The SG Heritage Businesses**, the National Heritage Board in 2025 recognised **42 businesses** with 30+ years of history. The F&B names are the famous ones: **JUMBO Seafood, Swee Choon, Spring Court, Red Star, Chatterbox, Shashlik, Muthu's Curry, Komala Vilas**, plus the heritage craft shops and teahouses (**Tea Chapter, Yixing Xuan, Lim Chee Guan**). Each is a word in the mind of every Singaporean.

These brands are the **living proof of the thesis**: a brand does not need a dominant share to own a word. Old Chang Kee does not dominate its kiosk category in share, yet it owns "curry puff", a word no rival can take. The giants of this chapter own scale and channels; these icons own a word held for generations, exactly what a small business is trying to build.

---

## Chapter 4, Why the map is split this way, and what it means

The map is the walls and the doors. But the most important question is the one the map cannot answer by itself: *why* is Singapore split this way? Because every wall on this map has a birth certificate. Every open door is an inheritance. Once you understand how both came to be, the map stops being a spreadsheet of industries and becomes a story, the story of a tiny island that had to build its own giants, borrow a few more from the world, and leave the rest to its people.



### The walls the state built

Begin with 1965. Singapore had just been expelled from Malaysia, a country it was told would never survive on its own. It had no army. Its port was not yet the world's. Its economy ran on servicing a British naval base that was closing down. Hundreds of thousands were unemployed. This was not a country that could afford to wait for the market to figure things out. So it did what no other small nation has ever done with such single-mindedness: **it built its own champions, big, on purpose, and it has never once looked back.**

- **DBS** was created in 1968 because no private bank would lend a new nation the money to industrialise. The state said, in effect, *if the market will not do it, we will.* It went on to become the most valuable brand in the country.
- **Singapore Airlines** was carved out of the joint carrier with Malaysia in 1972, a deliberate national champion, a wing-borne flag to carry a tiny island's exports, its reputation, and its ambition to the world.
- **Singtel, SP Group, PSA, ComfortDelGro**, one national operator for the telecom, one for the grid, one for the port, one for the transport. Three grid operators would have been a luxury a small island could not afford; one, given a licence and a moat, was a necessity it could not live without.
- **The casinos**, when Singapore finally relented and allowed gambling, it did not open the door; it cut a window. **Two licences. Ever.** One to Las Vegas Sands, one to Genting. The purest case of the state rationing competition into a duopoly on purpose.

This is the engine layer's origin in one line: **concentration in Singapore was never a market accident. It was a national-security decision.** The state did not *allow* these industries to consolidate; it *built* them that way, because a country that could not afford failure could not afford duplication.

### The walls we borrowed from the world

Then Singapore got rich, staggeringly, deliberately, faster than almost any economy in human history. And with wealth came a second kind of wall: the ones the world brought in.

The supermarkets, the malls, the fast food, the coffee, the fast fashion, these did not grow from local soil; they were imported, because once Singaporeans had money, the world's biggest consumer brands came for it. **McDonald's, Starbucks, Uniqlo, H&M, KFC, Nike** all set up shop the moment the island's income made them worth the effort. They brought their global scale, their global supply chains, their global brands, and they won, because a brand that has conquered a hundred countries is very hard for a local shop to beat on its home turf.

Singapore answered with its own scaled players where it could, the **FairPrice** cooperative, **Sheng Siong's** relentless value, **Cold Storage's** premium, and where it could not, the wall stayed global. This is why the concentrated consumer industries are the way they are: not state-built this time, but *global-scale*. A grocery chain and a flag carrier both need a wall; one built by the state, one built by the world's biggest brands.

### The doors we left to the people

Now the part of the story almost everyone misses. The hawker stalls, the tuition centres, the salons, the laundries, the workshops, **the state never touched these. Never built them, never consolidated them, never even really noticed them.** And that is the deepest decision of all, not an oversight.

The hawkers fed the city long before there was a food court, and the state's instinct was never to make one big hawker but to make sure food was cheap and everywhere, so the hawker stayed small, and stayed many. The tuition culture grew out of a PSLE exam system the state *created* but never chose to run, so the centres stayed private and stayed fragmented. The salons and workshops were always the refuge of the self-employed, the way ordinary Singaporeans have earned a living for a century. No one needed a tuition monopoly; one needed every child to have a chance at the exam. No one needed a salon champion; one needed a haircut that did not cost a fortune.

So the split is not random. **The concentrated industries are where the state, or the world's giants, decided the money mattered and built a wall. The fragmented industries are where no one bothered to build anything, and the people filled them with thousands of small operators, because there was never a reason to consolidate.** The walls are where Singapore decided to be great. The doors are where it decided to be free.

### How rare is a brand that grew without the state?

This is the question that should make every small business lean in. Singapore is one of the world's most state-engineered economies, but it is not a *state-only* economy. And here is the lesson: **the brands that grew big without a state parent are rare, and the ones that did it almost all did it in the doors.**

The heritage names we met earlier, Yeo's, Old Chang Kee, Tiger Balm, are the small-share proof that a word can be owned without scale. But the truly rare feat is the brand that grew *big* with no licence and no state parent: **Charles & Keith**, two brothers who built a global footwear label from a single shop in 1996; **Banyan Tree**, a hotel brand founded on a bold idea, not a state grant; **BreadTalk**, a bakery brand that crossed borders; and, most recently, **Grab**, **Shopee**, **Carousell**, internet companies that grew from nothing in the digital era, with no state licence behind them.

Every single one of these became big in a **fragmented, open category**, footwear, hospitality, bakery, and then the internet, not in a state-built wall. None of them tried to out-build DBS or out-scale Singapore Airlines; they won a *word* in a category the state had left open, and they grew it until the word was the whole category. Even the giant **Temasek-linked** names we all take for granted, and make no mistake, most of Singapore's big brands sit under state holding companies, were built *into* walls that already existed.

So the answer is: **in Singapore, a brand that grows big without the state is rare, and it is rare precisely because it can only happen in a door, and doors are the exception, not the rule.** The state's champions are the norm; the self-made brand is the exception that proves how hard it is. But the exception also proves it is *possible*, and that every one of them was built by an ordinary person who chose an open category and owned a word.

### And the era of the wall is turning

Here is the part that changes the map's meaning for you. The state's champions are not gone, but their grip is loosening at the edges. The banks the state built now face digital banks the state itself licensed, **Trust, GXS, MariBank**, new challengers born not from a national-security need but from a digital-age one. The consumer economy around the flag carriers was always fragmented, and it is precisely there, in the food, the care, the services, the niche, that a small operator with a clear word can now out-execute an incumbent that has done the same thing for twenty years.

The state's own strategy is why the doors exist. It concentrated its capital on the few industries that mattered to national survival and left everything else to the people. And the people, as Yeo's, Old Chang Kee, Charles & Keith, and Grab all proved, will build a brand when given an open field.

**The walls are the state's construction, and the state's great gift to the small business is the door.** The one who builds a brand in the free, growing, fragmented corner of this economy is doing exactly what the state's own heroes did, the only difference being that they did it with a word, not a licence.

### The pattern, what the names add up to

**The engine is owned by scale, not by words.** DBS, SIA, Singtel, SP Group, the Big Four, the commodity houses, the foreign fabs, the concentration points of the economy. They own licences, networks, state links, capital, not a word in the mind of the person who could be your customer.

**The concentrated consumer industries are channels, not words.** Grab owns the delivery, Shopee and Lazada the shelf, the hospitals the beds, the Big Four the audit. Each is a platform or a scale asset, not "the hawker you trust" or "the single-subject maths tutor."

**The fragmented industries are where no brand owns the share, but a word can still be taken.** Tuition has a billion dollars and no dominant name. Home care has growing spend and no one owns the family's decision. Personal services, laundry, wellness, all fragmented, all un-owned. And the demographic chapter showed these are precisely the industries the waves are growing: ageing, care, the smaller household, the pet.

**The fragmented industry that is also a growing industry is the rarest, most valuable thing in the map, a category with money and demand, and no name that clearly owns it.**

That is the synthesis. The giants own scale and channels, not words. The fragmented categories have the words, growing and valuable, and none appears to own them, a claim the map makes as a directional lead, to be confirmed with primary research. **The slot is "find a category where the money is growing and no name owns it, verify that, then own the word," not "find an industry."**

### What this map can and cannot tell you

A few things to keep in mind as you use it, so you neither over-read nor under-read what follows.

- **Shares are ranges, not false precision.** Where sources disagree (supermarket), the chapter gives the range and the reason, never a fabricated single number.
- **Platforms are separated from brands.** The channel (Grab, Shopee) is not the product brand (the hawker, the tuition centre).
- **Fragmented industries are named as fragmented**, not forced into a fake concentration. Where 80% is not real, the chapter says so and accounts for the rest by segment.
- **"Open slot" is a hypothesis to test, not a measured finding.** A business must verify it with primary research.

### The bridge, the name missing is the word you could own

The demographic chapter told you which demand is growing. The industry map told you where it lands, and, in the slots it named, exactly what a small business can walk into: the dementia-specialist home carer, the ageing-in-place consultant, the boutique day centre, the laundry done for the person with no time, the deep-niche enrichment, the tech specialist for the clinic and salon. The brand map named who already owns each territory, and, by subtraction, where the word appears to be unclaimed, to be confirmed.

That is the map, not a wall. You do not fight the platform; you use it. You do not out-scale the hospital; you own the care it does not. The empty word in a growing, fragmented industry is where a brand can be made, and the reason the next chapter in this series, the AI Map, is where the making begins.

### Reading the walls and doors as a small business

It is worth bringing the walls-and-doors map down to the ground where a small business actually decides, because the distinction is the difference between entering a fight you will lose and entering a ground you can win, not an academic one.

**The wall is the ground you should not fight head-on.** When a few names own the money, the banks, the delivery platforms, the supermarkets, the hospitals, a small business that tries to out-compete them on their own terms loses. It cannot out-scale DBS, out-spend Grab, or out-shelf Shopee. This is the reading of the map, not pessimism. The wall is where the money is concentrated, and where a small operator without scale, capital, or a state link cannot win a head-on fight.

**But the wall has cracks a small business can walk through.** The wall is owned by scale, not by words. DBS owns the licence and the network, not "the trusted adviser for a specific community." Grab owns the delivery platform, not "the specialist who serves my neighbourhood." The hospital owns the beds, not "the care the patient's family trusts after discharge." The wall owns the channel and the scale; it does not own the word, the relationship, the niche, the local trust. Those are the cracks, and they are where a small business can enter without fighting the wall.

**The door is the ground where no one owns the money, and where a word can be taken.** The fragmented industries, tuition, home care, personal services, the niche professional tiers, have money and demand and no dominant name. This is the ground a small business can actually own. The door is crowded with interchangeable shops fighting on price, not "easy." But it is winnable, because the business that owns a word in a door stops being interchangeable and becomes the name people recall and refer.

So the reading of the walls and doors is this: **do not fight the wall head-on; walk through its cracks. Do not treat the door as easy; treat it as the only ground you can actually own.** The walls tell you where the money is concentrated and where you cannot win by scale. The doors tell you where the words are unclaimed and where you can win by owning one. The map is the guide to which parts of the economy a small business can genuinely take, not a warning to stay out of it.

### The one-question test of your ground

Bring the whole brand map down to one question a small business can ask about its own ground: **in my category, who owns the money, and can a customer name anyone besides them?** 

If a few names own the money and the customer can only name them, you are in a wall, and you should not fight it head-on; you should find the crack, the word, the niche they do not own. If no name owns the money and the customer cannot name anyone, you are in a door, and you should own a word before someone else does. If you cannot answer the question, the map is telling you the ground is not yet clear enough to act on, and the move is to find out.

That is the whole brand map in one question. It tells you whether you are facing a wall or standing in a door, and it tells you the move, walk the crack, or own the word. The map does not decide for you; it tells you which ground you are on and what kind of win is actually available there.

---

## Appendix, the brands every Singaporean knows, but that don't move the decision

These are the brands a Singaporean touches every day without thinking, the app that pays the hawker, the warehouse that restocks the fridge, the hotel chain the auntie checks into in Bangkok. They are channels, state assets, or consumer layers that do not open a door for a small business. They belong on the census for completeness, and out of the main argument, because they are not where a brand can be made.

**Payments & the digital banks**, the rails under every transaction. Digital wallets are ~39% of online, ~29% of in-person spend. **PayNow** is the dominant rail (68% of Gen Z prefer it); **DBS PayLah!** leads wallets at ~26%, then **GrabPay, ShopeePay, Google/Apple Pay**. The digital banks, **Trust, GXS, MariBank, ANEXT, Green Link**, are each an ecosystem tie-up. A channel: it owns the transaction, not the brand.

**Online grocery**, riding on the supermarkets. **RedMart** (largest), **FairPrice Online**, **Shopee Supermarket**, **Cold Storage Online**, after **Amazon Fresh exited in July 2026**. The trusted names are the physical grocers that went digital; no pure online-grocery brand owns the category.

**Home & electronics retail**, the big-box set. **Courts, Best Denki, Gain City, Harvey Norman, Challenger**.

**Apps & tech**, the homegrown platforms that went regional: **Carousell** (57m listings), **PropertyGuru**, **ShopBack**; the social layer is international (WhatsApp 80% usage, TikTok, Telegram).

**Destination brands**, the visitor-facing names, almost all state-owned: **Changi & Jewel, Marina Bay Sands / RWS, Mandai Wildlife Group, Sentosa, Gardens by the Bay**. The tourism brand economy of Singapore is largely a public brand, not a private one.

**Hospitality groups**, Singapore-headquartered operators that compete globally: **Pan Pacific / PARKROYAL, Capella** (Travel + Leisure's best hotel brand 2023–26), **Far East, Frasers, The Ascott**.

---

## Sources & confidence

All figures confidence-labeled. **High** = primary or multiple independent; **Moderate** = single credible/secondary; **Directional** = structural reasoning. Key sources: Momentum Works/CNA (food delivery Grab the clear leader, market ~US$3B); Statista (McDonald's ~40% of SG QSR); CNBC/Mothership/Vulcan Post (Starbucks 140+, Luckin ~81, KOI ~40, Gong Cha exit, Moderate); Mordor (BreadTalk leader, low concentration); Momentum Works/Straits Times (e-commerce Shopee 52%, Lazada 36%, US$5.9B); Euromonitor & USDA FAS (grocery); YouGov (fashion consideration), smartlocal (department stores, luxury anchors), CNBC/Luxuo (LV floating store); JHMHP 2023 bed census (hospitals); Econ Healthcare SGX/Euromonitor (nursing); MOE/tuition brands (directional); L'Oréal & pharmacy chains (Euromonitor/US ITA); **GIA (general insurance S$11.2bn, motor leader NTUC Income)**; Reuters/MAS (banks); Insurance Asia (Great Eastern #1 life); Business Times (telecom shares); SIA Annual Report, OAG (SIA capacity); Business Times (taxi 64%, bus 57%); EMA (energy); Business Times Big Four (PwC 53.7%, etc.); Chambers/Legal 500 (legal); commodity houses & fabs; CEA industry statistics (real estate agents); STB (tourism receipts S$32.8bn, hotel metrics); cinema coverage (Golden Village ~53% box office); **Business Times/JP Morgan/GGR Asia (gaming: MBS casino revenue US$2.1bn H1 2026, RWS share ~28–31% record low, from ~40% pre-Covid)**; **STB (live events led tourism receipts growth)**;

**MINDEF/MHA/SGDI (public admin structure); SFA/SingStat (agriculture ~0.02% GDP, urban farms); CCCS (funeral market >800 providers, low concentration);

Kimage/Truefitt & Hill/Piing/WashSquad (other services, no share data)**; **NHB SG Heritage Business scheme (42 recognised 30+yr brands: Yeo's-adjacent F&B icons, Lim Chee Guan, Tai Chong Kok, tea houses, High/primary)**; **CNA/NLB (Yeo's heritage, century-old beverage major)**; **YouGov FMCG Rankings 2023 via Branding in Asia (most-considered FMCG: Maggi 30.3, Dettol top personal care, Khong Guan first homegrown)**; CEA via CNA (property agents); PwC STI audit fees (Business Times).



### Enriched category sizes (verified, live)

| Category | Size | Source |
|---|---|---|
| Private tuition | **S$1.8bn (2023)**, +29% vs 2018, +64% vs 2013; avg S$104.80/mo/household; top-20% S$162.60 vs bottom-20% S$36.30 | https://smiletutor.sg/singapore-families-spent-1-8b-on-private-tuition-in-2023-heres-what-that-means-for-2025/ (SingStat HES) |
| Beauty and personal care | **US$1,244m (~S$1.67bn) 2024**; pharmacy chains ~80% of channel | https://www.trade.gov/market-intelligence/singapore-beauty-and-personal-care-market (Statista via ITA) |
| Pet care | **S$412m (2023)** +12.5% YoY; pet food S$185m; vet services S$120m; CAGR 8.7% to S$650m by 2028 | https://gitnux.org/singapore-pet-industry-statistics/ |
| Care / day-care prices | day care from S$55/session, dementia S$63/session, nursing home S$2,000–4,500/mo | https://www.aic.sg/care-services/day-care; https://www.homage.sg/resources/elderly-care-options-singapore/ |




## How AI opens doors for the one-person company, and closes them on the incumbent who never built a relationship




There is a tuition centre in Toa Payoh that has been there for eleven years. It has three classrooms, a receptionist, and a reputation built slowly, student by student, on the PSLE results the families in the neighbourhood talk about at the coffee shop. The owner has never needed to advertise. The parents find him the way they find everything, through a neighbour who knows a parent whose child went there.

Next door, on the same floor, a younger tutor has just rented the unit. She has no classrooms. She has no receptionist. She tutors one subject, maths, and she is very, very good at it. What she does have is a suite of software agents that handle her scheduling, her parent messages, her practice materials, and her marketing, while she sleeps. She can teach twice as many students as a classroom tutor, charge less, and still keep more of the money. She does not need eleven years to become known; she needs eleven months of the right word spreading the way it always spreads in Singapore, through the neighbours.

This chapter is about the collision those two people represent. It is the same collision happening in care, in professional services, in the salons, in the laundries, across every corner of the map the earlier chapters drew.

Here is the whole argument, stated plainly at the start so you know where this is going:

> **AI makes the *doing* of work cheap, the thing that used to keep a one-person company out, and the thing that let a big incumbent coast. AI cannot make *being chosen* cheap, the trust, the relationship, the word in the customer's mind. So AI is a door for the one-person company that owns a word, and a falling wall for the incumbent that owns nothing but the work.**

That is the mechanism. This chapter is in four parts. First, why this is happening now. Second, the doors, how AI opens them for the small operator. Third, the walls, how AI closes them on the incumbents who never built a reason to be chosen. Fourth, what it all means for you, and how to test whether AI comes for your own business. Let us build to it.



# PART FIVE, THE AI MAP




## Chapter 1, Why now?

Before the doors and the walls, one question: why is this happening *now*, and not in 2022 or 2019?

The answer is not that AI got smarter, though it did. The answer is that **AI stopped being a tool you use and became a worker you hire.** In 2023, an AI helped you do a task, write a draft, answer a question, make a picture. By 2025, an AI could do a narrow, specific set of whole tasks itself, end to end. A "tool" needs you. A "worker" does not. That one change is what collapsed the cost of running parts of a small business from a team's worth of salaries to a subscription.

It is worth being precise about what that worker reliably does today, because the marketing runs ahead of the reality. An agent reliably handles the bounded, repeatable, text-and-data work: drafting a quote from a fixed skeleton, scheduling appointments, sending follow-up messages, sorting and summarising documents, doing the bookkeeping, running the first-pass research, and producing a first draft of a post or a reply. These are tasks with a clear input, a clear output, and a rule you can check. That is what the current generation of agents is genuinely good at.

What it does not yet do reliably is the unbounded, judgement-heavy work: deciding the strategy, holding the relationship, making the call when the information is incomplete, and being the named person a customer trusts. Those stay with the owner. The gap between the marketing and the operational reality is wide, and a small business that plans around the marketing, expecting an agent to run the whole business unattended, will be disappointed. The picture is a worker that does the execution reliably and the judgement not at all.

The numbers tell the same story, and they come from IMDA, the Infocomm Media Development Authority, the government agency that tracks Singapore's digital economy, in its own Singapore Digital Economy Report. In 2024, about **1 in 7** small businesses had adopted AI, up from **1 in 24** the year before, it tripled in a single year. Among the big companies, it was **2 in 3**. Here is what those two numbers mean together: the big firms are most of the way there, and the small firms are just starting. That gap, 48 points, is widening, not standing still, because the big firms are adopting AI four times faster than the small ones. And the digital economy that runs on all this reached **18.6 per cent of GDP** in 2025, up from 14.9 per cent six years earlier, the single fastest-growing share of the country's output.

But here is the part that matters most for a small business, and it is hiding inside the headline. Of the firms that do use AI, **84 per cent rely on off-the-shelf tools**, someone on the team opening a browser tab, typing a prompt, and copying the answer into a document. Only **44 per cent** use custom or proprietary AI wired into how they actually run. The average small business uses AI across just three functions, IT, customer service, and finance, while large firms use it across five. Read that honestly and it reframes the whole opportunity: AI has *barely started* in Singapore's small business. Most of the "adoption" is a chat window, not a worker. A small operator who wires AI into their actual operations, their scheduling, their quotes, their books, is not competing with the crowd that is already there; they are moving to a level the crowd has not reached yet.

And set that against the global benchmark, because it is a stunning one: on Microsoft's global measure of AI adoption, **Singapore ranks second in the world**, at 60.9 per cent of the population using AI, behind only the UAE, ahead of every Western economy. Put that together with the firm-level number and the gap becomes the whole story. The country is world-class at *using* AI as people. But its small businesses, at 14.5 per cent adoption, are four times behind their own large-firm peers. Singapore is a top-two AI *nation* and still a bottom-half AI *small-business* economy. That gap between the national muscle and the small-firm reality is the single most important fact in this chapter: it means the infrastructure, the talent, the government money are all in place, and the small business that moves now is riding a wave the country is actively building, not waiting for it.

That is the "why now." The tool is cheap, it is spreading, and the ones adopting it fastest are the ones you compete with. The rest of this chapter is what you do about it.

---

## Chapter 2, The doors (the opportunity)






How AI opens doors for the one-person company and the small business. There are three kinds of door, and each one is anchored to something the earlier chapters already mapped. These three doors are the author's reasoning, a framework for where to look, not a measured statistic, and they are flagged as analysis throughout.

### 1. The door beside the giant, the niche it left behind

Start with the map from the brand chapter. The concentrated industries, the banks, the airline, the telecom, the Big Four accounting firms, are owned by a few giants. DBS, OCBC and UOB handle the banking. The Big Four handle the audits. SIA and Singtel own their skies and wires. To most people, that reads as "closed." A one-person company cannot out-scale a bank.

But scale is not the same as coverage. A giant is big, and its bigness is also its blind spot. The Big Four audit every large listed company, but a client with a *narrow*, specialised need, a niche tax structure, a single-industry compliance question, a bespoke advisory for one type of foreign investor, is too small for the Big Four to staff and too specific for their generalist model to serve well. That is the slot they left. It is the specialist advisory the giant cannot profitably touch, not a maths tutor or a carer.

That slot used to be closed to a one-person firm, for one reason: execution. Writing the proposals, doing the research, drafting the documents, marketing yourself, that took a team. AI removes that barrier. A solo advisor with agents can field the full execution of a firm, and put it behind a single, sharp word, "the specialist in this niche." The giant's scale is irrelevant to the slot, because the specialist does not need scale; they need a word, and AI gives them the execution to go claim it.

**The giant owns the audit. The specialist owns the niche the giant left behind.** This is the first door, and it is the pattern for the concentrated industries: you do not fight the giant on its ground. You take the ground it cannot reach.

### 2. The door in the fragmented category, the word no one owns yet

Now the other side of the brand map: the fragmented industries, where no single name owns a meaningful share. Tuition is the clearest case, a billion dollars spent a year on it, and no dominant brand. Home care, the salons, the laundries, the same. These are the industries the map showed as a long tail of small operators with no champion.

Why is there no champion? Because the barrier to *scaling* a solo tutor, a salon, a laundry was always execution, the marketing, the scheduling, the materials, the follow-up, the admin. One person simply could not run the full operation and still do the actual work. So the industry stayed fragmented: thousands of small operators, each doing everything, none able to grow.

AI removes that barrier entirely. A single tutor with agents can now run the full operation of a tuition centre, the content, the booking, the parent communication, the progress tracking, while still teaching. A single person in a salon, in a laundry, in home care can do the same. The one thing that was ever scarce, the word a parent uses to recommend a specific centre, the word a neighbour uses to name a specific carer, is now the only thing that matters, and it is still free.

**The solo who owns "the single-subject maths tutor" has built something no AI can copy, because it was never built on execution.** This is the second door, and it is the pattern for the fragmented industries: the word is unclaimed, AI gives you the execution to go claim it, and whoever owns the word owns the category.

### 3. The door in the growing demand wave, the market AI makes reachable

The third door comes from the demographic chapter. Singapore's population is ageing, households are shrinking, and more families are willing to pay for care. These are not trends AI started, they were already moving. What AI does is make them *reachable* to a small operator.

Take care. Singapore does not have enough people to care for its growing elderly population, and the care that exists is expensive. The demographic chapter sized the *addressable paid care market*, the money a family will actually pay a provider, at roughly **S$0.28bn–0.85bn a year**. That number matters to you because it is the pool of money AI makes bigger: the more AI takes over the parts of care that do not need a human touch, the monitoring, the reminders, the scheduling, the paperwork, the cheaper and more scalable care becomes, and the more families can afford it. AI does not replace the carer; it makes the carer's business bigger.

The same logic runs through the shrinking household. A single person living alone has no one to help with the small tasks of daily life, and an AI assistant can fill that gap, which is exactly the kind of service a small operator can build on.

**The demand was already there, growing. AI is what makes it possible for a one-person company to serve it.** This is the third door: find the wave the demographic chapter measured, let AI remove the execution cost, and serve a market that was too expensive to reach before.

### The enabler, how one person can now do the work of a team

All three doors rest on the same enabler, and it deserves its own moment. In 2023, if you ran a small business, you had to hire a person to write your copy, a person to run your campaigns, a person to answer your customers, a person to manage your books. In 2025, one person with a fleet of software agents does the execution part of all of it.

This is not "AI helps you write faster." It is "an agent drafts your campaigns, answers the routine customer questions, and keeps your books." The first is a tool; the second is a worker. The second is a different economics of entry, it is the difference between needing a team and being a team. And it is the reason a one-person company can now field a level of execution that used to require three, five, ten salaries.

The boundary is the one this chapter has already drawn: the agent does the execution, not the judgement. It drafts the campaign; the owner decides the strategy and the word. It answers the routine questions; the owner holds the relationship and the trust. The opportunity for a small operator sits precisely in that gap, because most competitors are still at the browser-tab stage, using AI as a helper rather than wiring it into how they actually run. The operator who wires the execution into their operations is not competing with the crowd that is already there; they are moving to a level the crowd has not reached yet.

**The work that cannot be automated is the work worth owning.** Which brings us to the question you should ask of every door: is this slot one AI can get me into?

---

## Chapter 3, The walls (the risk)






Now turn the chapter around. The same force that opens doors for the positioned small operator closes them on the incumbent who owns nothing but the work. The risk is not spread evenly across the map, it falls hardest on one kind of player and barely touches two others. The three groups from the brand map tell you which. Like the doors, these three risk groups are the author's reasoning, a framework, not a measured statistic, and they are flagged as analysis throughout.

### The concentrated giants, walls that mostly hold

The banks, the airline, the telecom, the Big Four. These are protected by two things AI cannot remove: regulation and scale. A one-person company cannot get a banking licence. It cannot run an airline. It cannot audit a listed company the way a Big Four firm can, because the client's board and insurers demand a firm with that name on the cover.

So for these giants, the AI risk is low, but it is not zero, and it is worth naming precisely. The threat to them is that the *edges* of their territory, not that a solo operator replaces the bank, the specialist niches they left behind, the parts of their service that are pure execution, are now cheap for someone else to enter. The bank keeps the deposit and the mortgage; the specialist advisory beside it slips away to the solo advisor. The giant is not toppled, but it is nibbled at the edges, and the nibbling is new because it used to cost a team to do.

**The concentrated giant is safe in its core and slowly losing its edges.** The risk to it is real but bounded. This is not where AI destroys.

### The unpositioned fragmented incumbents, the wall falls here

This is where the risk is sharpest, and it is the group that should be reading this chapter most carefully.

In the fragmented industries, tuition, care, salons, laundry, the long tail of small operators, there are two kinds of incumbent. There is the one who owns a word: the tuition centre the neighbourhood knows by name, the salon everyone sends their daughters to, the carer the family trust has used for a decade. And there is the one who owns nothing but the work, the competent, hardworking operator who competes on being good at the job and having been around.

It is the second kind that AI targets. Because the work, the execution, was their entire moat. And AI has just made that exact thing cheap for everyone. The unpositioned tuition centre now competes against the solo tutor who can match its teaching, charge less, and run on agents. The unpositioned salon competes against the stylist who uses AI to book, market, and manage, leaving her free to do the work. The one thing the incumbent had, "we've always been here, we're competent", is now the thing that is cheapest to reproduce.

Here is the painful truth, stated plainly: **if the only thing you have is the work, then the day the work becomes free, you have nothing.** The unpositioned incumbent is losing the whole game, not just an edge, because it never built anything that AI cannot copy. The price war comes, the copycat comes, and the business that never built a relationship has nothing left when execution is free.

This is the wall, and it is falling on the competent, hardworking, unpositioned operator across every fragmented industry in the brand map. It is not falling on the operators who built a word.

### The industry-by-industry picture, where AI cuts cost, and where it cannot reach

Here is the whole risk across the industries the earlier chapters mapped, read in one table. Each industry is scored on two questions that decide whether AI is a threat or a shield to a small operator. This exposure framework is the author's reasoning, a way to read the map, not a measured statistic, and it is flagged as analysis throughout:

- **Can AI copy or do the work?** The more of the value is information, content, or a task an agent can complete end-to-end, the more AI is a threat, the price floor finds you.
- **Does the customer have to trust you, is the work licensed, or is it physical?** The more the buyer must trust you (health, legal, money, care), the more the work is regulated or licensed, or the more it is in-person and physical, the more AI is a shield, because AI cannot fake trust, get a licence, or do the physical thing.

The rule in one line: **the industries where AI cuts the cost of the work the most are the same ones where it opens the most new revenue, and they are the fragmented ones, where the data is thinnest.** That is where the opportunity is.

\begin{table}[!htbp]\centering
\caption{AI exposure by industry sub-category}\label{tab:ai-exposure}
{\small
\begin{tabular}{@{}p{11.2em}ccccc@{}}
\toprule
Sub-category & AI can copy & Trust needed & End-to-end & Cost cut & New revenue\\
\midrule
Delivery \& ghost kitchens & \rhigh & \rlow & \rhigh & \rhigh & \rmed\\
Quick-service / fast food & \rmed & \rlow & \rmed & \rmed & \rlow\\
Coffee \& bubble-tea chains & \rmed & \rlow & \rmed & \rmed & \rmed\\
Food courts \& kopitiams & \rmed & \rlow & \rmed & \rmed & \rlow\\
Full-service restaurant groups & \rmed & \rmed & \rmed & \rmed & \rmed\\
The hawker stalls & \rlow & \rhigh & \rlow & \rlow & \rmed\\
Tuition \& enrichment & \rhigh & \rmed & \rhigh & \rhigh & \rhigh\\
Senior care & \rmed & \rhigh & \rmed & \rhigh & \rhigh\\
Beauty \& personal care & \rmed & \rmed & \rmed & \rhigh & \rmed\\
Laundry & \rmed & \rlow & \rhigh & \rhigh & \rhigh\\
Pets & \rmed & \rmed & \rmed & \rmed & \rmed\\
Repair \& other services & \rmed & \rmed & \rmed & \rhigh & \rmed\\
Banking & \rhigh & \rhigh & \rmed & \rhigh & \rmed\\
Telecom & \rmed & \rlow & \rmed & \rmed & \rlow\\
Transport & \rmed & \rlow & \rmed & \rmed & \rlow\\
Professional services & \rhigh & \rhigh & \rmed & \rhigh & \rhigh\\
Supermarkets / grocery & \rmed & \rlow & \rmed & \rhigh & \rlow\\
E-commerce / marketplaces & \rhigh & \rlow & \rhigh & \rmed & \rmed\\
Real estate & \rhigh & \rmed & \rmed & \rhigh & \rmed\\
\bottomrule
\end{tabular}}
\ratingkey
\par\smallskip\noindent{\footnotesize Leaders in parentheses: Grab leads delivery; McDonald's $\sim$40\% of QSR; Starbucks $\sim$140 outlets, LiHo/KOI $\sim$40; Econ $\sim$27\% of private senior care; top-5 pet-food brands $\sim$55\%; Singtel $\sim$43--50\%; FairPrice $\sim$35--42\%; Shopee $\sim$52\%, Lazada $\sim$36\%.}
\end{table}

Read the two ends of the table and the pattern jumps out. **The industries where AI cuts the cost of the work the most AND opens the most new revenue, tuition, senior care, laundry, are the fragmented ones, where the value is mostly information and the work is mostly execution.** These are the wide-open doors: AI removes the execution barrier, so the solo who owns a word walks in. **The concentrated giants, banking, telecom, transport, energy, cut their costs with AI but open little new revenue to a small entrant**, because their protection is a licence and scale, which AI cannot cross. AI makes the giant more efficient; it does not open a door beside it. And in between sit the physically-anchored industries, the hawkers, the full-service restaurants, the salons, where the work is in-person and physical, so AI amplifies the operator who is already there rather than replacing them.

**The limit.** AI adoption by industry is not published in Singapore, so these ratings are the author's reasoning from the exposure framework, not measured statistics, and are flagged as analysis throughout. The industries where we are most confident are the concentrated ones, because Singapore publishes their shares. The industries where we are least confident, hawkers, laundry, repair, car servicing, are the fragmented ones, because no one publishes theirs. **The least-data industries are exactly the ones with the most opportunity**, which is why the ratings there are directional leads to verify, not measured facts.

### The positioned player, the wall that becomes a wind at your back

Now the third group, and the reason this chapter is not a doom report.

The incumbent who owns a word, the neighbourhood name, the trusted relationship, the reputation that took a decade to build, is *amplified* by AI, not threatened by it. Because AI takes away the busywork, the scheduling, the admin, the marketing, the follow-up, and leaves intact the one thing that made them the name in the first place: the trust. The salon that owns the neighbourhood can now serve more clients with less overhead. The carer the family trusts can spend more time on care and less on paperwork. The position is the whole game in the agent era, not a liability, and AI just made everything else cheaper.

The solo founder can match the positioned incumbent's price, speed, and output, but cannot match the ten years of referrals that made the incumbent the name the neighbourhood calls. **The AI-empowered newcomer sharpens, rather than erases, the value of an established relationship.**

And here is the flip that makes this chapter optimistic for the small operator: the incumbent who panics and cuts price is surrendering the one thing the newcomer cannot copy. The incumbent who leans into the relationship is defending the one thing the newcomer cannot buy. In a market where AI has made execution free, the positioned operator's relationship is the entire defensible position, not a nice-to-have.

---

## Chapter 4, So what? The test, and what it all means

Put the two halves together and the picture resolves. The doors opened for the small operator who owns a word; the walls closed on the incumbent who owns nothing but the work. They are the same mechanism. The door for one operator is the wall for another, in the same industry, at the same moment. The maths tutor who owns "single-subject maths" walks through the door. The tuition centre that owns nothing but "we've always been here" stands under the wall.

So the whole chapter reduces to one idea, and it is worth sitting with:

> **The scarce resource is no longer what you can do, AI made that cheap for everyone. It is why anyone should choose you, which, in Singapore, means who you are, who you know, and what word you own.**

That is why this chapter builds on the earlier ones. The brand map mapped the words, the concentrated giants and the fragmented slots, who owns what and where it is free. The demographic chapter measured the demand, the waves that are growing. This chapter adds the force that turns those maps into a strategy: AI removes the execution barrier, so the position becomes the whole game.

### Does AI come for you?, the test

Before you act on any of this, run a simple check on your own business. Ask these five questions:

| Ask this of your business | If the answer is "yes" |
|---|---|
| Is most of your value knowledge, copy, or data a customer could get anywhere? | AI will make your offer a commodity, you need a stronger word to survive |
| Could a customer verify your quality without meeting you? | You are transactional, the price floor will find you |
| Is your work unlicensed, with no compliance wall? | There is no licence stopping new entrants from copying you |
| Could the deliverable be done remotely or digitally? | An agent can be your substitute |
| Could an agent do the job end to end, unsupervised? | The agent era is already your competitor |

Here is the plain reading. The more "yes" answers, the more your slot depends on execution, and execution is exactly what AI makes free for everyone. To win a slot that scores this way, you must own a word no competitor can take, the way the maths tutor owns "single-subject maths." The more "no" answers, the more your slot depends on trust, regulation, and physical presence, and those are the things AI cannot make cheap. Those are the safest positions.

Then ask the sharper question: **is there a word a customer would use to recommend you?** Not "we do good work", a *specific* word. "The dementia-specialist," not "we do care." "The single-subject maths tutor," not "we do tuition." If you cannot name the word, you have no position, and AI will find you before you find it. If you can, AI cannot take it from you, because the referral that produces it is the one thing an agent cannot generate.

### Two final cautions

So this does not read as a fairy tale, hold two things.

**A position is a promise you re-earn, not a prize you win once.** The mind moves, new entrants every quarter, competitors repositioning, the market shifting. The owner who claimed "the dementia-specialist" in 2024 and stopped there has, by 2026, a word that is no longer theirs, someone has been saying it louder, and the neighbourhood has moved on. The owner who keeps re-earning the word each year still owns it.

**And one limit before you act on any of this:** the mechanism is the argument, but the maps it draws on are directional. AI adoption by industry is not published in Singapore, so where an industry is placed on the exposure framework is a reasoned read, not a measured figure. Use it to know *where to look*, and verify the specific slot against your own market before you commit.

The owner who reads this and walks away to "adopt AI" has missed the point. The owner who reads this and asks "what word do I own?" has found it. And the word, in Singapore, in a market that buys through the neighbours, is the one thing AI cannot take from you.

---

## Chapter 5, What a small business can actually do with AI now, the practical moves

Let us be plain about where things stand. There are about 371,000 businesses in Singapore. There are about 5.9 million residents. That is roughly one business for every sixteen people. In a market that small, everyone believes they are crowded. The truth is more interesting: in the things that matter most to a shop owner, the market is nearly empty, not crowded at all. This chapter is about the one area where that emptiness is most visible, and most useful to you. It is artificial intelligence, the technology that writes, answers, sorts, and predicts. We will call it AI (artificial intelligence). And we will talk about what a small business can hand to it this week, not in five years.

### The reality of adoption

Here is the number that should change how you think. In 2024, roughly one in seven small businesses in Singapore had adopted AI in some form. One in seven. That was already an improvement, because a short time earlier the figure was one in twenty-four. So the number tripled in a short period. Good. Now hold the other side of it. Six out of seven small businesses had still not adopted it at all. Most of your competitors, in other words, are not doing this yet.

And of that one in seven who did adopt, the large majority, about 84 per cent, are using an off-the-shelf tool. That usually means a chat window. They type a question, they get an answer, they copy it somewhere. That is not AI wired into the business. That is AI used as a faster search engine. It is useful, but it is shallow, and almost anyone can do it in an afternoon.

The contrast with big companies is stark. In 2024, about two in three large companies had adopted AI. Large here means the roughly 800 local companies in Singapore with revenue above a hundred million Singapore dollars a year. The gap between them and you is forty-eight points. That is a canyon, not a small gap. And it matters, because the large companies are not playing with chat windows. They are wiring AI into their quoting, their inventory, their customer service, their marketing. They are making it structural.

Now the government has noticed the gap and said it wants to lift ten thousand enterprises and a hundred thousand workers into AI. That is a real plan with real money behind it. But plans and grants move at the speed of government, and your business moves at the speed of a Tuesday. You do not need to wait for the programme. You can start now. The field being this empty is the whole point. When only one in seven of your competitors has touched the technology, and most of that one in seven is doing something shallow, the window is open. You do not need to be first to every trend. You just need to be early to the one that saves you the most time.

### What the books and the money need

Let us go through the practical functions, one at a time, in the plainest terms. We start with money, because money is where most small owners feel the pain first.

The books. If you are a salon, a tuition centre, a hawker stall with a single helper, or a one-person consultancy, your accounts probably sit somewhere between a spreadsheet and a shoebox. You reconcile at the end of the month. You dread it. You set aside a Sunday. Here is what AI can do now: it can read your receipts, match them to your bank statement, categorise the spending, and flag the odd transaction for you to look at. You still check the numbers. You still make the final call. But the drudgery, the sorting, the matching, the categorising, that goes to the machine. What you get back is an hour or two a week, and a cleaner set of records that an accountant or a tax agent can read without asking you eleven questions.

The quoting. Many small businesses live on jobs, not on products. A renovation, a catering run, a design project, a repair. Every job needs a quote, and every quote is basically the same skeleton: the parts, the labour, the margin, the tax, the payment terms. AI can hold that skeleton. You tell it the scope, it drafts the quote, you check the numbers and adjust the wording. For a business that sends out twenty quotes a week, this turns a task that used to eat a morning into a task that eats fifteen minutes. The quote is not the product. The quote is the paperwork around the product. Paperwork is exactly what AI is good at.

The scheduling. If you take bookings, a clinic, a salon, a tutoring centre, a repair van, your calendar is a source of constant friction. The no-shows, the double-booking, the "can you move me to Thursday" phone calls. AI can handle the rescheduling, the reminders, the waitlist, the confirmation messages. It does not get annoyed. It does not sigh. It sends the reminder and updates the slot and tells you when the afternoon is overbooked. What you get back is your front desk hours, spent instead on the people who actually walk in and the people who actually pay.

The follow-up. This is the quiet killer. Most small businesses win a customer and then forget them until they need money again. The follow-up, the "how was the service", the "your oil is due for a change", the "the new menu is out", the "your child's term is ending and here is the revision schedule", is how a one-time buyer becomes a repeat buyer. But nobody has time for it, so it never happens. AI can do it. It can send the follow-up after a job, check in at the right interval, and re-engage the customer who has gone quiet for ninety days. It is not you calling. But it is a message with your name on it, sent on your schedule, and it beats the alternative, which is silence.

The first draft. Every small owner is a small writer whether they like it or not. The social media post, the newsletter, the WhatsApp broadcast, the website blurb, the reply to the difficult customer, the email chasing the client who has not paid. None of it is your actual work, but all of it has to be written. AI drafts it. You take the draft, fix the tone, add the detail only you know, and send. The trick is to treat the draft as a starting point, not a finished thing. The machine gives you the blank page filled in. You give it the truth. Together you produce something faster than either of you could alone.

### The research and the reading

Here is where AI quietly does something most owners have never had at all: a research assistant.

The market research. When you are deciding whether to add a new service, open a second outlet, or change your hours, what do you actually base it on? Mostly your gut, and the gossip of your street. That is not nothing. A shop owner's gut is years of accumulated feel. But it can be sharpened. AI can read the market for you. It can tell you what similar businesses in your area are charging, what reviews say about them, what complaints repeat, what people are searching for, what is trending in your trade. It will not make the decision. You make the decision. But you make it with a map in your hands instead of a guess.

The analysis of your own numbers. You have data already, whether you know it or not. Your sales by day, your busy hours, your best sellers, your slow seasons, your repeat customers, your no-shows. AI can take that and tell you the pattern you are too close to see: that Tuesday is dead because of the market two streets over, that your regulars almost all come in the first week of the month, that one menu item is quietly carrying the margin while another costs you money every time you sell it. This is just the arithmetic of your own business, not fortune-telling, done properly, for once, and put in front of you in plain words.

The reading of the paperwork. Every small business drowns in documents it never actually reads. The tenancy agreement. The contract from the supplier. The insurance policy. The new regulation from the authority that affects your trade. AI can read them and tell you, in a paragraph, what matters: the clause that renews automatically, the fee you can dispute, the deadline you will miss if you do not act, the obligation you just signed up for. You still need a lawyer for the big ones. But for the everyday paperwork, a machine that actually reads the whole thing and summarises it is worth more than it costs.

None of this is magic. All of it is real and available now, on a laptop, for less than the cost of a staff member or an expensive consultant. The question is not whether the technology works. It works. The question is what you choose to point it at, and what you do with the time you get back.

### The boundary

Now we must be equally plain about what AI cannot do. Because a chapter that only tells you what the machine can do is a chapter that has lied to you, and you will discover the lie the first time you rely on it for the wrong thing.

AI cannot be a named, trusted person. When a customer walks into your shop, they are not buying from a machine. They are buying from you, or from the person you trained, or from the reputation that follows your name. That trust is not transferable to software. You cannot outsource the handshake, the eye contact, the "I remember your mother's birthday", the "I held this one for you". Those things are not tasks. They are a relationship, and a relationship is not a function you can hand to a chat window.

AI cannot make a neighbour vouch for you. This is the most Singaporean truth in this entire book, so let us say it slowly. Roughly 85 per cent of buyers in Singapore find the solution they end up buying through a personal referral. A friend, a relative, a colleague, a neighbour. Someone they trust pointed at someone else they can trust. That chain of vouching is the real sales channel in this country, and it is built on people, not on software. Your best customer did not find you through a clever ad. Your best customer found you because someone they believed in said your name. AI cannot stand in for that. It cannot be the friend who says your name at the right dinner.

AI cannot hold the accumulated trust of a community. Trust in Singapore is slow to build and slow to spend. It lives in the kopitiam, in the school gate, in the temple, in the group chat, in the years of being there when the customer needed you. A machine does not accumulate that. A machine does not have a history with your neighbourhood. It has no memory of the family that has bought from you for a decade. It cannot feel, and it cannot be felt. What it can do is not replace that trust. What it can do is stop wasting the time that you could spend building it.

So draw the line clearly. Give the machine the paperwork, the drafting, the scheduling, the sorting, the reading, the arithmetic. Keep the person for the relationship. This is a practical argument, not a moral one. The machine is good at the stuff nobody remembers and everyone needs. You are good at the stuff everybody remembers and nobody can copy. Use each for what it is good at, and do not confuse the two.

### The trap

There is one more thing to warn you about, because it is the way most small businesses will misuse this technology, and they will do it without noticing.

The trap is using AI to become a cheaper, more generic version of everyone else. This is the easy path, and it is the wrong path. Here is how it happens. The machine can write, so every business on your street starts posting the same kind of polished, generic social media content. The machine can draft, so every business starts sending the same kind of smooth, forgettable follow-up. The machine can do market research, so every business discovers the same "insight" and copies the same playbook. The result is not differentiation. The result is a street full of businesses that all look, sound, and act alike, except that the ones who lean on the machine hardest have made themselves interchangeable.

That is the exact opposite of what you need. In a market of 371,000 businesses, where one in sixteen people is running a business, and where about 213 new businesses open every day, being generic is a death sentence. If you are interchangeable with the shop next door, the customer has no reason to pick you, and the customer has no reason to remember you. They will pick whoever is closest, cheapest, or first on the list. None of those are positions you want to defend.

Here is the better way to think about it. Use AI to execute better behind a clear word. Every successful small business in Singapore has a word attached to it, even if the owner has never said it out loud. It is the thing the business is known for. It might be "the curry that never changes", or "the tutor who actually explains", or "the salon that listens", or "the clinic that is never rushed", or "the contractor who shows up when he says he will". That word is your reputation. It is the accumulated trust we just talked about. It is what the neighbour vouches for.

Now run the machine underneath that word. Use AI to write the follow-up that reminds people why your word is true. Use AI to schedule so that the word is never broken by a missed appointment. Use AI to research so that you know, better than the generic shop, what your customers actually want. Use AI to do the books so that you have the margin and the cash to keep the word true when times are thin. The machine should be in service of the word, not in competition with it. When the machine makes you faster, you spend the saved time on the word and on the relationship. That is the whole strategy, and it is the only strategy in this chapter that matters.

The difference between the two uses is the difference between the trap and the opportunity. One makes you a cheaper copy. The other makes you a sharper original. They cost the same. They take the same afternoon to set up. They are separated only by whether you know what your word is before you start. So before you automate a single thing, ask yourself the plain question: what are we actually known for? If you cannot answer it, go and find the answer first. The machine will only amplify what is there. If what is there is generic, the machine will make you efficiently generic. Nobody wins that race.

### The numbers on value

Let us put some numbers to why this matters, because it is easy to think of time savings as abstract, and they are not abstract at all.

The value of a worker in Singapore is not the same across every trade. In 2025, the official measure of value per worker, the value each worker helps produce in a year, looked like this. Wholesale, about 494 thousand Singapore dollars a year. Finance, about 436 thousand. Manufacturing, about 282 thousand. Education, about 150 thousand. Retail, about 58 thousand. Food and beverage, about 32 thousand. The whole economy, averaged out, about 194 thousand.

Read that list again. Retail and food and beverage, the trades where the bulk of Singapore's small businesses live, the hawkers, the salons, the small shops, sit at the bottom. A worker in wholesale produces fifteen times the value of a worker in food and beverage. That is because the trade itself, by its nature, squeezes most of the value out through the cost of a human standing there and doing the thing, not because the food and beverage worker is lazy. There is no factory behind it. There is no leverage. There is a person, a counter, and a day that has only so many hours.

This is exactly where AI becomes the most valuable, not the least. The trades that produce the most value per worker have already got systems, software, and structure doing the repetitive work underneath. The trades that produce the least do not. Everything is done by hand, by the owner, in the owner's hours. When you hand the repetitive work to a machine, you are not replacing the thing that makes your money, the hand, the skill, the face, the word. You are removing the part of your day that produces nothing and that has always eaten the hours you could have spent on the thing that does.

Think about the median. The median resident household in Singapore earns about 12,446 Singapore dollars a month. Just over half of households, 51.6 per cent, earn at least 12,000 a month. About 13.4 per cent earn at least 30,000 a month. What that tells you is that your customer base is the broad middle of the country, not a small elite, and the broad middle has money to spend but not money to waste. That customer is value-sensitive, not price-blind. They will pay for the word done well. They will not pay for the generic copy of it. So the businesses that win in this market are the ones who keep the word sharp and the overhead low enough to stay in business while they do. AI is how a small business keeps the overhead down without hollowing out the word.

### What your market looks like

Let us be even more specific about who you are selling to, because it shapes what you should automate and what you should keep for yourself.

The median resident in Singapore is 43 years old. That is a middle-aged market, not a teenager's market and not a retiree's market with established habits, established loyalties, and a strong preference for doing things the way they have always done them. Roughly one in five households in Singapore has a domestic helper. Those households have two working adults and a helper holding the household together, which means they are time-poor in a very particular way: they have money, and they have no time to waste on a bad experience. That is the customer who will pay for your word, and who will also punish you brutally if the word is broken, because they did not have the slack in the day to absorb your mistake.

Notice also that roughly two-thirds of small businesses in Singapore prefer to buy offline. They like the person, the handshake, the physical thing, the established way. You are not a business that runs on a cold platform. You are a business that runs on relationships and referrals. That is a strength, and it is also a warning. It means the machine can never be your salesperson. It can be your back office, your research arm, your drafting assistant, your bookkeeper, your scheduler. It cannot be your face. The customers in your market buy from faces they trust, and they trust faces their neighbours vouched for. Keep the face human.

And here is the hard statistic that should sharpen every hour you save. Fewer than one in four food and beverage businesses in Singapore survives five years. A quarter survive. Three quarters do not. That is not a market for the complacent. That is a market where the difference between surviving and closing is often the owner's own hours, spent on the wrong thing. The owner who spends Sunday reconciling the books has less energy for the word on Monday. The owner who automates the books has that Sunday back. Over a year, that is real. Over five years, that is often the difference between the business that is still there and the one that is not.

### The practical steps

So here is what a small owner actually does. Not in theory. In the next few weeks. Five steps, in order, each one small enough that you will not talk yourself out of it.

Step one: pick the one function that costs you the most time. Not the most interesting. Not the most impressive. The one that eats the most of your week. For most owners it is one of these: the books, the quoting, the scheduling, the follow-up, or the writing of the endless small messages. Look at your last month. Where did the hours go? Whatever answer you get, that is your starting point. Do not try to do everything at once. Trying to automate your whole business in a weekend is how people give up by Tuesday.

Step two: hand that one function to AI. This is a technical step but it should not be a scary one. You do not need to learn to program. You need an off-the-shelf tool and an afternoon. If it is the books, there are tools built for exactly this that plug into your bank and read your receipts. If it is the scheduling, there are tools that manage bookings and send reminders. If it is the follow-up, there are tools that hold your customer list and send the messages on your schedule. If it is the drafting, there is the chat window, used properly: you give it your tone and your facts, and you edit the result before it goes out. The 84 per cent of adopters who use off-the-shelf tools are not wrong to use them. They are wrong to stop there and call it done. You will go further than that, but you have to start exactly where they started.

Step three: reinvest the time into the word and the relationship. This is the step everyone skips, and it is the step that makes the whole thing worth doing. The point of the machine is not to give you more free time to stare at your phone. The point is to give you back the hours you were losing to the repetitive work, so you can spend them on the thing the machine cannot do: the word and the relationship. Walk the floor. Call a customer you have not spoken to in months. Fix the thing you keep meaning to fix. Talk to the regular. Be the named, trusted person that the machine cannot be. If you automate the books and then fill the freed Sunday with more generic posting, you have missed the entire point of this chapter.

Step four: check the output for a while, then trust it. The first week, you will not trust the machine, and you should not. Check everything it does. Verify the categorised transactions. Read the drafted messages before they go out. Look at the scheduled reminders. Over a few weeks, you will learn what it gets right and what it needs you for. Then you relax a little, and it becomes routine. Most owners find that the machine is more reliable than they feared and that the checking takes far less time than the doing used to.

Step five: once the first function is running, add a second. Do not add a second until the first is genuinely saving you time. Then pick the next biggest time sink and do the same thing again. Books, then scheduling. Scheduling, then follow-up. Follow-up, then research. Each one compounds. The first saves you an hour. The second saves you an hour and makes the first more useful, because the data is cleaner. By the time you have four or five functions automated, you are not just faster. You are structurally different from the shop next door that is still doing it all by hand.

### The reinvestment is the whole game

Let us return to where we started, because the closing point is the same as the opening one, and it is worth saying plainly.

The field is not crowded. One in seven small businesses has adopted AI. Six in seven have not. Of the one in seven who have, 84 per cent are using a chat window and nothing more. The large companies are two in three, and the gap is forty-eight points. The government wants to close it and will spend money trying. But you do not need to wait for the programme, and you do not need to match the large companies. You only need to be ahead of your own street. And being ahead of your own street, right now, takes an afternoon and a decision.

The boundary has not moved. The machine cannot be the named, trusted person. It cannot make the neighbour vouch for you. It cannot hold the accumulated trust of your community. You can, and you already do, and that is your moat. What the machine can do is take the drudgery off your hands so that you have the hours to deepen that moat instead of just defending it. That is the entire argument of this chapter, in one sentence: let the machine do the work that nobody remembers, so that you can do the work that everybody remembers.

The trap is to use the machine to become a cheaper generic version of everyone else. The opportunity is to use it to execute better behind your clear word. The word is the thing you are known for. The word is what the neighbour vouches for. The word is why the customer who was referred to you stays with you. Point the machine underneath that word and let it run there. It will make you faster, sharper, and better informed. It will not make you someone else, and it should not try.

So the practical moves are these. Take the one function that costs you the most time. Hand it to the machine. Take the hours you get back and spend them on the word and the relationship. Then do it again. That is a Tuesday discipline, not a grand strategy. But it is a Tuesday discipline that compounds, and compounding is how a small business in a market of 371,000 businesses, with a neighbour vouching for it, becomes the one that is still there when the street has moved on.

You do not need to be first. You need to be early to the one thing that saves you the most time, and then spend that time on the only thing the machine cannot do. That is what a small business can actually do with AI now. It is real, it is available, and the field, for now, is nearly empty.

---

## Sources & confidence
# PART SIX, THE DECISION LINE

## Chapter 1, What the map gave you

Step back and see the five chapters as one picture, because they were never five separate stories. Each handed you a lens and a bridge:

| Chapter | What it told you | The bridge it left you with |
|---|---|---|
| **The Landscape** | Singapore is three engines, a global engine (capital, exports, R&D), a government engine (the state's public service, its S$97bn spend), and a domestic layer (employment, competition) fed by both engines' payroll. | You're in a dense, capped domestic layer. Your escape from the price war is a position. |
| **The Demographics** | Four structural waves, ageing, fertility collapse, shrinking household, remaking of care, are shifting who buys and what they'll pay. | Your position is a word that matches the wave you're riding. |
| **The Industry Map** | Every industry, its size, its trend, its data quality. Some are structurally brutal, some friendly. | Your position is the open slot in the industry you can actually enter. |
| **The Brand Map** | Every incumbent brand owns one word and leaves the others open. The concentrated giants own scale, not words; the fragmented categories have the words, unowned. | Your position is the specific word no incumbent owns, the slot the map shows is free. |
| **The AI Map** | AI makes the doing of work cheap but cannot make being chosen cheap. The doors it opens and the walls it drops are mapped sub-category by sub-category. | Your position is the one thing AI can't copy, a maintained word in a customer's mind. |

Five lenses. And they converge on a single conclusion:

> **In Singapore's domestic layer, the only durable way to win is to own a position, a word in the customer's mind, and the relationship behind it, and to keep it current as the market moves.**

That is the terrain. Now the hard part. Knowing the terrain is not the same as knowing where you stand in it.

---

## Chapter 2, Where the map stops, and what a real position analysis is

There is a real line the map does not cross. Understanding it is the book telling you the truth about what a map can and cannot do, not a failure of the book.

**The map is structural and aggregate. A position is individual and relative.**

The map can tell you that food and beverage is a brutal, price-war industry. That is true of the industry as a whole. The map can tell you that care is a growing, amplified market. That is true of the market as a whole.

But the map cannot tell you *your* competitive set, the specific five or twenty businesses actually fighting for *your* customer. It cannot tell you *your* customers' mental map, what word they already associate with your category and your rivals. It cannot tell you *your* viable differentiators, which of the many ways to stand out is winnable for *you*, at *your* price, in *your* slot. It cannot tell you *your* open slot, the word nobody in *your* specific market owns yet.

These are not derivable from aggregate data. They are true only of *your* market, *your* rivals, *your* customers. No map, this one or anyone's, can tell a specific business its specific position without running the analysis on that business, because the position you hold is defined only by the other people in your field and the minds of the people who buy from you.

### What a real position analysis actually is

Because the boundary is real, the next step has a shape, and it is a shape this book does not teach. Finding your position is a defined method, not a black box and not a mystery, and it starts exactly where the map stops, with your live market, your actual rivals, and the minds of the people who buy from you.

This is the method, not the map. Every chapter in this series has been careful not to overreach into it, because doing it right requires your live market, not aggregate statistics. That is the line between "understand your market," which this book has done, and "find your position," which the second book in this series teaches in full. This book gives you the terrain; the method is the standing on it.

---

## Chapter 3, The one-page self-assessment



```{=latex}
\input{print/worksheet-one-page}
```



The map is only useful if it tells you where you stand. This chapter gives you a one-page self-assessment that turns the map into five answers about your own business. Fill it in, and you will know which engine you sit in, which industry you are in and how good its data is, which wave your demand rides, how dense and concentrated your category is, and which words look open. That is the whole map, made personal.

### The five questions

**Question one, which engine are you in?** Are you in the global engine (you sell to the world), the government engine (you are funded by the state), or the domestic layer (you serve people where they live)? Most small businesses are in the domestic layer. If you are, the map has told you the ground: dense, capped, and won by position, not price.

**Question two, what is your industry, its size, its trend, and its data quality?** Name your SSIC section. Look it up in the industry table. What is its value added, its share of GDP, its growth rate, and is the data on it good enough to act on? The answer tells you whether you are in a growing, friendly industry or a brutal, price-war one, and whether you can trust the numbers you are reading.

**Question three, which demographic wave does your demand ride?** Is your customer the ageing senior, the shrinking household, the sandwich generation, the childless couple, the foreign worker? The wave tells you which words are becoming scarce, dignity and independence in an ageing country, convenience in a shrinking household, time for the sandwich generation. If your demand rides a growing wave, the current is at your back.

**Question four, how dense is your category, and is it concentrated or fragmented?** How many businesses compete for your customer? Is the money owned by a few giants (concentrated, a wall) or by no one (fragmented, a door)? The concentrated industries are walls owned by scale; the fragmented ones are doors where a word can be taken. This tells you whether you are fighting a wall or walking through a door.

**Question five, which two or three words look open in your market?** Based on the brand map, what words do the incumbents in your category already own, and which are sitting free? The open word is the slot you could take, the dementia-specialist, the single-subject maths tutor, the salon that owns a neighbourhood. Name two or three that look genuinely open.

### The one-page sheet

| Question | Your answer | What the map says about it |
|---|---|---|
| 1. Which engine? | | Global / government / domestic |
| 2. Industry, size, trend, data quality | | Growing or brutal? Data trustworthy? |
| 3. Which wave? | | Ageing / shrinking household / sandwich / childless / foreign worker |
| 4. Dense? Concentrated or fragmented? | | Wall (concentrated) or door (fragmented)? |
| 5. Two or three open words | | The slot you could take |

Fill that page in, and you have done the first real act of positioning: you have located yourself on the map. You know the ground you stand on, the current you are riding, and the words that are open. That is not a position yet, a position is a word you claim and hold in a specific market, but it is the foundation every position is built on.

### What the map has already given you

Before you go further, it is worth naming what the map hands you to act on today, with the map alone. It is not only background.

**Know which engine you are in.** If you are in the domestic layer, the map has told you not to compete on price, because the structure makes it a death sentence. Compete on position.

**Choose the right wave.** If your market rides the ageing or care wave, you are in the growing, friendlier zone. If you are in a shrinking or price-war zone, the map has told you where the headwind is.

**Find the unowned word.** The brand map's key insight: the concentrated giants own scale, not words, and the fragmented categories have the words, unowned. The slot is the specific word no incumbent owns.

**Face toward the trust axis.** The AI map's key insight: the thing that cannot be made cheap, relationship, trust, accountability, is where a small Singapore business can beat both a cheaper copycat and an AI agent. That axis is your friend.

These are not abstract. They are immediate postures the map hands you, before any individual-position analysis.

### A final word on what this book is

This book deliberately stopped at the map. It did not give you *your* position, that requires your live market. It did not teach the full method, that is the second book in this series. It did not claim that knowing the terrain wins the war. It is the foundation, not the victory.

What it did give you is the terrain, confidence-labeled and evidence-backed, so that you can locate yourself on it, and know which words are open. It does not pretend to hand you a position that only your own market can reveal.

The terrain is mapped. The rest is the standing on it.

---

## Reading the whole map at once, the six-layer view



![The six layers of the map.](print/figures/fig-six-layers.pdf)



A map is only useful if you can hold the whole of it in your head at once. This chapter is the six-layer view, all six maps of Singapore brought together so you can see how they fit, and what the whole picture tells a small business that is trying to decide where to stand.

### Layer one, the three engines

The first map showed that Singapore is not one economy but three. There is the global engine, the capital, the exports, the research that makes the headlines. There is the government engine, the state's S$97 billion annual spend. And there is the domestic layer, where most Singaporeans live and work, fed by the payroll of the other two. The small business lives in the third. It is dense, capped, and competitive, and its only durable escape from the price war is a position.

### Layer two, the four waves

The second map showed the people. The median resident is forty-three. The senior share is rising, the fertility is among the world's lowest, the household is shrinking, and care is being remade. These are not trends that will reverse; they are facts already in motion. The wave tells you which words are becoming scarce, dignity and independence in an ageing country, convenience in a shrinking household, time for the sandwich generation.

### Layer three, the industries

The third map showed where the demand lands. Some industries are friendly to a small operator, health and social services, the niche professional tiers. Some are brutal, retail, food, admin, hostile to anyone who competes on price, and therefore open to anyone who does not. The map tells you which industries are worth looking for a slot in, and where the incumbents are weak enough that your word will take share.

### Layer four, the walls and doors

The fourth map named who owns the money. The concentrated industries are walls, owned by the state or by global giants, by scale, not by words. The fragmented industries are doors, no one owns the money, and a word can be taken. The giants own the channel and the scale; they do not own the word, the relationship, the niche, the local trust. Those are the cracks in the wall, and the ground of the door.

### Layer five, the AI wave

The fifth map added the newest force. AI makes the doing of work cheap for everyone, but it cannot make being chosen cheap. In a market that buys on trust and referral, the word in the customer's mind is the one thing AI cannot copy. AI removes the execution barrier that kept the fragmented industries fragmented, so a one-person operator can now run a full business, and the position becomes the whole game.

### Layer six, the decision line

The sixth map drew the line. The map is structural and aggregate; a position is individual and relative. The map can tell you the industry is brutal, but it cannot tell you your specific competitive set, your customers' mental map, your open slot. That requires running the analysis on your specific market. The map is the terrain; the method is the standing on it.

### What the whole picture says

Hold all six layers together and one clear picture emerges. Singapore's small business market is dense, capped, and competitive, that is the hard ground. The people are ageing, shrinking, and running out of time, that is the demand. The industries are split between friendly and brutal, that is the choice. The walls are owned by scale and the doors by no one, that is the opportunity. AI makes the work cheap, that is the tool. And the only durable way to win in all of it is to own a position, a word in the customer's mind, kept current as the market moves.

That is the whole map. It is one ground, seen from six directions, and they all point the same way, not a list of separate facts. The small business that can hold this whole picture, and then find its specific word within it, has the one thing the market demands: the understanding of the ground before the standing on it.

## From the map to the method, the hand-off

This book has given you the map. The second book in this series, *How a Small Business Gets Chosen*, takes it up. It is worth drawing the hand-off clearly, so you know what this book gives you and what the next one does with it.

**What this book gave you.** This book drew the terrain: where the money is, who the people are, which industries are friendly, which names own the walls, how AI is changing the ground, and where the map stops. It is the why and the where. It told you the ground you are standing on, with the data and the caveats.

**What the next book does.** The second book is the method. It takes the position concept, the word in the customer's mind, and shows how a small business actually finds and holds one. It explains the theory of positioning and where it came from, credits Ries, Trout and Gu Junhui, lays out the postures of the market battle, walks the stories of the Singapore brands that went from small to big, and shows the five-step process of finding your own position. It is the how.

**The hand-off.** The map does not hand you your position. Your position depends on your specific market, your specific competitors, your specific customers, the word genuinely open for you. That is the work of the method, run on your market. This book gives you the terrain so you are not standing in the dark; the second book gives you the method so you know how to stand. Together they are the map and the move, the ground and the position on it.

---

## References

\printbibliography[title={References}]

### Sources note

The market figures in this book (value per worker by sector, GDP, FDI, CPF, workforce, AI adoption, F&B survival, referral-driven buying) draw on published statistics from SingStat, the Ministry of Manpower (MOM), and the Ministry of Trade and Industry (MTI). Specific releases are confidence-labeled in the text and in each chapter's "Sources & confidence" section.

---

## Glossary

**ACRA**, the Accounting and Corporate Regulatory Authority, the agency that registers and regulates companies in Singapore.

**B2B**, business-to-business, sales from one business to another rather than to a consumer.

**COE**, Certificate of Entitlement, the quota licence a person must buy to own a car in Singapore.

**CPF**, the Central Provident Fund, Singapore's compulsory national savings scheme for retirement, housing, and healthcare.

**EDB**, the Economic Development Board, the agency that attracts foreign investment to Singapore.

**F&B**, food and beverage, the restaurants, hawkers, cafes, and bars.

**FMCG**, fast-moving consumer goods, the everyday products like food, drink, and toiletries sold quickly and in volume.

**GDP**, gross domestic product, the total value of everything a country produces in a year.

**GP**, general practitioner, a family doctor.

**HDB**, the Housing and Development Board, the public-housing authority; also the flats it builds, where most Singaporeans live.

**IMDA**, the Infocomm Media Development Authority, the agency that regulates media and communications.

**MAS**, the Monetary Authority of Singapore, the central bank.

**MOM**, the Ministry of Manpower, the ministry that manages the workforce and foreign workers.

**MOH**, the Ministry of Health.

**MTI**, the Ministry of Trade and Industry.

**OPC**, one-person company, a company with a single shareholder.

**QSR**, quick-service restaurant, a fast-food outlet.

**REIT**, real estate investment trust, a fund that owns property and pays out its rental income.

**SingStat**, the Singapore Department of Statistics, the national statistics agency.

**SME**, small and medium enterprise.

**SSIC**, the Singapore Standard Industrial Classification, the official system for classifying industries.

**TCM**, Traditional Chinese Medicine.

---

## About the author

Sean Foo has spent his working life inside the problem these books are about. He started his career in 2008 in Well Engineering with the Singapore wells consultancy Stuart Wright, where he rose from graduate to senior management, helped build the complex-wells service that won the company the position of complex-wells expert in offshore Australia, and watched the company scale from a handful of employees to more than forty across Singapore and Australia.

Between 2021 and 2023 he was the Chief Business Officer of AlgoMerchant, the Singapore fintech the Business Times called Asia's first robot trader for retail investors, where he learned from the inside what happens when a company gets its word right and what happens when it blurs.

Since then he has run positioning analyses for Singapore businesses across very different markets, a compostable-packaging distributor, a menopause supplement, a bubble-tea brand, a salad market study, and a pet directory business. He studied positioning under Gu Junhui in Singapore and China. This book is the method he has used, written down.

*Next in this series: How a Small Business Gets Chosen, Book 2, the method.*
