# books-print — task package

Two book interiors, built from markdown through pandoc and xelatex. Everything
needed to build and check them is in this directory.

## Run it

    make build      # both books -> out/book1-FINAL.pdf, out/book2-FINAL.pdf
    make verify     # acceptance check; exit 0 = shippable
    make all        # build then verify
    make book1      # one book only
    make clean      # remove out/ and the LaTeX aux files

A build takes a few minutes per book. `make build` fails loudly: it deletes the
previous PDF first, and it exits non-zero if xelatex reports an error. This
matters — see "How this went wrong before".

## Definition of done

`make verify` exits 0. That is the whole contract. Two exceptions are expected
and are recorded in `reference/expected-verify.txt`:

- the placeholder ISBN, which fails on purpose until Sean assigns real ones
- Book 1's empty chapter opening at the "Sources & confidence" heading, which
  is a content decision (see `DECISIONS.md`), not a build fault

Anything else that fails is yours to fix. Anything that passes and shouldn't
means the check is wrong — say so rather than working around it.

## Reporting

A claim about the PDFs is only true if `verify_final.py` says so, run against
the exact file being handed over. Paste its raw output, SHA-256 included, into
your report. Do not summarise it. Do not describe a fix as done without the
matching line in that output. Do not report on a build that is not the file
being delivered.

If a check cannot be made to pass, leave it failing and name it. A failing
check that is named is fine. A passing claim the verifier does not support is
not.

## How this went wrong before

The previous delivery reported an index of 244 entries. The PDF had 41, and the
second book had none. Three separate faults produced that, and the third is the
one to keep in mind:

1. `makeindex` was never called. `imakeidx` only calls it under
   `-shell-escape`, so `\printindex` read whatever stale `.ind` was in `/tmp`.
2. The index tagger wrote `\index` into chapter titles, which is fatal in the
   `\label` hook. Book 1's first pass died at page 94.
3. **When a pass dies, xelatex writes no PDF, and the old build script kept
   whatever PDF was already there and printed "Built".** A failed build handed
   over an older file, and the report described the fix rather than the file.

`run_build.sh` now removes the target before building and checks the log for
`! ` errors. Do not weaken that.

## Layout

    manuscripts/   book1.md, book2.md
    figures/       19 figure PDFs
    build/         the pipeline; every fix carries a comment naming what it fixes
    reference/     known-good SHA-256s and expected verify output
    out/           build products (created by make)

`build/build_latex_MAC.py` is the one to run if you are on Sean's Mac: it keeps
the Charter font line. `build/build_latex.py` here substitutes TeX Gyre Pagella
because Charter's bold crashes the PDF driver in the Linux container. **The two
produce different page counts, and therefore different spine widths.** Never
report a page count or spine width from a build that is not the one going to
the printer.
