import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mp
from matplotlib import rcParams
rcParams['font.family']='DejaVu Serif'

MM=1/25.4
TRIM_W, TRIM_H = 140*MM, 216*MM     # 5.5 x 8.5 in
BLEED = 3*MM
PAPER = 0.0032                       # inches per leaf, 80gsm cream — CONFIRM WITH PRINTER

GREEN='#1b6b57'; CREAM='#f5f2ec'; INK='#141414'; RUST='#b5651d'

def cover(name, title, subtitle, booknum, pages, blurb, accent, series_pos, strap):
    spine = pages/2*PAPER
    W = TRIM_W*2 + spine + BLEED*2
    H = TRIM_H + BLEED*2
    fig = plt.figure(figsize=(W,H), dpi=300)
    ax = fig.add_axes([0,0,1,1]); ax.set_xlim(0,W); ax.set_ylim(0,H); ax.axis('off')
    ax.add_patch(mp.Rectangle((0,0),W,H,facecolor=CREAM,edgecolor='none'))

    x_back, x_spine = BLEED, BLEED+TRIM_W
    x_front = x_spine + spine

    # --- front ---
    fx, fw = x_front, TRIM_W
    ax.add_patch(mp.Rectangle((fx,BLEED+TRIM_H*0.60),fw,TRIM_H*0.40,facecolor=accent,edgecolor='none'))
    ax.text(fx+fw/2, BLEED+TRIM_H*0.885, 'THE MAP AND THE METHOD',
            ha='center', fontsize=7.5, color='white', alpha=0.85, family='DejaVu Sans')
    ax.text(fx+fw/2, BLEED+TRIM_H*0.845, f'BOOK {booknum}',
            ha='center', fontsize=7.5, color='white', alpha=0.85, family='DejaVu Sans')
    n = len(title)
    fs = 21 if n <= 2 else 17
    step = 0.062 if n <= 2 else 0.050
    top = 0.760 if n <= 2 else 0.775
    for i, line in enumerate(title):
        ax.text(fx+fw/2, BLEED+TRIM_H*(top-i*step), line,
                ha='center', fontsize=fs, color='white', fontweight='bold')
    rule_y = top - (n-1)*step - 0.052
    ax.plot([fx+fw*0.40,fx+fw*0.60],[BLEED+TRIM_H*rule_y]*2,color='white',lw=2.2)
    for i,line in enumerate(subtitle):
        ax.text(fx+fw/2, BLEED+TRIM_H*(0.520-i*0.036), line,
                ha='center', fontsize=9.5, color=INK, style='italic')
    # anchor the lower half so it does not read as empty
    ax.plot([fx+fw*0.30,fx+fw*0.70],[BLEED+TRIM_H*0.255]*2,color=accent,lw=0.8)
    ax.text(fx+fw/2, BLEED+TRIM_H*0.205, strap,
            ha='center', fontsize=8.2, color=accent, family='DejaVu Sans')
    ax.text(fx+fw/2, BLEED+TRIM_H*0.085, 'SEAN FOO',
            ha='center', fontsize=13, color=INK, family='DejaVu Sans')

    # --- spine ---
    if spine > 8*MM:
        ax.add_patch(mp.Rectangle((x_spine,BLEED),spine,TRIM_H,facecolor=accent,edgecolor='none'))
        ax.text(x_spine+spine/2, BLEED+TRIM_H*0.62, ' '.join(title),
                rotation=270, ha='center', va='center', fontsize=10,
                color='white', fontweight='bold')
        ax.text(x_spine+spine/2, BLEED+TRIM_H*0.13, 'SEAN FOO',
                rotation=270, ha='center', va='center', fontsize=8, color='white')

    # --- back ---
    bx = x_back
    ax.text(bx+TRIM_W*0.10, BLEED+TRIM_H*0.90, series_pos, fontsize=8.5,
            color=accent, family='DejaVu Sans', fontweight='bold')
    y = BLEED+TRIM_H*0.845
    for para in blurb:
        for line in para:
            ax.text(bx+TRIM_W*0.10, y, line, fontsize=8.2, color=INK, va='top')
            y -= TRIM_H*0.0255
        y -= TRIM_H*0.016
    # ISBN block
    ax.add_patch(mp.Rectangle((bx+TRIM_W*0.58,BLEED+TRIM_H*0.045),
                              TRIM_W*0.32,TRIM_H*0.075,facecolor='white',edgecolor='#cccccc',lw=0.5))
    ax.text(bx+TRIM_W*0.74, BLEED+TRIM_H*0.075, 'ISBN barcode',
            ha='center', fontsize=6, color='#999999')
    ax.text(bx+TRIM_W*0.10, BLEED+TRIM_H*0.065, 'ObserveCo · Singapore',
            fontsize=7.5, color=INK, family='DejaVu Sans')

    # trim guides on a separate proof copy
    fig.savefig(f'{name}.pdf'); fig.savefig(f'{name}.png', dpi=150)
    plt.close(fig)
    return spine/MM

s1 = cover('cover-book1',
    ['Small Island,','Crowded Market'],
    ['What every Singapore business owner should','know about the ground they compete on'],
    'ONE', 268,
    [['Singapore has 371,000 businesses and 5.9 million people.','That is one business for every sixteen people on the island.'],
     ['This book maps the ground they all compete on: the three','engines that pay for everything, the four demographic waves','moving the money, and which industries a small business can','actually win in.'],
     ['Every figure is confidence-labelled. Where the data does not','exist, this book says so.']],
    GREEN, 'BOOK ONE — THE GROUND',
    'Every figure confidence-labelled')

s2 = cover('cover-book2',
    ['How a Small','Business','Gets Chosen'],
    ['Lessons from established Singapore brands'],
    'TWO', 252,
    [['Tiger Balm owns "relief". Old Chang Kee owns "curry puff".','Sheng Siong owns "the deal". Each of them owns one word in','the customer\'s mind, and that is why they get chosen.'],
     ['This is the method for finding yours.'],
     ['It is not another collection of success stories. It is the','positioning book that tells you where positioning fails: the','brands that widened and lost their word, the one that owned','its word perfectly and lost anyway when the category died,','and the one that was flawlessly different with no demand','under it.']],
    RUST, 'BOOK TWO — THE MOVE',
    'Including where positioning fails')

print(f'Book 1 spine: {s1:.1f} mm   Book 2 spine: {s2:.1f} mm')
